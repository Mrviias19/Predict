import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime, timedelta

class FootballVisualization:
    """
    Comprehensive visualization utilities for football prediction system
    """
    
    def __init__(self):
        self.color_palette = {
            'primary': '#FF6B6B',
            'secondary': '#4ECDC4',
            'success': '#45B7D1',
            'warning': '#FFA07A',
            'danger': '#FF6B6B',
            'info': '#6C7CE0',
            'dark': '#2C3E50',
            'light': '#F8F9FA'
        }
    
    def create_prediction_gauge(self, probabilities, predicted_outcome):
        """Create a gauge chart for match prediction probabilities"""
        
        # Map outcomes to colors
        outcome_colors = {
            'Home Win': self.color_palette['success'],
            'Draw': self.color_palette['warning'],
            'Away Win': self.color_palette['danger']
        }
        
        # Get the probability of the predicted outcome
        outcome_mapping = {
            'Home Win': 'home_win',
            'Draw': 'draw', 
            'Away Win': 'away_win'
        }
        
        predicted_prob = probabilities[outcome_mapping[predicted_outcome]]
        
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=predicted_prob * 100,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': f"Confidence: {predicted_outcome}"},
            delta={'reference': 50},
            gauge={
                'axis': {'range': [None, 100]},
                'bar': {'color': outcome_colors[predicted_outcome]},
                'steps': [
                    {'range': [0, 50], 'color': "lightgray"},
                    {'range': [50, 80], 'color': "gray"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 90
                }
            }
        ))
        
        fig.update_layout(
            height=300,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_probability_bars(self, probabilities):
        """Create horizontal bar chart for outcome probabilities"""
        
        outcomes = ['Home Win', 'Draw', 'Away Win']
        probs = [probabilities['home_win'], probabilities['draw'], probabilities['away_win']]
        colors = [self.color_palette['success'], self.color_palette['warning'], self.color_palette['danger']]
        
        fig = go.Figure(data=[
            go.Bar(
                x=probs,
                y=outcomes,
                orientation='h',
                marker_color=colors,
                text=[f"{p:.1%}" for p in probs],
                textposition='inside',
                textfont={'size': 14, 'color': 'white'}
            )
        ])
        
        fig.update_layout(
            title="Match Outcome Probabilities",
            xaxis_title="Probability",
            yaxis_title="Outcome",
            height=300,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            xaxis={'tickformat': '.0%'}
        )
        
        return fig
    
    def create_expected_goals_chart(self, home_xg, away_xg, home_team, away_team):
        """Create expected goals comparison chart"""
        
        fig = go.Figure(data=[
            go.Bar(
                x=[home_team, away_team],
                y=[home_xg, away_xg],
                marker_color=[self.color_palette['primary'], self.color_palette['secondary']],
                text=[f"{home_xg:.2f}", f"{away_xg:.2f}"],
                textposition='inside',
                textfont={'size': 16, 'color': 'white'}
            )
        ])
        
        fig.update_layout(
            title="Expected Goals (xG)",
            yaxis_title="Expected Goals",
            height=300,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_model_performance_chart(self, performance_data):
        """Create model performance visualization"""
        
        if not performance_data:
            return self.create_empty_chart("No performance data available")
        
        models = list(performance_data.keys())
        accuracies = [performance_data[model]['mean_accuracy'] for model in models]
        stds = [performance_data[model]['std_accuracy'] for model in models]
        
        fig = go.Figure(data=[
            go.Bar(
                x=models,
                y=accuracies,
                error_y=dict(type='data', array=stds),
                marker_color=self.color_palette['info'],
                text=[f"{acc:.3f}" for acc in accuracies],
                textposition='inside',
                textfont={'color': 'white'}
            )
        ])
        
        fig.update_layout(
            title="Model Performance Comparison",
            xaxis_title="Model",
            yaxis_title="Accuracy",
            height=400,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_feature_importance_chart(self, importance_df, top_n=15):
        """Create feature importance visualization"""
        
        if importance_df is None or importance_df.empty:
            return self.create_empty_chart("No feature importance data available")
        
        # Get top N features
        top_features = importance_df.head(top_n)
        
        fig = go.Figure(data=[
            go.Bar(
                x=top_features['average'],
                y=top_features['feature'],
                orientation='h',
                marker_color=self.color_palette['secondary'],
                text=[f"{imp:.3f}" for imp in top_features['average']],
                textposition='inside'
            )
        ])
        
        fig.update_layout(
            title=f"Top {top_n} Feature Importance",
            xaxis_title="Importance Score",
            yaxis_title="Features",
            height=500,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_training_history_chart(self, training_history):
        """Create training history visualization"""
        
        if not training_history:
            return self.create_empty_chart("No training history available")
        
        dates = [session['timestamp'] for session in training_history]
        accuracies = [session['test_accuracy'] for session in training_history]
        
        fig = go.Figure(data=[
            go.Scatter(
                x=dates,
                y=accuracies,
                mode='lines+markers',
                marker_color=self.color_palette['primary'],
                line={'width': 3}
            )
        ])
        
        fig.update_layout(
            title="Model Training History",
            xaxis_title="Training Date",
            yaxis_title="Test Accuracy",
            height=400,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_confusion_matrix(self, confusion_matrix_data):
        """Create confusion matrix heatmap"""
        
        if confusion_matrix_data is None:
            return self.create_empty_chart("No confusion matrix data available")
        
        labels = ['Home Win', 'Draw', 'Away Win']
        
        fig = go.Figure(data=go.Heatmap(
            z=confusion_matrix_data,
            x=labels,
            y=labels,
            colorscale='Blues',
            text=confusion_matrix_data,
            texttemplate="%{text}",
            textfont={"size": 16}
        ))
        
        fig.update_layout(
            title="Confusion Matrix",
            xaxis_title="Predicted",
            yaxis_title="Actual",
            height=400,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20}
        )
        
        return fig
    
    def create_backtest_results_chart(self, backtest_df):
        """Create backtest results visualization"""
        
        if backtest_df is None or backtest_df.empty:
            return self.create_empty_chart("No backtest data available")
        
        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=('Accuracy Over Time', 'Model Confidence'),
            vertical_spacing=0.1
        )
        
        # Accuracy over time
        fig.add_trace(
            go.Scatter(
                x=backtest_df['test_period_start'],
                y=backtest_df['accuracy'],
                mode='lines+markers',
                name='Accuracy',
                marker_color=self.color_palette['primary']
            ),
            row=1, col=1
        )
        
        # Average confidence over time
        fig.add_trace(
            go.Scatter(
                x=backtest_df['test_period_start'],
                y=backtest_df['avg_confidence'],
                mode='lines+markers',
                name='Avg Confidence',
                marker_color=self.color_palette['secondary']
            ),
            row=2, col=1
        )
        
        fig.update_layout(
            height=500,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_team_comparison_radar(self, home_stats, away_stats, home_team, away_team):
        """Create radar chart comparing team statistics"""
        
        # Define metrics for comparison
        metrics = ['goals_per_game', 'goals_conceded_per_game', 'avg_possession', 'pass_accuracy', 'shots_per_game']
        metric_labels = ['Goals/Game', 'Goals Conceded/Game', 'Possession %', 'Pass Accuracy %', 'Shots/Game']
        
        # Normalize values for radar chart (0-100 scale)
        home_values = []
        away_values = []
        
        for metric in metrics:
            home_val = home_stats.get(metric, 50)
            away_val = away_stats.get(metric, 50)
            
            if metric == 'goals_conceded_per_game':
                # Invert goals conceded (lower is better)
                home_val = max(0, 100 - home_val * 20)
                away_val = max(0, 100 - away_val * 20)
            elif metric in ['avg_possession', 'pass_accuracy']:
                # These are already percentages
                home_val = min(100, home_val)
                away_val = min(100, away_val)
            else:
                # Scale other metrics
                home_val = min(100, home_val * 20)
                away_val = min(100, away_val * 20)
            
            home_values.append(home_val)
            away_values.append(away_val)
        
        fig = go.Figure()
        
        # Add home team trace
        fig.add_trace(go.Scatterpolar(
            r=home_values,
            theta=metric_labels,
            fill='toself',
            name=home_team,
            marker_color=self.color_palette['primary']
        ))
        
        # Add away team trace
        fig.add_trace(go.Scatterpolar(
            r=away_values,
            theta=metric_labels,
            fill='toself',
            name=away_team,
            marker_color=self.color_palette['secondary']
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 100]
                )),
            showlegend=True,
            title="Team Statistics Comparison",
            height=500,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20}
        )
        
        return fig
    
    def create_betting_value_chart(self, betting_analysis):
        """Create betting value visualization"""
        
        outcomes = ['Home Win', 'Draw', 'Away Win']
        model_probs = [betting_analysis[outcome]['model_probability'] for outcome in ['home_win', 'draw', 'away_win']]
        implied_probs = [betting_analysis[outcome]['implied_probability'] for outcome in ['home_win', 'draw', 'away_win']]
        values = [betting_analysis[outcome]['value'] for outcome in ['home_win', 'draw', 'away_win']]
        
        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('Probability Comparison', 'Betting Value'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        # Probability comparison
        fig.add_trace(
            go.Bar(x=outcomes, y=model_probs, name='Model Probability', 
                   marker_color=self.color_palette['primary']),
            row=1, col=1
        )
        
        fig.add_trace(
            go.Bar(x=outcomes, y=implied_probs, name='Market Probability', 
                   marker_color=self.color_palette['secondary']),
            row=1, col=1
        )
        
        # Betting value
        colors = [self.color_palette['success'] if v > 0 else self.color_palette['danger'] for v in values]
        fig.add_trace(
            go.Bar(x=outcomes, y=values, name='Value', marker_color=colors),
            row=1, col=2
        )
        
        fig.update_layout(
            height=400,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_form_trend_chart(self, team_data, team_name):
        """Create team form trend visualization"""
        
        # Simulate recent form data
        dates = [datetime.now() - timedelta(days=x*7) for x in range(10, 0, -1)]
        form_scores = np.random.uniform(0, 3, 10)  # 0-3 scale (loss, draw, win)
        
        fig = go.Figure(data=[
            go.Scatter(
                x=dates,
                y=form_scores,
                mode='lines+markers',
                name=f'{team_name} Form',
                marker_color=self.color_palette['primary'],
                line={'width': 3}
            )
        ])
        
        fig.update_layout(
            title=f"{team_name} Recent Form Trend",
            xaxis_title="Date",
            yaxis_title="Form Score",
            height=300,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        
        return fig
    
    def create_empty_chart(self, message):
        """Create empty chart with message"""
        
        fig = go.Figure()
        
        fig.add_annotation(
            text=message,
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font={'size': 16, 'color': 'gray'}
        )
        
        fig.update_layout(
            height=300,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20},
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            xaxis={'visible': False},
            yaxis={'visible': False}
        )
        
        return fig
    
    def create_data_quality_dashboard(self, quality_report):
        """Create data quality dashboard"""
        
        if not quality_report or quality_report == "No data available for quality assessment":
            return self.create_empty_chart("No data quality information available")
        
        # Create metrics cards
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Data Coverage', 'Missing Data', 'Data Consistency', 'Update Status'),
            specs=[[{"type": "indicator"}, {"type": "bar"}],
                   [{"type": "indicator"}, {"type": "indicator"}]]
        )
        
        # Data coverage
        fig.add_trace(go.Indicator(
            mode="gauge+number",
            value=quality_report['total_matches'],
            title={'text': "Total Matches"},
            gauge={'axis': {'range': [None, 5000]}}
        ), row=1, col=1)
        
        # Missing data
        missing_data = quality_report['missing_data']
        fig.add_trace(go.Bar(
            x=list(missing_data.keys()),
            y=list(missing_data.values()),
            marker_color=self.color_palette['warning']
        ), row=1, col=2)
        
        # Data consistency
        consistency = quality_report['data_consistency']
        avg_consistency = np.mean(list(consistency.values())) * 100
        
        fig.add_trace(go.Indicator(
            mode="gauge+number",
            value=avg_consistency,
            title={'text': "Data Consistency %"},
            gauge={'axis': {'range': [0, 100]}}
        ), row=2, col=1)
        
        # Update status
        days_since_update = (datetime.now() - quality_report['last_updated']).days if quality_report['last_updated'] else 999
        
        fig.add_trace(go.Indicator(
            mode="number",
            value=days_since_update,
            title={'text': "Days Since Update"},
        ), row=2, col=2)
        
        fig.update_layout(
            height=600,
            margin={'l': 20, 'r': 20, 't': 50, 'b': 20}
        )
        
        return fig

def create_match_timeline_viz(predictions_history):
    """Create timeline visualization of recent predictions"""
    
    if not predictions_history:
        return None
    
    dates = [pred['date'] for pred in predictions_history]
    accuracies = [pred['was_correct'] for pred in predictions_history]
    
    fig = go.Figure(data=[
        go.Scatter(
            x=dates,
            y=accuracies,
            mode='markers',
            marker=dict(
                size=10,
                color=['green' if acc else 'red' for acc in accuracies]
            )
        )
    ])
    
    fig.update_layout(
        title="Recent Prediction Accuracy",
        xaxis_title="Date",
        yaxis_title="Prediction Correct",
        height=300
    )
    
    return fig
