import pandas as pd
import numpy as np
import json
import joblib
import os
from datetime import datetime, timedelta
import pickle
from pathlib import Path


class FilePersistenceManager:
    """
    Free file-based persistence system for all data and models
    No external APIs or paid services required
    """
    
    def __init__(self, base_path="data_storage"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(exist_ok=True)
        
        # Create subdirectories
        self.models_path = self.base_path / "models"
        self.predictions_path = self.base_path / "predictions"
        self.training_data_path = self.base_path / "training_data"
        self.betting_data_path = self.base_path / "betting_data"
        self.historical_path = self.base_path / "historical"
        
        for path in [self.models_path, self.predictions_path, self.training_data_path, 
                    self.betting_data_path, self.historical_path]:
            path.mkdir(exist_ok=True)
    
    def save_model(self, model, model_name, version="latest"):
        """Save trained model to file"""
        filename = f"{model_name}_{version}.pkl"
        filepath = self.models_path / filename
        
        try:
            joblib.dump(model, filepath)
            
            # Save metadata
            metadata = {
                'model_name': model_name,
                'version': version,
                'saved_at': datetime.now().isoformat(),
                'file_size': filepath.stat().st_size,
                'model_type': type(model).__name__
            }
            
            metadata_file = self.models_path / f"{model_name}_{version}_metadata.json"
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            return True, f"Model saved to {filepath}"
        
        except Exception as e:
            return False, f"Error saving model: {str(e)}"
    
    def load_model(self, model_name, version="latest"):
        """Load trained model from file"""
        filename = f"{model_name}_{version}.pkl"
        filepath = self.models_path / filename
        
        if not filepath.exists():
            return None, f"Model file not found: {filepath}"
        
        try:
            model = joblib.load(filepath)
            return model, "Model loaded successfully"
        
        except Exception as e:
            return None, f"Error loading model: {str(e)}"
    
    def save_training_data(self, data, dataset_name):
        """Save training data to CSV"""
        filename = f"{dataset_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = self.training_data_path / filename
        
        try:
            if isinstance(data, pd.DataFrame):
                data.to_csv(filepath, index=False)
            else:
                pd.DataFrame(data).to_csv(filepath, index=False)
            
            return True, f"Training data saved to {filepath}"
        
        except Exception as e:
            return False, f"Error saving training data: {str(e)}"
    
    def load_latest_training_data(self, dataset_name):
        """Load most recent training data"""
        pattern = f"{dataset_name}_*.csv"
        files = list(self.training_data_path.glob(pattern))
        
        if not files:
            return None, f"No training data found for {dataset_name}"
        
        # Get most recent file
        latest_file = max(files, key=lambda x: x.stat().st_mtime)
        
        try:
            data = pd.read_csv(latest_file)
            return data, f"Loaded training data from {latest_file}"
        
        except Exception as e:
            return None, f"Error loading training data: {str(e)}"
    
    def save_prediction(self, prediction_data, match_info):
        """Save individual prediction to file"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"prediction_{timestamp}.json"
        filepath = self.predictions_path / filename
        
        try:
            # Prepare data for JSON serialization
            save_data = {
                'match_info': match_info,
                'prediction': prediction_data,
                'timestamp': timestamp,
                'saved_at': datetime.now().isoformat()
            }
            
            # Convert numpy types to Python types
            save_data = self._convert_numpy_types(save_data)
            
            with open(filepath, 'w') as f:
                json.dump(save_data, f, indent=2)
            
            return True, f"Prediction saved to {filepath}"
        
        except Exception as e:
            return False, f"Error saving prediction: {str(e)}"
    
    def save_betting_session(self, betting_data, session_name):
        """Save betting analysis session"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"betting_session_{session_name}_{timestamp}.json"
        filepath = self.betting_data_path / filename
        
        try:
            save_data = {
                'session_name': session_name,
                'betting_data': betting_data,
                'timestamp': timestamp,
                'saved_at': datetime.now().isoformat()
            }
            
            save_data = self._convert_numpy_types(save_data)
            
            with open(filepath, 'w') as f:
                json.dump(save_data, f, indent=2)
            
            return True, f"Betting session saved to {filepath}"
        
        except Exception as e:
            return False, f"Error saving betting session: {str(e)}"
    
    def load_historical_predictions(self, days_back=30):
        """Load historical predictions from the last N days"""
        cutoff_date = datetime.now() - timedelta(days=days_back)
        
        predictions = []
        for file in self.predictions_path.glob("prediction_*.json"):
            try:
                with open(file, 'r') as f:
                    data = json.load(f)
                
                pred_date = datetime.fromisoformat(data['saved_at'])
                if pred_date >= cutoff_date:
                    predictions.append(data)
            
            except Exception as e:
                print(f"Warning: Could not load {file}: {e}")
                continue
        
        return predictions
    
    def get_storage_stats(self):
        """Get storage usage statistics"""
        stats = {
            'total_models': len(list(self.models_path.glob("*.pkl"))),
            'total_predictions': len(list(self.predictions_path.glob("*.json"))),
            'total_training_datasets': len(list(self.training_data_path.glob("*.csv"))),
            'total_betting_sessions': len(list(self.betting_data_path.glob("*.json"))),
            'storage_paths': {
                'models': str(self.models_path),
                'predictions': str(self.predictions_path),
                'training_data': str(self.training_data_path),
                'betting_data': str(self.betting_data_path)
            }
        }
        
        # Calculate total size
        total_size = 0
        for path in [self.models_path, self.predictions_path, self.training_data_path, self.betting_data_path]:
            for file in path.rglob("*"):
                if file.is_file():
                    total_size += file.stat().st_size
        
        stats['total_size_mb'] = total_size / (1024 * 1024)
        
        return stats
    
    def _convert_numpy_types(self, obj):
        """Convert numpy types to Python types for JSON serialization"""
        if isinstance(obj, dict):
            return {key: self._convert_numpy_types(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_numpy_types(item) for item in obj]
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj
    
    def export_data_for_backup(self, backup_name):
        """Export all data for backup"""
        backup_path = self.base_path / f"backup_{backup_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_path.mkdir(exist_ok=True)
        
        try:
            # Copy all directories
            import shutil
            for source_path in [self.models_path, self.predictions_path, 
                              self.training_data_path, self.betting_data_path]:
                dest_path = backup_path / source_path.name
                shutil.copytree(source_path, dest_path, dirs_exist_ok=True)
            
            return True, f"Backup created at {backup_path}"
        
        except Exception as e:
            return False, f"Error creating backup: {str(e)}"
    
    def clean_old_data(self, days_to_keep=30):
        """Clean old prediction and betting data"""
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        cleaned_files = 0
        
        # Clean predictions
        for file in self.predictions_path.glob("prediction_*.json"):
            try:
                with open(file, 'r') as f:
                    data = json.load(f)
                
                pred_date = datetime.fromisoformat(data['saved_at'])
                if pred_date < cutoff_date:
                    file.unlink()
                    cleaned_files += 1
            
            except Exception:
                continue
        
        # Clean betting sessions
        for file in self.betting_data_path.glob("betting_session_*.json"):
            if file.stat().st_mtime < cutoff_date.timestamp():
                file.unlink()
                cleaned_files += 1
        
        return cleaned_files


class FreeDataSources:
    """
    Free data sources for real football data
    No API keys or paid services required
    """
    
    def __init__(self):
        self.data_sources = {
            'fixtures': [
                'https://www.bbc.com/sport/football/fixtures',
                'https://www.espn.com/soccer/fixtures',
                'https://www.skysports.com/football/fixtures'
            ],
            'results': [
                'https://www.bbc.com/sport/football/results',
                'https://www.espn.com/soccer/results'
            ],
            'tables': [
                'https://www.bbc.com/sport/football/tables',
                'https://www.espn.com/soccer/standings'
            ]
        }
    
    def get_available_sources(self):
        """Get list of free data sources"""
        return {
            'Real-time Fixtures': 'BBC Sport, ESPN, Sky Sports (web scraping)',
            'Historical Results': 'Free football databases, CSV downloads',
            'Team Statistics': 'Public sports websites',
            'Player Data': 'Wikipedia, free sports APIs',
            'Weather Data': 'Free weather APIs (OpenWeatherMap free tier)',
            'Betting Odds': 'Odds comparison websites',
            'Manual Data Entry': 'CSV upload system for your own data'
        }
    
    def create_sample_csv_template(self):
        """Create CSV template for manual data entry"""
        template_data = {
            'date': ['2024-01-15', '2024-01-16'],
            'home_team': ['Manchester City', 'Liverpool'],
            'away_team': ['Arsenal', 'Chelsea'],
            'home_goals': [2, 1],
            'away_goals': [1, 1],
            'venue': ['Etihad Stadium', 'Anfield'],
            'league': ['Premier League', 'Premier League'],
            'attendance': [54000, 53000],
            'weather_temp': [15, 12],
            'weather_condition': ['Clear', 'Rainy']
        }
        
        return pd.DataFrame(template_data)
    
    def manual_data_entry_guide(self):
        """Provide guide for manual data entry"""
        return {
            'step_1': 'Download historical data from free sources like football-data.co.uk',
            'step_2': 'Use the CSV template to format your data',
            'step_3': 'Upload CSV files through the Data Collection page',
            'step_4': 'System will automatically process and train on your data',
            'free_sources': [
                'football-data.co.uk - Free historical football results',
                'fbref.com - Free football statistics',
                'transfermarkt.com - Free transfer and team data',
                'premierleague.com - Official fixtures and results'
            ]
        }


def create_free_setup_guide():
    """Create comprehensive guide for free setup"""
    return {
        'storage': {
            'description': 'All data stored locally in files - no cloud costs',
            'location': 'data_storage/ folder in your project',
            'backup': 'Export function creates complete backups'
        },
        'data_sources': {
            'free_apis': 'OpenWeatherMap (free tier), free sports APIs',
            'web_scraping': 'BBC Sport, ESPN for live fixtures',
            'manual_entry': 'CSV upload system for your own data',
            'historical_data': 'football-data.co.uk, fbref.com'
        },
        'deployment': {
            'local': 'Run on your computer with Streamlit',
            'free_hosting': 'Streamlit Cloud, Heroku free tier, Railway',
            'requirements': 'Just Python and the installed packages'
        },
        'costs': {
            'total_cost': '$0 - Completely free to run',
            'storage': 'Local files only',
            'compute': 'Your computer or free hosting',
            'data': 'Free sources and manual entry'
        }
    }