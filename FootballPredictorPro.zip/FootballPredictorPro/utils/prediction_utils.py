import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import streamlit as st
from models.ensemble_model import FootballPredictionEnsemble
from models.feature_engineering import FootballFeatureEngineer
from data.data_collector import FootballDataCollector
import joblib
import os

class PredictionUtils:
    """
    Utility functions for football match predictions
    """
    
    def __init__(self):
        self.model = None
        self.feature_engineer = None
        self.data_collector = FootballDataCollector()
        
    def load_trained_model(self, model_path='models/trained_model.pkl'):
        """Load a trained model for predictions"""
        try:
            if os.path.exists(model_path):
                training_session = joblib.load(model_path)
                self.model = training_session['model']
                self.feature_engineer = training_session['feature_engineer']
                return True
            else:
                return False
        except Exception as e:
            st.error(f"Error loading model: {e}")
            return False
    
    def create_prediction_dataframe(self, home_team, away_team, match_date, venue=None, league='Premier League'):
        """Create a dataframe for prediction from match details"""
        
        # Collect comprehensive match data
        prediction_data = self.data_collector.get_match_prediction_data(
            home_team, away_team, match_date, venue
        )
        
        # Create base match record
        match_record = {
            'match_date': pd.to_datetime(match_date),
            'home_team': home_team,
            'away_team': away_team,
            'venue': venue or f"{home_team} Stadium",
            'league': league,
            'referee': prediction_data['referee']['name']
        }
        
        # Add team statistics
        home_stats = prediction_data['team_stats']['home']
        away_stats = prediction_data['team_stats']['away']
        
        # Add relevant statistics to match record
        match_record.update({
            'home_team_rating': home_stats.get('xg_for', 60),
            'away_team_rating': away_stats.get('xg_for', 60),
            'home_injuries': len([p for p in prediction_data['player_data']['home'] 
                                if p['injury_status'] != 'Fit']),
            'away_injuries': len([p for p in prediction_data['player_data']['away'] 
                                if p['injury_status'] != 'Fit']),
            'temperature': prediction_data['weather']['temperature'],
            'humidity': prediction_data['weather']['humidity'],
            'wind_speed': prediction_data['weather']['wind_speed'],
            'precipitation': prediction_data['weather']['precipitation']
        })
        
        # Create DataFrame
        df = pd.DataFrame([match_record])
        
        return df, prediction_data
    
    def make_prediction(self, home_team, away_team, match_date, venue=None, league='Premier League'):
        """Make a comprehensive prediction for a match"""
        
        if not self.model or not self.feature_engineer:
            # Try to load model
            if not self.load_trained_model():
                return None, "No trained model available. Please train a model first."
        
        try:
            # Create prediction dataframe
            df, raw_data = self.create_prediction_dataframe(
                home_team, away_team, match_date, venue, league
            )
            
            # Create features using the same feature engineering pipeline
            df_features, feature_columns = self.feature_engineer.create_all_features(df)
            
            # Prepare features for prediction
            X = df_features[feature_columns].copy()
            X = X.fillna(X.mean())
            
            # Make prediction
            prediction_result = self.model.predict_match_details(X)
            
            # Enhance prediction with additional analysis
            enhanced_prediction = self.enhance_prediction(
                prediction_result[0], raw_data, home_team, away_team
            )
            
            return enhanced_prediction, None
            
        except Exception as e:
            return None, f"Error making prediction: {str(e)}"
    
    def enhance_prediction(self, base_prediction, raw_data, home_team, away_team):
        """Enhance basic prediction with additional insights"""
        
        enhanced = base_prediction.copy()
        
        # Add betting analysis
        betting_odds = raw_data['betting_odds']['average_odds']
        enhanced['betting_analysis'] = self.analyze_betting_value(
            base_prediction['probabilities'], betting_odds
        )
        
        # Add form analysis
        enhanced['form_analysis'] = self.analyze_team_form(
            raw_data['team_stats']['home'], raw_data['team_stats']['away']
        )
        
        # Add weather impact
        enhanced['weather_impact'] = self.analyze_weather_impact(raw_data['weather'])
        
        # Add injury impact
        enhanced['injury_impact'] = self.analyze_injury_impact(
            raw_data['player_data']['home'], raw_data['player_data']['away']
        )
        
        # Add head-to-head insights
        enhanced['h2h_insights'] = self.analyze_h2h_history(raw_data['historical_h2h'])
        
        # Calculate expected goals
        enhanced['expected_goals'] = self.calculate_expected_goals(
            base_prediction['probabilities'], raw_data
        )
        
        # Generate key factors
        enhanced['key_factors'] = self.identify_key_factors(enhanced, home_team, away_team)
        
        return enhanced
    
    def analyze_betting_value(self, probabilities, odds):
        """Analyze betting value based on model probabilities vs market odds"""
        
        # Convert odds to implied probabilities
        implied_probs = {
            'home_win': 1 / odds['home_win'],
            'draw': 1 / odds['draw'],
            'away_win': 1 / odds['away_win']
        }
        
        # Calculate value
        value_analysis = {}
        outcomes = ['home_win', 'draw', 'away_win']
        
        for outcome in outcomes:
            model_prob = probabilities[outcome]
            implied_prob = implied_probs[outcome]
            
            value = (model_prob / implied_prob) - 1
            
            value_analysis[outcome] = {
                'model_probability': model_prob,
                'implied_probability': implied_prob,
                'value': value,
                'recommended': value > 0.1  # 10% edge threshold
            }
        
        return value_analysis
    
    def analyze_team_form(self, home_stats, away_stats):
        """Analyze recent team form"""
        
        home_form = home_stats.get('form_last_5', [])
        away_form = away_stats.get('form_last_5', [])
        
        form_analysis = {
            'home_form_score': np.mean(home_form) if home_form else 1.5,
            'away_form_score': np.mean(away_form) if away_form else 1.5,
            'home_trend': 'improving' if len(home_form) >= 3 and home_form[-1] > home_form[-3] else 'declining',
            'away_trend': 'improving' if len(away_form) >= 3 and away_form[-1] > away_form[-3] else 'declining'
        }
        
        form_analysis['form_advantage'] = form_analysis['home_form_score'] - form_analysis['away_form_score']
        
        return form_analysis
    
    def analyze_weather_impact(self, weather_data):
        """Analyze potential weather impact on the match"""
        
        temp = weather_data['temperature']
        wind = weather_data['wind_speed']
        rain = weather_data['precipitation_chance']
        
        impact_factors = []
        
        if temp < 5:
            impact_factors.append("Cold weather may affect ball control and player performance")
        elif temp > 30:
            impact_factors.append("Hot weather may lead to fatigue and more substitutions")
        
        if wind > 15:
            impact_factors.append("Strong winds may affect passing accuracy and set pieces")
        
        if rain > 70:
            impact_factors.append("High chance of rain may make the pitch slippery and affect play style")
        
        return {
            'impact_level': 'High' if len(impact_factors) > 1 else 'Medium' if impact_factors else 'Low',
            'factors': impact_factors,
            'conditions_summary': f"{temp:.1f}°C, {wind:.1f} km/h wind, {rain:.0f}% rain chance"
        }
    
    def analyze_injury_impact(self, home_players, away_players):
        """Analyze impact of injuries on team strength"""
        
        home_injuries = [p for p in home_players if p['injury_status'] != 'Fit']
        away_injuries = [p for p in away_players if p['injury_status'] != 'Fit']
        
        # Calculate impact based on player importance and position
        def calculate_injury_impact(injuries):
            total_impact = 0
            for injury in injuries:
                position_weight = {
                    'GK': 0.8,  # Goalkeeper injuries are critical
                    'DEF': 0.6,
                    'MID': 0.7,
                    'FWD': 0.7
                }.get(injury['position'], 0.5)
                
                severity_weight = {
                    'Minor Injury': 0.3,
                    'Major Injury': 0.8
                }.get(injury['injury_status'], 0.5)
                
                total_impact += position_weight * severity_weight
            
            return min(total_impact, 2.0)  # Cap at 2.0
        
        home_impact = calculate_injury_impact(home_injuries)
        away_impact = calculate_injury_impact(away_injuries)
        
        return {
            'home_injury_count': len(home_injuries),
            'away_injury_count': len(away_injuries),
            'home_impact_score': home_impact,
            'away_impact_score': away_impact,
            'injury_advantage': away_impact - home_impact,  # Positive means home team has advantage
            'summary': f"Home: {len(home_injuries)} injuries, Away: {len(away_injuries)} injuries"
        }
    
    def analyze_h2h_history(self, h2h_matches):
        """Analyze head-to-head history between teams"""
        
        if not h2h_matches:
            return {'insufficient_data': True}
        
        h2h_df = pd.DataFrame(h2h_matches)
        
        total_matches = len(h2h_df)
        home_wins = len(h2h_df[h2h_df['result'] == 'H'])
        away_wins = len(h2h_df[h2h_df['result'] == 'A'])
        draws = len(h2h_df[h2h_df['result'] == 'D'])
        
        # Recent form (last 5 matches)
        recent_matches = h2h_df.head(5)
        recent_results = recent_matches['result'].tolist()
        
        avg_goals = (h2h_df['home_goals'].mean() + h2h_df['away_goals'].mean())
        
        return {
            'total_matches': total_matches,
            'home_wins': home_wins,
            'away_wins': away_wins,
            'draws': draws,
            'home_win_rate': home_wins / total_matches,
            'recent_results': recent_results,
            'avg_total_goals': avg_goals,
            'h2h_trend': self.determine_h2h_trend(recent_results)
        }
    
    def determine_h2h_trend(self, recent_results):
        """Determine trend from recent H2H results"""
        if not recent_results:
            return "No recent data"
        
        home_wins = recent_results.count('H')
        away_wins = recent_results.count('A')
        
        if home_wins > away_wins:
            return "Home team dominance"
        elif away_wins > home_wins:
            return "Away team dominance"
        else:
            return "Balanced recent record"
    
    def calculate_expected_goals(self, probabilities, raw_data):
        """Calculate expected goals for both teams"""
        
        # Base expected goals from team statistics
        home_stats = raw_data['team_stats']['home']
        away_stats = raw_data['team_stats']['away']
        
        home_xg = home_stats.get('goals_per_game', 1.5) * 1.1  # Home advantage
        away_xg = away_stats.get('goals_per_game', 1.5) * 0.9  # Away disadvantage
        
        # Adjust based on match probabilities
        if probabilities['home_win'] > 0.5:
            home_xg *= 1.2
            away_xg *= 0.8
        elif probabilities['away_win'] > 0.5:
            home_xg *= 0.8
            away_xg *= 1.2
        
        # Calculate over/under probabilities
        total_xg = home_xg + away_xg
        
        over_2_5_prob = 1 - np.exp(-total_xg) * (1 + total_xg + (total_xg**2)/2)  # Poisson approximation
        
        return {
            'home_xg': round(home_xg, 2),
            'away_xg': round(away_xg, 2),
            'total_xg': round(total_xg, 2),
            'over_2_5_probability': round(over_2_5_prob, 3),
            'under_2_5_probability': round(1 - over_2_5_prob, 3)
        }
    
    def identify_key_factors(self, enhanced_prediction, home_team, away_team):
        """Identify the most important factors affecting the prediction"""
        
        factors = []
        
        # Check confidence level
        confidence = enhanced_prediction['confidence']
        if confidence > 0.8:
            factors.append(f"High model confidence ({confidence:.1%})")
        elif confidence < 0.6:
            factors.append(f"Low model confidence ({confidence:.1%}) - unpredictable match")
        
        # Check form
        form_adv = enhanced_prediction['form_analysis']['form_advantage']
        if abs(form_adv) > 0.5:
            better_form_team = home_team if form_adv > 0 else away_team
            factors.append(f"{better_form_team} has significantly better recent form")
        
        # Check injuries
        injury_adv = enhanced_prediction['injury_impact']['injury_advantage']
        if abs(injury_adv) > 0.3:
            less_injured_team = home_team if injury_adv > 0 else away_team
            factors.append(f"{less_injured_team} has fewer key player injuries")
        
        # Check H2H if available
        h2h = enhanced_prediction.get('h2h_insights', {})
        if not h2h.get('insufficient_data') and h2h.get('home_win_rate'):
            if h2h['home_win_rate'] > 0.7:
                factors.append(f"{home_team} dominates recent H2H record")
            elif h2h['home_win_rate'] < 0.3:
                factors.append(f"{away_team} dominates recent H2H record")
        
        # Check betting value
        betting = enhanced_prediction['betting_analysis']
        value_bets = [outcome for outcome, data in betting.items() if data['recommended']]
        if value_bets:
            factors.append(f"Model identifies value in: {', '.join(value_bets)}")
        
        # Check weather
        weather_impact = enhanced_prediction['weather_impact']['impact_level']
        if weather_impact == 'High':
            factors.append("Weather conditions may significantly affect play")
        
        return factors[:5]  # Return top 5 factors
    
    def get_prediction_explanation(self, prediction):
        """Generate human-readable explanation of the prediction"""
        
        outcome = prediction['predicted_outcome']
        confidence = prediction['confidence']
        
        explanation = f"The model predicts a {outcome} with {confidence:.1%} confidence.\n\n"
        
        # Add probability breakdown
        probs = prediction['probabilities']
        explanation += f"Probability breakdown:\n"
        explanation += f"• Home Win: {probs['home_win']:.1%}\n"
        explanation += f"• Draw: {probs['draw']:.1%}\n"
        explanation += f"• Away Win: {probs['away_win']:.1%}\n\n"
        
        # Add key factors
        if 'key_factors' in prediction:
            explanation += "Key factors influencing this prediction:\n"
            for factor in prediction['key_factors']:
                explanation += f"• {factor}\n"
        
        return explanation

def format_prediction_for_display(prediction):
    """Format prediction results for Streamlit display"""
    
    if not prediction:
        return None
    
    # Main prediction card
    outcome = prediction['predicted_outcome']
    confidence = prediction['confidence']
    
    prediction_card = {
        'outcome': outcome,
        'confidence': confidence,
        'risk_level': prediction['risk_level'],
        'probabilities': prediction['probabilities']
    }
    
    # Expected goals
    if 'expected_goals' in prediction:
        prediction_card['expected_goals'] = prediction['expected_goals']
    
    # Betting analysis
    if 'betting_analysis' in prediction:
        prediction_card['betting_analysis'] = prediction['betting_analysis']
    
    return prediction_card

def get_available_teams():
    """Get list of available teams for prediction"""
    # In a real application, this would come from a database
    return [
        'Arsenal', 'Chelsea', 'Liverpool', 'Manchester City', 'Manchester United',
        'Tottenham', 'Newcastle', 'Brighton', 'Aston Villa', 'West Ham',
        'Crystal Palace', 'Fulham', 'Brentford', 'Wolves', 'Everton',
        'Nottingham Forest', 'Leeds United', 'Leicester City', 'Southampton', 'Bournemouth'
    ]

def get_available_venues():
    """Get list of available venues"""
    return [
        'Emirates Stadium', 'Stamford Bridge', 'Anfield', 'Etihad Stadium',
        'Old Trafford', 'Tottenham Hotspur Stadium', 'St. James Park',
        'Amex Stadium', 'Villa Park', 'London Stadium', 'Selhurst Park',
        'Craven Cottage', 'Brentford Community Stadium', 'Molineux Stadium',
        'Goodison Park', 'City Ground', 'Elland Road', 'King Power Stadium',
        'St. Mary\'s Stadium', 'Vitality Stadium'
    ]
