import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.metrics import brier_score_loss, log_loss
from sklearn.model_selection import cross_val_score, TimeSeriesSplit
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class ModelEvaluator:
    """
    Comprehensive model evaluation utilities
    """
    
    def __init__(self):
        self.evaluation_history = []
        
    def evaluate_classification_performance(self, y_true, y_pred, y_proba=None):
        """Comprehensive classification performance evaluation"""
        
        # Basic metrics
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision_macro': precision_score(y_true, y_pred, average='macro'),
            'recall_macro': recall_score(y_true, y_pred, average='macro'),
            'f1_macro': f1_score(y_true, y_pred, average='macro'),
            'precision_weighted': precision_score(y_true, y_pred, average='weighted'),
            'recall_weighted': recall_score(y_true, y_pred, average='weighted'),
            'f1_weighted': f1_score(y_true, y_pred, average='weighted')
        }
        
        # Per-class metrics
        class_report = classification_report(y_true, y_pred, output_dict=True)
        metrics['per_class_metrics'] = class_report
        
        # Confusion matrix
        cm = confusion_matrix(y_true, y_pred)
        metrics['confusion_matrix'] = cm.tolist()
        
        # Probabilistic metrics if probabilities are provided
        if y_proba is not None:
            try:
                # Multi-class Brier score
                metrics['brier_score'] = self.calculate_multiclass_brier_score(y_true, y_proba)
                
                # Log loss
                metrics['log_loss'] = log_loss(y_true, y_proba)
                
                # ROC AUC (one-vs-rest for multiclass)
                try:
                    metrics['roc_auc_ovr'] = roc_auc_score(y_true, y_proba, multi_class='ovr')
                except ValueError:
                    metrics['roc_auc_ovr'] = None
                
            except Exception as e:
                print(f"Error calculating probabilistic metrics: {e}")
        
        return metrics
    
    def calculate_multiclass_brier_score(self, y_true, y_proba):
        """Calculate Brier score for multiclass classification"""
        n_classes = y_proba.shape[1]
        y_true_onehot = np.zeros((len(y_true), n_classes))
        for i, label in enumerate(y_true):
            y_true_onehot[i, label] = 1
        
        brier_score = np.mean(np.sum((y_proba - y_true_onehot) ** 2, axis=1))
        return brier_score
    
    def evaluate_prediction_confidence(self, y_true, y_pred, confidence_scores):
        """Evaluate relationship between prediction confidence and accuracy"""
        
        correct_predictions = (y_true == y_pred)
        
        # Define confidence bins
        confidence_bins = [(0, 0.5), (0.5, 0.7), (0.7, 0.85), (0.85, 1.0)]
        bin_labels = ['Low (0-50%)', 'Medium (50-70%)', 'High (70-85%)', 'Very High (85-100%)']
        
        confidence_analysis = {}
        
        for i, (low, high) in enumerate(confidence_bins):
            mask = (confidence_scores >= low) & (confidence_scores < high)
            if i == len(confidence_bins) - 1:  # Last bin includes upper bound
                mask = (confidence_scores >= low) & (confidence_scores <= high)
            
            if mask.sum() > 0:
                accuracy_in_bin = correct_predictions[mask].mean()
                count_in_bin = mask.sum()
                avg_confidence_in_bin = confidence_scores[mask].mean()
                
                confidence_analysis[bin_labels[i]] = {
                    'accuracy': accuracy_in_bin,
                    'count': int(count_in_bin),
                    'avg_confidence': avg_confidence_in_bin,
                    'percentage_of_predictions': count_in_bin / len(y_true)
                }
            else:
                confidence_analysis[bin_labels[i]] = {
                    'accuracy': 0,
                    'count': 0,
                    'avg_confidence': 0,
                    'percentage_of_predictions': 0
                }
        
        # Overall confidence calibration
        calibration_score = self.calculate_calibration_score(y_true, y_pred, confidence_scores)
        
        return {
            'confidence_bins': confidence_analysis,
            'calibration_score': calibration_score,
            'overall_avg_confidence': confidence_scores.mean(),
            'confidence_std': confidence_scores.std()
        }
    
    def calculate_calibration_score(self, y_true, y_pred, confidence_scores, n_bins=10):
        """Calculate reliability/calibration score"""
        
        correct_predictions = (y_true == y_pred).astype(int)
        
        # Create bins
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        calibration_error = 0
        total_samples = len(y_true)
        
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            # Find predictions in this confidence bin
            in_bin = (confidence_scores > bin_lower) & (confidence_scores <= bin_upper)
            prop_in_bin = in_bin.sum() / total_samples
            
            if prop_in_bin > 0:
                accuracy_in_bin = correct_predictions[in_bin].mean()
                avg_confidence_in_bin = confidence_scores[in_bin].mean()
                
                # Expected Calibration Error (ECE)
                calibration_error += np.abs(avg_confidence_in_bin - accuracy_in_bin) * prop_in_bin
        
        return calibration_error
    
    def evaluate_betting_performance(self, predictions_df):
        """Evaluate performance from a betting perspective"""
        
        if 'actual_result' not in predictions_df.columns:
            return "No actual results available for betting evaluation"
        
        # Calculate profit/loss for different betting strategies
        betting_results = {}
        
        # Strategy 1: Bet on model's top prediction when confidence > threshold
        confidence_thresholds = [0.6, 0.7, 0.8]
        
        for threshold in confidence_thresholds:
            high_confidence_bets = predictions_df[predictions_df['confidence'] >= threshold]
            
            if len(high_confidence_bets) > 0:
                correct_bets = (high_confidence_bets['predicted_outcome'] == high_confidence_bets['actual_result']).sum()
                total_bets = len(high_confidence_bets)
                win_rate = correct_bets / total_bets
                
                # Simple profit calculation (assuming even odds for simplicity)
                profit = correct_bets * 1.0 - (total_bets - correct_bets) * 1.0
                roi = profit / total_bets if total_bets > 0 else 0
                
                betting_results[f'confidence_{threshold}'] = {
                    'total_bets': total_bets,
                    'winning_bets': correct_bets,
                    'win_rate': win_rate,
                    'profit_units': profit,
                    'roi': roi
                }
        
        # Strategy 2: Value betting (when model probability > implied probability)
        if 'betting_odds' in predictions_df.columns:
            value_bets = self.identify_value_bets(predictions_df)
            betting_results['value_betting'] = value_bets
        
        return betting_results
    
    def identify_value_bets(self, predictions_df):
        """Identify value betting opportunities"""
        
        value_bets = []
        
        for _, row in predictions_df.iterrows():
            if pd.isna(row['betting_odds']):
                continue
                
            # Parse betting odds (assuming decimal format)
            try:
                odds = eval(row['betting_odds'])  # Assuming stored as dict string
                
                for outcome in ['home_win', 'draw', 'away_win']:
                    if outcome in odds and outcome in row:
                        model_prob = row[outcome]
                        decimal_odds = odds[outcome]
                        implied_prob = 1 / decimal_odds
                        
                        # Value exists if model probability > implied probability
                        if model_prob > implied_prob * 1.05:  # 5% margin for value
                            edge = (model_prob / implied_prob) - 1
                            
                            value_bets.append({
                                'match': f"{row.get('home_team', 'Team A')} vs {row.get('away_team', 'Team B')}",
                                'outcome': outcome,
                                'model_probability': model_prob,
                                'implied_probability': implied_prob,
                                'odds': decimal_odds,
                                'edge': edge
                            })
            except:
                continue
        
        return value_bets
    
    def evaluate_temporal_performance(self, predictions_df, date_column='match_date'):
        """Evaluate model performance over time"""
        
        if date_column not in predictions_df.columns:
            return "No date information available for temporal analysis"
        
        predictions_df[date_column] = pd.to_datetime(predictions_df[date_column])
        predictions_df = predictions_df.sort_values(date_column)
        
        # Monthly performance
        predictions_df['year_month'] = predictions_df[date_column].dt.to_period('M')
        monthly_performance = predictions_df.groupby('year_month').agg({
            'accuracy': 'mean',
            'confidence': 'mean',
            'predicted_outcome': 'count'
        }).rename(columns={'predicted_outcome': 'prediction_count'})
        
        # Rolling performance (30-day windows)
        predictions_df['rolling_accuracy'] = predictions_df['accuracy'].rolling(window=30, min_periods=10).mean()
        
        # Performance by day of week
        predictions_df['day_of_week'] = predictions_df[date_column].dt.day_name()
        dow_performance = predictions_df.groupby('day_of_week')['accuracy'].mean()
        
        # Performance by season period
        predictions_df['month'] = predictions_df[date_column].dt.month
        predictions_df['season_period'] = predictions_df['month'].apply(self.get_season_period)
        season_performance = predictions_df.groupby('season_period')['accuracy'].mean()
        
        return {
            'monthly_performance': monthly_performance.to_dict('index'),
            'day_of_week_performance': dow_performance.to_dict(),
            'season_performance': season_performance.to_dict(),
            'rolling_accuracy_trend': predictions_df[['match_date', 'rolling_accuracy']].dropna().to_dict('records')
        }
    
    def get_season_period(self, month):
        """Map month to season period"""
        if month in [8, 9]:
            return 'Early Season'
        elif month in [10, 11, 12, 1, 2]:
            return 'Mid Season'
        elif month in [3, 4, 5]:
            return 'Late Season'
        else:
            return 'Off Season'
    
    def evaluate_league_performance(self, predictions_df):
        """Evaluate performance across different leagues"""
        
        if 'league' not in predictions_df.columns:
            return "No league information available"
        
        league_performance = predictions_df.groupby('league').agg({
            'accuracy': ['mean', 'count', 'std'],
            'confidence': 'mean'
        }).round(4)
        
        return league_performance.to_dict('index')
    
    def evaluate_match_type_performance(self, predictions_df):
        """Evaluate performance by match characteristics"""
        
        performance_analysis = {}
        
        # Performance by predicted outcome
        if 'predicted_outcome' in predictions_df.columns:
            outcome_performance = predictions_df.groupby('predicted_outcome')['accuracy'].agg(['mean', 'count'])
            performance_analysis['by_predicted_outcome'] = outcome_performance.to_dict('index')
        
        # Performance by confidence level
        if 'confidence' in predictions_df.columns:
            predictions_df['confidence_level'] = pd.cut(
                predictions_df['confidence'], 
                bins=[0, 0.5, 0.7, 0.85, 1.0],
                labels=['Low', 'Medium', 'High', 'Very High']
            )
            confidence_performance = predictions_df.groupby('confidence_level')['accuracy'].agg(['mean', 'count'])
            performance_analysis['by_confidence_level'] = confidence_performance.to_dict('index')
        
        # Performance by match importance (if available)
        if 'match_importance' in predictions_df.columns:
            importance_performance = predictions_df.groupby('match_importance')['accuracy'].agg(['mean', 'count'])
            performance_analysis['by_match_importance'] = importance_performance.to_dict('index')
        
        return performance_analysis
    
    def generate_performance_report(self, y_true, y_pred, y_proba=None, predictions_df=None):
        """Generate comprehensive performance report"""
        
        report = {
            'timestamp': datetime.now(),
            'basic_metrics': self.evaluate_classification_performance(y_true, y_pred, y_proba),
            'sample_size': len(y_true)
        }
        
        # Add confidence analysis if probabilities available
        if y_proba is not None:
            confidence_scores = np.max(y_proba, axis=1)
            report['confidence_analysis'] = self.evaluate_prediction_confidence(y_true, y_pred, confidence_scores)
        
        # Add additional analyses if DataFrame provided
        if predictions_df is not None:
            try:
                report['betting_performance'] = self.evaluate_betting_performance(predictions_df)
                report['temporal_performance'] = self.evaluate_temporal_performance(predictions_df)
                report['league_performance'] = self.evaluate_league_performance(predictions_df)
                report['match_type_performance'] = self.evaluate_match_type_performance(predictions_df)
            except Exception as e:
                print(f"Error in additional analyses: {e}")
        
        # Performance summary
        accuracy = report['basic_metrics']['accuracy']
        if accuracy >= 0.8:
            performance_grade = 'Excellent'
        elif accuracy >= 0.7:
            performance_grade = 'Good'
        elif accuracy >= 0.6:
            performance_grade = 'Fair'
        else:
            performance_grade = 'Poor'
        
        report['performance_summary'] = {
            'grade': performance_grade,
            'accuracy': accuracy,
            'strengths': self.identify_model_strengths(report),
            'weaknesses': self.identify_model_weaknesses(report),
            'recommendations': self.generate_improvement_recommendations(report)
        }
        
        # Save to evaluation history
        self.evaluation_history.append(report)
        
        return report
    
    def identify_model_strengths(self, report):
        """Identify model strengths from performance report"""
        
        strengths = []
        basic_metrics = report['basic_metrics']
        
        if basic_metrics['accuracy'] > 0.75:
            strengths.append("High overall accuracy")
        
        if basic_metrics['f1_macro'] > 0.7:
            strengths.append("Good balanced performance across all outcomes")
        
        if 'confidence_analysis' in report:
            conf_analysis = report['confidence_analysis']
            if conf_analysis['calibration_score'] < 0.1:
                strengths.append("Well-calibrated confidence scores")
        
        if 'temporal_performance' in report:
            temp_perf = report['temporal_performance']
            if isinstance(temp_perf, dict) and 'rolling_accuracy_trend' in temp_perf:
                recent_accuracy = temp_perf['rolling_accuracy_trend'][-10:] if temp_perf['rolling_accuracy_trend'] else []
                if recent_accuracy and np.mean([r['rolling_accuracy'] for r in recent_accuracy if r['rolling_accuracy']]) > 0.7:
                    strengths.append("Consistent recent performance")
        
        return strengths if strengths else ["Model shows potential for improvement"]
    
    def identify_model_weaknesses(self, report):
        """Identify model weaknesses from performance report"""
        
        weaknesses = []
        basic_metrics = report['basic_metrics']
        
        if basic_metrics['accuracy'] < 0.6:
            weaknesses.append("Below-average overall accuracy")
        
        # Check class imbalance issues
        if 'per_class_metrics' in basic_metrics:
            class_f1_scores = [basic_metrics['per_class_metrics'][str(i)]['f1-score'] 
                              for i in range(3) if str(i) in basic_metrics['per_class_metrics']]
            if max(class_f1_scores) - min(class_f1_scores) > 0.2:
                weaknesses.append("Imbalanced performance across outcome classes")
        
        if 'confidence_analysis' in report:
            conf_analysis = report['confidence_analysis']
            if conf_analysis['calibration_score'] > 0.2:
                weaknesses.append("Poorly calibrated confidence scores")
        
        return weaknesses if weaknesses else ["No significant weaknesses identified"]
    
    def generate_improvement_recommendations(self, report):
        """Generate recommendations for model improvement"""
        
        recommendations = []
        basic_metrics = report['basic_metrics']
        
        if basic_metrics['accuracy'] < 0.7:
            recommendations.append("Consider collecting more training data or feature engineering")
        
        if 'confidence_analysis' in report:
            conf_analysis = report['confidence_analysis']
            if conf_analysis['calibration_score'] > 0.15:
                recommendations.append("Implement confidence calibration techniques")
        
        # Check for class imbalance
        if 'per_class_metrics' in basic_metrics:
            class_supports = [basic_metrics['per_class_metrics'][str(i)]['support'] 
                             for i in range(3) if str(i) in basic_metrics['per_class_metrics']]
            if max(class_supports) / min(class_supports) > 3:
                recommendations.append("Address class imbalance in training data")
        
        if 'betting_performance' in report:
            betting_perf = report['betting_performance']
            if isinstance(betting_perf, dict):
                profitable_strategies = [k for k, v in betting_perf.items() 
                                       if isinstance(v, dict) and v.get('roi', 0) > 0]
                if not profitable_strategies:
                    recommendations.append("Focus on improving high-confidence predictions for betting applications")
        
        return recommendations if recommendations else ["Continue monitoring and regular retraining"]
    
    def compare_model_versions(self, model_reports):
        """Compare performance across different model versions"""
        
        if len(model_reports) < 2:
            return "Need at least 2 model reports for comparison"
        
        comparison = {}
        
        for i, report in enumerate(model_reports):
            version = f"Version_{i+1}"
            comparison[version] = {
                'accuracy': report['basic_metrics']['accuracy'],
                'f1_score': report['basic_metrics']['f1_macro'],
                'timestamp': report['timestamp'],
                'sample_size': report['sample_size']
            }
            
            if 'confidence_analysis' in report:
                comparison[version]['calibration_score'] = report['confidence_analysis']['calibration_score']
        
        # Identify best performing version
        best_version = max(comparison.keys(), key=lambda x: comparison[x]['accuracy'])
        
        comparison['summary'] = {
            'best_version': best_version,
            'best_accuracy': comparison[best_version]['accuracy'],
            'improvement_trend': self.calculate_improvement_trend(comparison)
        }
        
        return comparison
    
    def calculate_improvement_trend(self, comparison):
        """Calculate if model performance is improving over time"""
        
        versions = sorted(comparison.keys(), key=lambda x: comparison[x]['timestamp'] if x != 'summary' else datetime.min)
        versions = [v for v in versions if v != 'summary']
        
        if len(versions) < 2:
            return "Insufficient data"
        
        accuracies = [comparison[v]['accuracy'] for v in versions]
        
        # Simple trend calculation
        if accuracies[-1] > accuracies[0]:
            return "Improving"
        elif accuracies[-1] < accuracies[0]:
            return "Declining"
        else:
            return "Stable"

def create_performance_summary_table(evaluation_report):
    """Create a formatted summary table of performance metrics"""
    
    if not evaluation_report:
        return pd.DataFrame()
    
    basic_metrics = evaluation_report['basic_metrics']
    
    summary_data = {
        'Metric': ['Accuracy', 'Precision (Macro)', 'Recall (Macro)', 'F1-Score (Macro)'],
        'Value': [
            f"{basic_metrics['accuracy']:.3f}",
            f"{basic_metrics['precision_macro']:.3f}",
            f"{basic_metrics['recall_macro']:.3f}",
            f"{basic_metrics['f1_macro']:.3f}"
        ]
    }
    
    if 'brier_score' in basic_metrics:
        summary_data['Metric'].append('Brier Score')
        summary_data['Value'].append(f"{basic_metrics['brier_score']:.3f}")
    
    if 'log_loss' in basic_metrics:
        summary_data['Metric'].append('Log Loss')
        summary_data['Value'].append(f"{basic_metrics['log_loss']:.3f}")
    
    return pd.DataFrame(summary_data)
