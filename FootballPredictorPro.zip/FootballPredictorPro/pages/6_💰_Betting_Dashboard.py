import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

from models.betting_analytics import BettingAnalytics
from models.real_time_predictor import RealTimePredictionEngine
from utils.visualization import FootballVisualization
from utils.prediction_utils import PredictionUtils

# Page configuration
st.set_page_config(page_title="Betting Dashboard", page_icon="💰", layout="wide")

# Initialize components
@st.cache_resource
def initialize_betting_system():
    return BettingAnalytics(), RealTimePredictionEngine(), FootballVisualization(), PredictionUtils()

betting_analytics, realtime_engine, viz, predictor = initialize_betting_system()

# Page title and description
st.title("💰 Professional Betting Dashboard")
st.markdown("""
Advanced betting analytics dashboard with value detection, Kelly criterion optimization, 
portfolio management, and real-time market analysis for professional sports betting.
""")

# Sidebar for dashboard configuration
st.sidebar.header("⚙️ Dashboard Configuration")

# Portfolio settings
st.sidebar.subheader("💼 Portfolio Settings")
bankroll = st.sidebar.number_input("Total Bankroll ($)", min_value=100, max_value=100000, value=5000, step=500)
risk_tolerance = st.sidebar.selectbox("Risk Tolerance", ["Conservative", "Moderate", "Aggressive"])
kelly_fraction = st.sidebar.slider("Kelly Fraction", 0.1, 1.0, 0.25, 0.05)

# Betting preferences
st.sidebar.subheader("🎯 Betting Preferences")
min_edge = st.sidebar.slider("Minimum Edge (%)", 1, 20, 5)
min_confidence = st.sidebar.slider("Minimum Confidence", 0.5, 0.95, 0.7, 0.05)
max_bet_percentage = st.sidebar.slider("Max Bet % of Bankroll", 1, 15, 5)

# Market selection
st.sidebar.subheader("🏆 Market Selection")
selected_leagues = st.sidebar.multiselect(
    "Leagues to analyze",
    ["Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1", "Championship"],
    default=["Premier League", "La Liga"]
)

time_horizon = st.sidebar.selectbox("Analysis Period", ["Today", "This Week", "This Month"])

# Generate sample betting opportunities
@st.cache_data(ttl=300)  # Cache for 5 minutes
def generate_betting_opportunities():
    """Generate realistic betting opportunities for demonstration"""
    
    teams = [
        "Manchester City", "Liverpool", "Arsenal", "Chelsea", "Manchester United",
        "Barcelona", "Real Madrid", "Bayern Munich", "PSG", "Juventus"
    ]
    
    opportunities = []
    
    for i in range(15):  # Generate 15 matches
        home_team = np.random.choice(teams)
        away_team = np.random.choice([t for t in teams if t != home_team])
        
        # Generate realistic probabilities
        home_prob = np.random.uniform(0.25, 0.65)
        away_prob = np.random.uniform(0.25, 0.65)
        draw_prob = 1 - home_prob - away_prob
        
        # Normalize
        total = home_prob + draw_prob + away_prob
        home_prob /= total
        draw_prob /= total
        away_prob /= total
        
        # Generate market odds with some inefficiency
        home_fair_odds = 1 / home_prob
        draw_fair_odds = 1 / draw_prob
        away_fair_odds = 1 / away_prob
        
        # Add market margin and some randomness
        margin = np.random.uniform(0.05, 0.12)  # 5-12% margin
        
        home_market_odds = home_fair_odds * (1 + margin + np.random.uniform(-0.15, 0.15))
        draw_market_odds = draw_fair_odds * (1 + margin + np.random.uniform(-0.15, 0.15))
        away_market_odds = away_fair_odds * (1 + margin + np.random.uniform(-0.15, 0.15))
        
        match_data = {
            'match_info': f"{home_team} vs {away_team}",
            'home_team': home_team,
            'away_team': away_team,
            'match_date': datetime.now() + timedelta(days=np.random.randint(0, 7)),
            'league': np.random.choice(selected_leagues) if selected_leagues else "Premier League",
            'probabilities': {
                'home': home_prob,
                'draw': draw_prob,
                'away': away_prob
            },
            'market_odds': {
                'home': max(1.1, home_market_odds),
                'draw': max(1.1, draw_market_odds),
                'away': max(1.1, away_market_odds)
            },
            'confidence': np.random.uniform(0.6, 0.9)
        }
        
        opportunities.append(match_data)
    
    return opportunities

# Generate opportunities
betting_opportunities = generate_betting_opportunities()

# Calculate value bets
value_bets = betting_analytics.identify_value_bets(betting_opportunities)

# Filter based on user preferences
filtered_bets = [
    bet for bet in value_bets 
    if bet['edge'] >= min_edge/100 and bet['confidence'] >= min_confidence
]

# Calculate portfolio metrics
portfolio_metrics = betting_analytics.calculate_betting_portfolio_metrics(filtered_bets, bankroll)

# Main dashboard content
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Total Opportunities", 
        len(filtered_bets),
        delta=f"+{len(filtered_bets) - len(value_bets)//2}" if len(filtered_bets) > len(value_bets)//2 else None
    )

with col2:
    expected_roi = portfolio_metrics.get('expected_roi', 0)
    st.metric("Expected ROI", f"{expected_roi:.1f}%", delta=f"+{expected_roi-5:.1f}%" if expected_roi > 5 else None)

with col3:
    total_stake = portfolio_metrics.get('total_stake_percentage', 0)
    st.metric("Portfolio Exposure", f"{total_stake:.1f}%", delta="Safe" if total_stake < 10 else "High")

with col4:
    avg_edge = portfolio_metrics.get('average_edge', 0) * 100
    st.metric("Avg Edge", f"{avg_edge:.1f}%", delta=f"+{avg_edge-3:.1f}%" if avg_edge > 3 else None)

# Main dashboard tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🎯 Value Opportunities", 
    "📊 Portfolio Analysis", 
    "📈 Market Trends", 
    "⚖️ Risk Management", 
    "🔍 Research Tools"
])

with tab1:
    st.markdown("## 🎯 Current Value Betting Opportunities")
    
    if filtered_bets:
        st.success(f"✅ {len(filtered_bets)} value opportunities identified meeting your criteria")
        
        # Top opportunities table
        opportunities_data = []
        for bet in filtered_bets[:10]:  # Top 10
            opportunities_data.append({
                'Match': bet['match_info'],
                'Outcome': bet['outcome'].title(),
                'Edge': f"{bet['edge']:.1%}",
                'Market Odds': f"{bet['market_odds']:.2f}",
                'Fair Odds': f"{bet['fair_odds']:.2f}",
                'Kelly Stake': f"{bet['kelly_fraction']:.1%}",
                'Bet Amount': f"${bet['recommended_stake'] * bankroll:.0f}",
                'Expected Value': f"${bet['expected_value'] * bankroll:.0f}",
                'Confidence': f"{bet['confidence']:.0%}"
            })
        
        df = pd.DataFrame(opportunities_data)
        st.dataframe(df, hide_index=True, use_container_width=True)
        
        # Detailed analysis of top bet
        if filtered_bets:
            best_bet = max(filtered_bets, key=lambda x: x['expected_value'])
            
            st.markdown("### 🏆 Best Opportunity Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Match:** {best_bet['match_info']}")
                st.markdown(f"**Outcome:** {best_bet['outcome'].title()}")
                st.markdown(f"**Edge:** {best_bet['edge']:.1%}")
                st.markdown(f"**Confidence:** {best_bet['confidence']:.0%}")
            
            with col2:
                st.markdown(f"**Market Odds:** {best_bet['market_odds']:.2f}")
                st.markdown(f"**Fair Odds:** {best_bet['fair_odds']:.2f}")
                st.markdown(f"**Recommended Stake:** ${best_bet['recommended_stake'] * bankroll:.0f}")
                st.markdown(f"**Expected Profit:** ${best_bet['expected_value'] * bankroll:.0f}")
        
        # Edge distribution chart
        if len(filtered_bets) > 1:
            st.markdown("### 📊 Edge Distribution")
            
            edges = [bet['edge'] * 100 for bet in filtered_bets]
            
            fig = go.Figure(data=[go.Histogram(x=edges, nbinsx=10)])
            fig.update_layout(
                title="Distribution of Betting Edges",
                xaxis_title="Edge (%)",
                yaxis_title="Number of Opportunities",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    else:
        st.warning("⚠️ No value opportunities found matching your criteria")
        st.info("Try adjusting your minimum edge or confidence requirements")

with tab2:
    st.markdown("## 📊 Portfolio Analysis")
    
    if portfolio_metrics:
        # Portfolio overview
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 💼 Portfolio Overview")
            
            st.markdown(f"**Total Opportunities:** {portfolio_metrics.get('total_bets', 0)}")
            st.markdown(f"**Total Stake:** ${portfolio_metrics.get('total_stake_percentage', 0) * bankroll / 100:.0f}")
            st.markdown(f"**Expected Return:** ${portfolio_metrics.get('expected_roi', 0) * bankroll / 100:.0f}")
            st.markdown(f"**Sharpe Ratio:** {portfolio_metrics.get('sharpe_ratio', 0):.2f}")
        
        with col2:
            st.markdown("### ⚖️ Risk Assessment")
            
            max_single_bet = portfolio_metrics.get('max_single_bet', 0)
            if max_single_bet > 8:
                st.error(f"🚨 Largest bet: {max_single_bet:.1f}% - Consider reducing")
            elif max_single_bet > 5:
                st.warning(f"⚠️ Largest bet: {max_single_bet:.1f}% - Monitor closely")
            else:
                st.success(f"✅ Largest bet: {max_single_bet:.1f}% - Well controlled")
            
            total_exposure = portfolio_metrics.get('total_stake_percentage', 0)
            if total_exposure > 15:
                st.error(f"🚨 Total exposure: {total_exposure:.1f}% - High risk")
            elif total_exposure > 10:
                st.warning(f"⚠️ Total exposure: {total_exposure:.1f}% - Moderate risk")
            else:
                st.success(f"✅ Total exposure: {total_exposure:.1f}% - Conservative")
        
        # Outcome distribution
        outcome_dist = portfolio_metrics.get('outcome_distribution', {})
        if outcome_dist:
            st.markdown("### 🎲 Bet Distribution by Outcome")
            
            outcomes = list(outcome_dist.keys())
            stakes = list(outcome_dist.values())
            
            fig = go.Figure(data=[go.Pie(labels=outcomes, values=stakes, hole=0.3)])
            fig.update_layout(title="Portfolio Distribution by Bet Type", height=400)
            
            st.plotly_chart(fig, use_container_width=True)
    
    else:
        st.info("Generate some betting opportunities to see portfolio analysis")

with tab3:
    st.markdown("## 📈 Market Trends & Analysis")
    
    # Simulate market trends
    if filtered_bets:
        st.markdown("### 📊 Market Efficiency Analysis")
        
        # Calculate market margins
        margins = []
        for opportunity in betting_opportunities:
            odds = opportunity['market_odds']
            implied_total = sum(1/odd for odd in odds.values())
            margin = (implied_total - 1) * 100
            margins.append(margin)
        
        avg_margin = np.mean(margins)
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Average Market Margin", f"{avg_margin:.1f}%")
        
        with col2:
            efficient_markets = sum(1 for m in margins if m < 6)
            st.metric("Efficient Markets", f"{efficient_markets}/{len(margins)}")
        
        with col3:
            value_frequency = len(filtered_bets) / len(betting_opportunities) * 100
            st.metric("Value Frequency", f"{value_frequency:.1f}%")
        
        # Market margin distribution
        st.markdown("### 📊 Market Margin Distribution")
        
        fig = go.Figure(data=[go.Histogram(x=margins, nbinsx=15)])
        fig.update_layout(
            title="Distribution of Bookmaker Margins",
            xaxis_title="Margin (%)",
            yaxis_title="Number of Markets",
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # League comparison
        if len(selected_leagues) > 1:
            st.markdown("### 🏆 League Comparison")
            
            league_data = {}
            for opportunity in betting_opportunities:
                league = opportunity['league']
                if league not in league_data:
                    league_data[league] = {'opportunities': 0, 'value_bets': 0}
                league_data[league]['opportunities'] += 1
            
            for bet in filtered_bets:
                # Find league for this bet
                for opp in betting_opportunities:
                    if bet['match_info'] == opp['match_info']:
                        league = opp['league']
                        league_data[league]['value_bets'] += 1
                        break
            
            league_comparison = []
            for league, data in league_data.items():
                value_rate = data['value_bets'] / data['opportunities'] * 100 if data['opportunities'] > 0 else 0
                league_comparison.append({
                    'League': league,
                    'Total Matches': data['opportunities'],
                    'Value Bets': data['value_bets'],
                    'Value Rate (%)': f"{value_rate:.1f}%"
                })
            
            st.dataframe(pd.DataFrame(league_comparison), hide_index=True, use_container_width=True)

with tab4:
    st.markdown("## ⚖️ Risk Management")
    
    # Risk metrics and warnings
    st.markdown("### 🚨 Risk Monitoring")
    
    risk_checks = []
    
    # Check portfolio concentration
    total_exposure = portfolio_metrics.get('total_stake_percentage', 0)
    if total_exposure > 15:
        risk_checks.append({
            'type': 'error',
            'title': 'High Portfolio Exposure',
            'message': f'Total exposure of {total_exposure:.1f}% exceeds recommended maximum of 15%'
        })
    elif total_exposure > 10:
        risk_checks.append({
            'type': 'warning',
            'title': 'Moderate Portfolio Exposure',
            'message': f'Total exposure of {total_exposure:.1f}% is above conservative threshold of 10%'
        })
    else:
        risk_checks.append({
            'type': 'success',
            'title': 'Safe Portfolio Exposure',
            'message': f'Total exposure of {total_exposure:.1f}% is within safe limits'
        })
    
    # Check bet sizing
    max_bet = portfolio_metrics.get('max_single_bet', 0)
    if max_bet > 8:
        risk_checks.append({
            'type': 'error',
            'title': 'Large Single Bet',
            'message': f'Largest single bet of {max_bet:.1f}% exceeds recommended maximum of 8%'
        })
    
    # Check diversification
    outcome_dist = portfolio_metrics.get('outcome_distribution', {})
    if outcome_dist:
        max_outcome_concentration = max(outcome_dist.values()) / sum(outcome_dist.values()) * 100
        if max_outcome_concentration > 70:
            risk_checks.append({
                'type': 'warning',
                'title': 'Poor Diversification',
                'message': f'Over-concentration in single outcome type ({max_outcome_concentration:.1f}%)'
            })
    
    # Display risk checks
    for check in risk_checks:
        if check['type'] == 'error':
            st.error(f"🚨 **{check['title']}:** {check['message']}")
        elif check['type'] == 'warning':
            st.warning(f"⚠️ **{check['title']}:** {check['message']}")
        else:
            st.success(f"✅ **{check['title']}:** {check['message']}")
    
    # Kelly criterion optimization
    st.markdown("### 🎯 Kelly Criterion Optimization")
    
    if filtered_bets:
        st.markdown("**Current Kelly Recommendations:**")
        
        total_kelly = sum(bet['kelly_fraction'] for bet in filtered_bets)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Total Kelly %", f"{total_kelly:.1%}")
            st.metric("Number of Bets", len(filtered_bets))
        
        with col2:
            avg_kelly = total_kelly / len(filtered_bets) if filtered_bets else 0
            st.metric("Average Kelly %", f"{avg_kelly:.1%}")
            
            if total_kelly > 0.3:
                st.warning("⚠️ High total Kelly - consider reducing bet sizes")
            else:
                st.success("✅ Kelly allocation within safe limits")

with tab5:
    st.markdown("## 🔍 Research & Analysis Tools")
    
    # Match analysis tool
    st.markdown("### 🔬 Individual Match Analysis")
    
    if betting_opportunities:
        selected_match = st.selectbox(
            "Select match to analyze",
            [opp['match_info'] for opp in betting_opportunities]
        )
        
        # Find selected match data
        selected_data = next(opp for opp in betting_opportunities if opp['match_info'] == selected_match)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Match Details**")
            st.markdown(f"**Teams:** {selected_data['match_info']}")
            st.markdown(f"**League:** {selected_data['league']}")
            st.markdown(f"**Date:** {selected_data['match_date'].strftime('%Y-%m-%d')}")
            st.markdown(f"**Confidence:** {selected_data['confidence']:.0%}")
        
        with col2:
            st.markdown("**Probability Analysis**")
            probs = selected_data['probabilities']
            st.markdown(f"**Home Win:** {probs['home']:.1%}")
            st.markdown(f"**Draw:** {probs['draw']:.1%}")
            st.markdown(f"**Away Win:** {probs['away']:.1%}")
        
        # Value analysis for this match
        betting_value = betting_analytics.calculate_betting_value(
            selected_data['probabilities'],
            selected_data['market_odds']
        )
        
        if betting_value:
            st.markdown("### 💰 Value Analysis")
            
            value_data = []
            for outcome in ['home', 'draw', 'away']:
                edge = betting_value['edges'][outcome]
                kelly = betting_value['kelly_fractions'][outcome]
                
                value_data.append({
                    'Outcome': outcome.title(),
                    'Model Prob': f"{selected_data['probabilities'][outcome]:.1%}",
                    'Market Odds': f"{selected_data['market_odds'][outcome]:.2f}",
                    'Fair Odds': f"{betting_value['fair_odds'][outcome]:.2f}",
                    'Edge': f"{edge:.1%}",
                    'Kelly %': f"{kelly:.1%}",
                    'Value': "✅" if edge > min_edge/100 else "❌"
                })
            
            st.dataframe(pd.DataFrame(value_data), hide_index=True, use_container_width=True)
    
    # Quick calculator
    st.markdown("### 🧮 Quick Betting Calculator")
    
    calc_col1, calc_col2 = st.columns(2)
    
    with calc_col1:
        true_prob = st.number_input("True Probability", 0.01, 0.99, 0.60, 0.01)
        market_odds = st.number_input("Market Odds", 1.01, 10.0, 2.50, 0.01)
    
    with calc_col2:
        implied_prob = 1 / market_odds
        edge = true_prob - implied_prob
        kelly_calc = max(0, (market_odds * true_prob - 1) / (market_odds - 1) * kelly_fraction)
        
        st.metric("Implied Probability", f"{implied_prob:.1%}")
        st.metric("Edge", f"{edge:.1%}")
        st.metric("Kelly Stake", f"{kelly_calc:.1%}")
        
        if edge > 0.05:
            st.success("✅ Positive value detected!")
        else:
            st.info("ℹ️ No significant edge")

# Footer with disclaimer
st.markdown("---")
st.markdown("""
**⚠️ Important Disclaimer:** This dashboard is for educational and analytical purposes only. 
Always gamble responsibly and never bet more than you can afford to lose. 
Past performance does not guarantee future results.
""")

# Session state for tracking
if 'betting_session_active' not in st.session_state:
    st.session_state.betting_session_active = True