import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

from utils.model_evaluation import ModelEvaluator, create_performance_summary_table
from utils.visualization import FootballVisualization
from models.model_trainer import ModelTrainer
from data.data_collector import FootballDataCollector

# Page configuration
st.set_page_config(page_title="Performance Analysis", page_icon="📈", layout="wide")

# Initialize components
@st.cache_resource
def initialize_analysis_system():
    return ModelEvaluator(), FootballVisualization(), ModelTrainer(), FootballDataCollector()

evaluator, viz, trainer, data_collector = initialize_analysis_system()

# Page title and description
st.title("📈 Performance Analysis & Model Evaluation")
st.markdown("""
Comprehensive analysis of model performance across different metrics, time periods, and conditions.
Monitor accuracy trends, identify strengths and weaknesses, and optimize model performance.
""")

# Sidebar for analysis configuration
st.sidebar.header("⚙️ Analysis Configuration")

# Analysis scope
st.sidebar.subheader("📊 Analysis Scope")
analysis_period = st.sidebar.selectbox(
    "Analysis period",
    ["Last 30 days", "Last 90 days", "Last 6 months", "Last year", "All time"]
)

min_confidence = st.sidebar.slider("Minimum confidence threshold", 0.0, 1.0, 0.5)
leagues_filter = st.sidebar.multiselect(
    "Filter by leagues",
    ["Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"],
    default=["Premier League"]
)

# Performance metrics selection
st.sidebar.subheader("📋 Metrics")
show_accuracy = st.sidebar.checkbox("Accuracy metrics", value=True)
show_calibration = st.sidebar.checkbox("Calibration analysis", value=True)
show_betting = st.sidebar.checkbox("Betting performance", value=True)
show_temporal = st.sidebar.checkbox("Temporal analysis", value=True)

# Main content area
tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Overview", "🎯 Accuracy Analysis", "📉 Calibration", "💰 Betting Performance", "📅 Temporal Trends"])

with tab1:
    st.markdown("## 📊 Performance Overview")
    
    # Generate or load performance data
    if st.button("🔄 Refresh Performance Data", type="primary"):
        with st.spinner("Analyzing model performance..."):
            
            # Generate sample performance data for demonstration
            # In a real system, this would load actual prediction results
            
            sample_size = 1000
            
            # Simulate prediction results
            y_true = np.random.choice([0, 1, 2], sample_size, p=[0.45, 0.3, 0.25])  # Home, Draw, Away
            y_pred = np.random.choice([0, 1, 2], sample_size, p=[0.45, 0.3, 0.25])
            
            # Add some correlation between true and predicted
            correlation_factor = 0.7
            for i in range(sample_size):
                if np.random.random() < correlation_factor:
                    y_pred[i] = y_true[i]
            
            # Generate probability predictions
            y_proba = np.random.dirichlet([2, 1, 2], sample_size)  # Slightly favor home/away
            
            # Create comprehensive evaluation
            evaluation_report = evaluator.generate_performance_report(y_true, y_pred, y_proba)
            
            st.success("✅ Performance analysis completed!")
            
            # Store results in session state
            st.session_state.performance_report = evaluation_report
            st.session_state.y_true = y_true
            st.session_state.y_pred = y_pred
            st.session_state.y_proba = y_proba
    
    # Display performance overview if data exists
    if 'performance_report' in st.session_state:
        report = st.session_state.performance_report
        
        # Key performance indicators
        st.markdown("### 🎯 Key Performance Indicators")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        basic_metrics = report['basic_metrics']
        
        with col1:
            st.metric(
                "Overall Accuracy",
                f"{basic_metrics['accuracy']:.3f}",
                delta=f"+{(basic_metrics['accuracy'] - 0.6):.3f}" if basic_metrics['accuracy'] > 0.6 else f"{(basic_metrics['accuracy'] - 0.6):.3f}"
            )
        
        with col2:
            st.metric(
                "Precision (Macro)",
                f"{basic_metrics['precision_macro']:.3f}",
                delta=None
            )
        
        with col3:
            st.metric(
                "Recall (Macro)",
                f"{basic_metrics['recall_macro']:.3f}",
                delta=None
            )
        
        with col4:
            st.metric(
                "F1-Score (Macro)",
                f"{basic_metrics['f1_macro']:.3f}",
                delta=None
            )
        
        with col5:
            if 'brier_score' in basic_metrics:
                st.metric(
                    "Brier Score",
                    f"{basic_metrics['brier_score']:.3f}",
                    delta=f"{(0.25 - basic_metrics['brier_score']):.3f}"  # Lower is better
                )
        
        # Performance grade
        perf_summary = report['performance_summary']
        grade = perf_summary['grade']
        
        grade_colors = {
            'Excellent': '🟢',
            'Good': '🟡',
            'Fair': '🟠',
            'Poor': '🔴'
        }
        
        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            text-align: center;
            margin: 1rem 0;
        ">
            <h3 style="margin: 0;">{grade_colors.get(grade, '⚪')} Performance Grade: {grade}</h3>
            <p style="margin: 0.5rem 0 0 0;">Based on comprehensive evaluation metrics</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Confusion Matrix
        st.markdown("### 📊 Confusion Matrix")
        
        if 'confusion_matrix' in basic_metrics:
            cm_chart = viz.create_confusion_matrix(basic_metrics['confusion_matrix'])
            st.plotly_chart(cm_chart, use_container_width=True)
        
        # Performance summary table
        st.markdown("### 📋 Detailed Metrics")
        
        summary_table = create_performance_summary_table(report)
        if not summary_table.empty:
            st.dataframe(summary_table, hide_index=True, use_container_width=True)
        
        # Strengths and Weaknesses
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 💪 Model Strengths")
            strengths = perf_summary.get('strengths', [])
            for strength in strengths:
                st.markdown(f"• {strength}")
            
            if not strengths:
                st.info("No specific strengths identified.")
        
        with col2:
            st.markdown("#### ⚠️ Areas for Improvement")
            weaknesses = perf_summary.get('weaknesses', [])
            for weakness in weaknesses:
                st.markdown(f"• {weakness}")
            
            if not weaknesses:
                st.success("No significant weaknesses identified!")
        
        # Recommendations
        st.markdown("#### 💡 Recommendations")
        recommendations = perf_summary.get('recommendations', [])
        for rec in recommendations:
            st.markdown(f"• {rec}")
    
    else:
        st.info("👆 Click 'Refresh Performance Data' to generate analysis")

with tab2:
    st.markdown("## 🎯 Accuracy Analysis")
    
    if 'performance_report' in st.session_state:
        report = st.session_state.performance_report
        
        # Per-class performance
        st.markdown("### 📊 Per-Class Performance")
        
        if 'per_class_metrics' in report['basic_metrics']:
            class_metrics = report['basic_metrics']['per_class_metrics']
            
            # Create per-class visualization
            class_names = ['Home Win', 'Draw', 'Away Win']
            
            precision_scores = []
            recall_scores = []
            f1_scores = []
            support_counts = []
            
            for i in range(3):
                if str(i) in class_metrics:
                    metrics = class_metrics[str(i)]
                    precision_scores.append(metrics['precision'])
                    recall_scores.append(metrics['recall'])
                    f1_scores.append(metrics['f1-score'])
                    support_counts.append(metrics['support'])
                else:
                    precision_scores.append(0)
                    recall_scores.append(0)
                    f1_scores.append(0)
                    support_counts.append(0)
            
            # Per-class metrics chart
            fig = go.Figure()
            
            fig.add_trace(go.Bar(
                name='Precision',
                x=class_names,
                y=precision_scores,
                marker_color='#FF6B6B'
            ))
            
            fig.add_trace(go.Bar(
                name='Recall',
                x=class_names,
                y=recall_scores,
                marker_color='#4ECDC4'
            ))
            
            fig.add_trace(go.Bar(
                name='F1-Score',
                x=class_names,
                y=f1_scores,
                marker_color='#45B7D1'
            ))
            
            fig.update_layout(
                title='Per-Class Performance Metrics',
                barmode='group',
                yaxis_title='Score',
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Support distribution
            st.markdown("### 📈 Class Distribution")
            
            fig_support = go.Figure(data=[
                go.Pie(
                    labels=class_names,
                    values=support_counts,
                    hole=0.3
                )
            ])
            
            fig_support.update_layout(
                title='Distribution of Actual Outcomes',
                height=400
            )
            
            st.plotly_chart(fig_support, use_container_width=True)
        
        # Accuracy by confidence level
        if 'confidence_analysis' in report:
            st.markdown("### 🎯 Accuracy by Confidence Level")
            
            conf_analysis = report['confidence_analysis']
            confidence_bins = conf_analysis['confidence_bins']
            
            # Extract data for visualization
            bin_names = list(confidence_bins.keys())
            accuracies = [conf_analysis['confidence_bins'][bin_name]['accuracy'] for bin_name in bin_names]
            counts = [conf_analysis['confidence_bins'][bin_name]['count'] for bin_name in bin_names]
            
            # Create subplot for accuracy and count
            fig = make_subplots(
                rows=1, cols=2,
                subplot_titles=('Accuracy by Confidence', 'Prediction Count by Confidence'),
                specs=[[{"secondary_y": False}, {"secondary_y": False}]]
            )
            
            fig.add_trace(
                go.Bar(x=bin_names, y=accuracies, name='Accuracy', marker_color='#FF6B6B'),
                row=1, col=1
            )
            
            fig.add_trace(
                go.Bar(x=bin_names, y=counts, name='Count', marker_color='#4ECDC4'),
                row=1, col=2
            )
            
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
            
            # Confidence metrics table
            conf_df = pd.DataFrame([
                {
                    'Confidence Range': bin_name,
                    'Accuracy': f"{data['accuracy']:.3f}",
                    'Count': data['count'],
                    'Percentage': f"{data['percentage_of_predictions']:.1%}"
                }
                for bin_name, data in confidence_bins.items()
            ])
            
            st.dataframe(conf_df, hide_index=True, use_container_width=True)
    
    else:
        st.info("No performance data available. Please generate analysis first.")

with tab3:
    st.markdown("## 📉 Model Calibration Analysis")
    
    if 'performance_report' in st.session_state and 'confidence_analysis' in st.session_state.performance_report:
        conf_analysis = st.session_state.performance_report['confidence_analysis']
        
        # Calibration score
        calibration_score = conf_analysis.get('calibration_score', 0)
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Calibration Score", f"{calibration_score:.3f}")
        
        with col2:
            st.metric("Average Confidence", f"{conf_analysis.get('overall_avg_confidence', 0):.3f}")
        
        with col3:
            st.metric("Confidence Std", f"{conf_analysis.get('confidence_std', 0):.3f}")
        
        # Calibration interpretation
        if calibration_score < 0.05:
            st.success("🎯 **Excellent calibration** - Model confidence closely matches actual accuracy")
        elif calibration_score < 0.1:
            st.info("📊 **Good calibration** - Model confidence is reasonably well-calibrated")
        elif calibration_score < 0.2:
            st.warning("⚠️ **Fair calibration** - Some miscalibration present")
        else:
            st.error("❌ **Poor calibration** - Model confidence does not match actual performance")
        
        # Reliability diagram
        st.markdown("### 📈 Reliability Diagram")
        
        # Create reliability diagram
        confidence_bins = conf_analysis['confidence_bins']
        bin_centers = []
        bin_accuracies = []
        bin_counts = []
        
        for bin_name, data in confidence_bins.items():
            # Extract numeric range from bin name
            if 'Low' in bin_name:
                bin_center = 0.25
            elif 'Medium' in bin_name:
                bin_center = 0.6
            elif 'High' in bin_name and 'Very' not in bin_name:
                bin_center = 0.775
            else:  # Very High
                bin_center = 0.925
            
            bin_centers.append(bin_center)
            bin_accuracies.append(data['accuracy'])
            bin_counts.append(data['count'])
        
        # Create reliability diagram
        fig = go.Figure()
        
        # Perfect calibration line
        fig.add_trace(go.Scatter(
            x=[0, 1],
            y=[0, 1],
            mode='lines',
            name='Perfect Calibration',
            line=dict(dash='dash', color='gray'),
        ))
        
        # Actual calibration
        fig.add_trace(go.Scatter(
            x=bin_centers,
            y=bin_accuracies,
            mode='markers+lines',
            name='Model Calibration',
            marker=dict(size=np.array(bin_counts)/max(bin_counts)*30 + 5),
            line=dict(color='#FF6B6B'),
        ))
        
        fig.update_layout(
            title='Reliability Diagram',
            xaxis_title='Mean Predicted Probability',
            yaxis_title='Fraction of Positives',
            height=400,
            showlegend=True
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Calibration tips
        st.markdown("### 💡 Calibration Improvement Tips")
        
        if calibration_score > 0.1:
            st.markdown("""
            **Improve Model Calibration:**
            - Use Platt scaling or isotonic regression for post-hoc calibration
            - Increase training data diversity
            - Adjust ensemble weights based on calibration performance
            - Consider temperature scaling for neural network components
            """)
        else:
            st.success("✅ Model is well-calibrated. No immediate action needed.")
    
    else:
        st.info("Calibration analysis requires confidence data. Please generate performance analysis first.")

with tab4:
    st.markdown("## 💰 Betting Performance Analysis")
    
    if 'performance_report' in st.session_state:
        st.markdown("### 🎯 Simulated Betting Performance")
        
        # Generate simulated betting data
        n_bets = 500
        
        # Simulate betting scenarios
        np.random.seed(42)  # For consistent results
        
        confidence_levels = np.random.uniform(0.4, 0.95, n_bets)
        bet_outcomes = np.random.choice([1, 0], n_bets, p=[0.7, 0.3])  # 70% win rate for demo
        bet_odds = np.random.uniform(1.5, 3.5, n_bets)
        bet_stakes = np.random.uniform(10, 100, n_bets)
        
        # Calculate profits
        profits = np.where(bet_outcomes == 1, bet_stakes * (bet_odds - 1), -bet_stakes)
        
        # Create betting performance DataFrame
        betting_df = pd.DataFrame({
            'confidence': confidence_levels,
            'outcome': bet_outcomes,
            'odds': bet_odds,
            'stake': bet_stakes,
            'profit': profits
        })
        
        # Overall betting metrics
        col1, col2, col3, col4 = st.columns(4)
        
        total_profit = betting_df['profit'].sum()
        total_stakes = betting_df['stake'].sum()
        roi = (total_profit / total_stakes) * 100
        win_rate = betting_df['outcome'].mean()
        
        with col1:
            st.metric("Total Profit", f"${total_profit:.2f}")
        
        with col2:
            st.metric("ROI", f"{roi:.1f}%")
        
        with col3:
            st.metric("Win Rate", f"{win_rate:.1%}")
        
        with col4:
            st.metric("Total Bets", len(betting_df))
        
        # Performance by confidence threshold
        st.markdown("### 📊 Performance by Confidence Threshold")
        
        thresholds = [0.5, 0.6, 0.7, 0.8, 0.9]
        threshold_results = []
        
        for threshold in thresholds:
            high_conf_bets = betting_df[betting_df['confidence'] >= threshold]
            
            if len(high_conf_bets) > 0:
                threshold_profit = high_conf_bets['profit'].sum()
                threshold_stakes = high_conf_bets['stake'].sum()
                threshold_roi = (threshold_profit / threshold_stakes) * 100
                threshold_win_rate = high_conf_bets['outcome'].mean()
                threshold_count = len(high_conf_bets)
                
                threshold_results.append({
                    'Threshold': f"{threshold:.1f}",
                    'Bets': threshold_count,
                    'Win Rate': f"{threshold_win_rate:.1%}",
                    'Profit': f"${threshold_profit:.2f}",
                    'ROI': f"{threshold_roi:.1f}%"
                })
        
        threshold_df = pd.DataFrame(threshold_results)
        st.dataframe(threshold_df, hide_index=True, use_container_width=True)
        
        # Profit curve over time
        st.markdown("### 📈 Cumulative Profit Curve")
        
        # Simulate time series
        betting_df['cumulative_profit'] = betting_df['profit'].cumsum()
        betting_df['bet_number'] = range(1, len(betting_df) + 1)
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=betting_df['bet_number'],
            y=betting_df['cumulative_profit'],
            mode='lines',
            name='Cumulative Profit',
            line=dict(color='#FF6B6B', width=2)
        ))
        
        # Add zero line
        fig.add_hline(y=0, line_dash="dash", line_color="gray")
        
        fig.update_layout(
            title='Cumulative Profit Over Time',
            xaxis_title='Bet Number',
            yaxis_title='Cumulative Profit ($)',
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Risk analysis
        st.markdown("### ⚠️ Risk Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Drawdown analysis
            running_max = betting_df['cumulative_profit'].cummax()
            drawdown = betting_df['cumulative_profit'] - running_max
            max_drawdown = drawdown.min()
            
            st.metric("Maximum Drawdown", f"${max_drawdown:.2f}")
            
            # Volatility
            profit_volatility = betting_df['profit'].std()
            st.metric("Profit Volatility", f"${profit_volatility:.2f}")
        
        with col2:
            # Winning/losing streaks
            betting_df['streak'] = (betting_df['outcome'] != betting_df['outcome'].shift()).cumsum()
            streak_analysis = betting_df.groupby('streak')['outcome'].agg(['first', 'count'])
            
            win_streaks = streak_analysis[streak_analysis['first'] == 1]['count']
            lose_streaks = streak_analysis[streak_analysis['first'] == 0]['count']
            
            longest_win_streak = win_streaks.max() if len(win_streaks) > 0 else 0
            longest_lose_streak = lose_streaks.max() if len(lose_streaks) > 0 else 0
            
            st.metric("Longest Win Streak", longest_win_streak)
            st.metric("Longest Lose Streak", longest_lose_streak)
        
        # Betting strategy recommendations
        st.markdown("### 💡 Strategy Recommendations")
        
        if roi > 10:
            st.success("✅ **Excellent performance** - Continue current strategy")
        elif roi > 5:
            st.info("📊 **Good performance** - Consider increasing stake sizes")
        elif roi > 0:
            st.warning("⚠️ **Break-even performance** - Review betting criteria")
        else:
            st.error("❌ **Loss-making** - Revise strategy or reduce stakes")
        
        # Risk management tips
        st.markdown("""
        **Risk Management Tips:**
        - Only bet with high confidence predictions (>70%)
        - Limit individual bet size to 1-2% of bankroll
        - Set stop-loss limits for daily/weekly losses
        - Track performance and adjust strategy based on results
        - Never chase losses with larger bets
        """)
    
    else:
        st.info("Betting analysis requires performance data. Please generate analysis first.")

with tab5:
    st.markdown("## 📅 Temporal Performance Trends")
    
    # Generate temporal performance data
    if st.button("📊 Generate Temporal Analysis"):
        with st.spinner("Analyzing performance trends over time..."):
            
            # Generate time series data
            start_date = datetime.now() - timedelta(days=365)
            date_range = pd.date_range(start=start_date, end=datetime.now(), freq='D')
            
            # Simulate daily performance
            np.random.seed(42)
            daily_accuracy = 0.65 + 0.1 * np.sin(np.arange(len(date_range)) * 2 * np.pi / 365) + np.random.normal(0, 0.05, len(date_range))
            daily_accuracy = np.clip(daily_accuracy, 0.4, 0.9)
            
            daily_predictions = np.random.poisson(8, len(date_range))  # Average 8 predictions per day
            
            temporal_df = pd.DataFrame({
                'date': date_range,
                'accuracy': daily_accuracy,
                'predictions': daily_predictions,
                'month': date_range.month,
                'day_of_week': date_range.dayofweek
            })
            
            st.success("✅ Temporal analysis completed!")
            st.session_state.temporal_data = temporal_df
    
    if 'temporal_data' in st.session_state:
        temporal_df = st.session_state.temporal_data
        
        # Overall trend
        st.markdown("### 📈 Accuracy Trend Over Time")
        
        fig = go.Figure()
        
        # Daily accuracy (smoothed)
        fig.add_trace(go.Scatter(
            x=temporal_df['date'],
            y=temporal_df['accuracy'].rolling(window=7).mean(),
            mode='lines',
            name='7-Day Moving Average',
            line=dict(color='#FF6B6B', width=2)
        ))
        
        # Monthly accuracy
        monthly_accuracy = temporal_df.groupby(temporal_df['date'].dt.to_period('M'))['accuracy'].mean()
        
        fig.add_trace(go.Scatter(
            x=[period.to_timestamp() for period in monthly_accuracy.index],
            y=monthly_accuracy.values,
            mode='markers+lines',
            name='Monthly Average',
            marker=dict(size=8, color='#4ECDC4'),
            line=dict(color='#4ECDC4', width=1)
        ))
        
        fig.update_layout(
            title='Model Accuracy Over Time',
            xaxis_title='Date',
            yaxis_title='Accuracy',
            height=400,
            showlegend=True
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Seasonal analysis
        st.markdown("### 🍂 Seasonal Performance Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Monthly performance
            monthly_performance = temporal_df.groupby('month')['accuracy'].agg(['mean', 'std']).reset_index()
            monthly_performance['month_name'] = pd.to_datetime(monthly_performance['month'], format='%m').dt.strftime('%B')
            
            fig_monthly = go.Figure()
            
            fig_monthly.add_trace(go.Bar(
                x=monthly_performance['month_name'],
                y=monthly_performance['mean'],
                error_y=dict(type='data', array=monthly_performance['std']),
                marker_color='#45B7D1',
                name='Monthly Accuracy'
            ))
            
            fig_monthly.update_layout(
                title='Performance by Month',
                xaxis_title='Month',
                yaxis_title='Average Accuracy',
                height=400
            )
            
            st.plotly_chart(fig_monthly, use_container_width=True)
        
        with col2:
            # Day of week analysis
            dow_performance = temporal_df.groupby('day_of_week')['accuracy'].agg(['mean', 'std']).reset_index()
            dow_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            dow_performance['day_name'] = [dow_names[i] for i in dow_performance['day_of_week']]
            
            fig_dow = go.Figure()
            
            fig_dow.add_trace(go.Bar(
                x=dow_performance['day_name'],
                y=dow_performance['mean'],
                error_y=dict(type='data', array=dow_performance['std']),
                marker_color='#FFA07A',
                name='Daily Accuracy'
            ))
            
            fig_dow.update_layout(
                title='Performance by Day of Week',
                xaxis_title='Day',
                yaxis_title='Average Accuracy',
                height=400
            )
            
            st.plotly_chart(fig_dow, use_container_width=True)
        
        # Performance statistics
        st.markdown("### 📊 Temporal Statistics")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            best_month = monthly_performance.loc[monthly_performance['mean'].idxmax(), 'month_name']
            best_accuracy = monthly_performance['mean'].max()
            st.metric("Best Month", f"{best_month} ({best_accuracy:.3f})")
        
        with col2:
            worst_month = monthly_performance.loc[monthly_performance['mean'].idxmin(), 'month_name']
            worst_accuracy = monthly_performance['mean'].min()
            st.metric("Worst Month", f"{worst_month} ({worst_accuracy:.3f})")
        
        with col3:
            best_day = dow_performance.loc[dow_performance['mean'].idxmax(), 'day_name']
            best_day_accuracy = dow_performance['mean'].max()
            st.metric("Best Day", f"{best_day} ({best_day_accuracy:.3f})")
        
        with col4:
            trend_slope = np.polyfit(range(len(temporal_df)), temporal_df['accuracy'], 1)[0]
            trend_direction = "Improving" if trend_slope > 0 else "Declining" if trend_slope < 0 else "Stable"
            st.metric("Overall Trend", trend_direction)
        
        # Recent performance
        st.markdown("### 📅 Recent Performance (Last 30 Days)")
        
        recent_data = temporal_df.tail(30)
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            recent_avg = recent_data['accuracy'].mean()
            overall_avg = temporal_df['accuracy'].mean()
            st.metric(
                "Recent Average",
                f"{recent_avg:.3f}",
                delta=f"{recent_avg - overall_avg:+.3f}"
            )
        
        with col2:
            recent_best = recent_data['accuracy'].max()
            st.metric("Recent Best", f"{recent_best:.3f}")
        
        with col3:
            recent_consistency = 1 - recent_data['accuracy'].std()
            st.metric("Consistency", f"{recent_consistency:.3f}")
    
    else:
        st.info("👆 Click 'Generate Temporal Analysis' to view performance trends")

# Footer with analysis tips
st.markdown("---")
st.markdown("""
<div style="background: #f0f2f6; padding: 1rem; border-radius: 10px; margin-top: 2rem;">
    <h4>💡 Performance Analysis Tips</h4>
    <ul>
        <li><strong>Regular Monitoring:</strong> Check performance metrics weekly to catch issues early</li>
        <li><strong>Confidence Calibration:</strong> Well-calibrated models have confidence that matches accuracy</li>
        <li><strong>Temporal Patterns:</strong> Look for seasonal or cyclical performance patterns</li>
        <li><strong>Betting Strategy:</strong> Only bet on high-confidence predictions with positive expected value</li>
        <li><strong>Continuous Improvement:</strong> Use performance insights to guide model improvements</li>
        <li><strong>Risk Management:</strong> Monitor drawdowns and volatility for betting applications</li>
    </ul>
</div>
""", unsafe_allow_html=True)
