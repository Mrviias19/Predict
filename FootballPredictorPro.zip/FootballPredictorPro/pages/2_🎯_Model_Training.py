import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
import time
import io

from models.model_trainer import ModelTrainer
from models.ensemble_model import FootballPredictionEnsemble
from data.data_collector import FootballDataCollector
from utils.visualization import FootballVisualization
from utils.model_evaluation import ModelEvaluator

# Page configuration
st.set_page_config(page_title="Model Training", page_icon="🎯", layout="wide")

# Initialize components
@st.cache_resource
def initialize_training_system():
    return ModelTrainer(), FootballDataCollector(), FootballVisualization(), ModelEvaluator()

trainer, data_collector, viz, evaluator = initialize_training_system()

# Page title and description
st.title("🎯 Model Training & Optimization")
st.markdown("""
Train and optimize the football prediction ensemble model with comprehensive data and advanced hyperparameter tuning.
Monitor training progress, evaluate performance, and compare different model configurations.
""")

# Sidebar for training configuration
st.sidebar.header("🔧 Training Configuration")

# Training data settings
st.sidebar.subheader("📊 Training Data")
n_matches = st.sidebar.slider("Number of training matches", 500, 5000, 2000, 250)
train_test_split = st.sidebar.slider("Training/Test split", 0.6, 0.9, 0.8, 0.05)

# Model configuration
st.sidebar.subheader("🤖 Model Settings")
optimize_hyperparams = st.sidebar.checkbox("Enable hyperparameter optimization", value=True)
n_optimization_trials = st.sidebar.slider("Optimization trials", 10, 100, 50, 10) if optimize_hyperparams else 0

# Advanced settings
with st.sidebar.expander("⚙️ Advanced Settings"):
    cross_validation_folds = st.sidebar.slider("CV folds", 3, 10, 5)
    random_state = st.sidebar.number_input("Random state", 0, 1000, 42)
    enable_early_stopping = st.sidebar.checkbox("Enable early stopping", value=True)

# Training execution
training_section = st.container()

with training_section:
    
    # Training status
    if 'training_in_progress' not in st.session_state:
        st.session_state.training_in_progress = False
    
    if 'training_completed' not in st.session_state:
        st.session_state.training_completed = False
    
    # Training interface
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        if st.button("🚀 Start Model Training", type="primary", disabled=st.session_state.training_in_progress):
            st.session_state.training_in_progress = True
            st.session_state.training_completed = False
            st.rerun()
    
    with col2:
        if st.button("📊 Load Existing Model"):
            try:
                trainer.load_training_session('models/trained_model.pkl')
                st.success("✅ Model loaded successfully!")
                st.session_state.training_completed = True
            except Exception as e:
                st.error(f"❌ Failed to load model: {e}")
    
    with col3:
        if st.button("🗑️ Clear Training"):
            for key in ['training_in_progress', 'training_completed', 'training_results']:
                if key in st.session_state:
                    del st.session_state[key]
            st.success("Training session cleared")
            st.rerun()

# Training execution
if st.session_state.training_in_progress:
    
    st.markdown("## 🔄 Training in Progress")
    
    # Progress indicators
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    try:
        # Step 1: Data Generation
        status_text.text("Step 1/5: Generating training data...")
        progress_bar.progress(10)
        
        training_data = data_collector.generate_sample_data(n_matches=n_matches)
        
        status_text.text("Step 2/5: Preparing features...")
        progress_bar.progress(30)
        
        # Prepare training data
        X, y, feature_columns = trainer.prepare_training_data(training_data)
        
        status_text.text("Step 3/5: Configuring models...")
        progress_bar.progress(50)
        
        # Training progress simulation (in real implementation, this would be actual training)
        if optimize_hyperparams:
            status_text.text(f"Step 4/5: Optimizing hyperparameters ({n_optimization_trials} trials)...")
            progress_bar.progress(70)
            time.sleep(2)  # Simulate optimization time
        
        status_text.text("Step 5/5: Training ensemble model...")
        progress_bar.progress(85)
        
        # Actual training
        training_results = trainer.train_model(
            X, y, 
            optimize_params=optimize_hyperparams,
            n_trials=n_optimization_trials
        )
        
        progress_bar.progress(100)
        status_text.text("✅ Training completed successfully!")
        
        # Save results and model
        trainer.save_training_session('models/trained_model.pkl')
        st.session_state.training_results = training_results
        st.session_state.training_in_progress = False
        st.session_state.training_completed = True
        
        st.success("🎉 Model training completed and saved!")
        time.sleep(1)
        st.rerun()
        
    except Exception as e:
        st.error(f"❌ Training failed: {str(e)}")
        st.session_state.training_in_progress = False

# Training results display
if st.session_state.training_completed:
    
    st.markdown("## 📈 Training Results")
    
    # Get training summary
    training_summary = trainer.get_training_summary()
    
    if training_summary and training_summary != "No training history available":
        
        # Performance metrics overview
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="Test Accuracy",
                value=f"{training_summary['latest_test_accuracy']:.3f}",
                delta=None
            )
        
        with col2:
            st.metric(
                label="Features Used",
                value=training_summary['features_used'],
                delta=None
            )
        
        with col3:
            st.metric(
                label="Training Samples",
                value=f"{training_summary['training_samples']:,}",
                delta=None
            )
        
        with col4:
            st.metric(
                label="Model Complexity",
                value="Ensemble",
                delta=None
            )
        
        # Detailed results tabs
        tab1, tab2, tab3, tab4 = st.tabs(["📊 Performance", "🎯 Model Comparison", "🔧 Hyperparameters", "📈 Feature Importance"])
        
        with tab1:
            st.markdown("### 🎯 Model Performance Metrics")
            
            if 'training_results' in st.session_state:
                results = st.session_state.training_results
                
                # Individual model performance
                if 'individual_model_scores' in results:
                    performance_chart = viz.create_model_performance_chart(results['individual_model_scores'])
                    st.plotly_chart(performance_chart, use_container_width=True)
                
                # Confusion matrix
                if 'confusion_matrix' in results:
                    cm_chart = viz.create_confusion_matrix(results['confusion_matrix'])
                    st.plotly_chart(cm_chart, use_container_width=True)
                
                # Classification report
                if 'classification_report' in results:
                    st.markdown("#### 📋 Detailed Classification Report")
                    
                    class_report = results['classification_report']
                    
                    # Convert classification report to DataFrame
                    report_data = []
                    for class_name, metrics in class_report.items():
                        if isinstance(metrics, dict) and 'precision' in metrics:
                            report_data.append({
                                'Class': class_name,
                                'Precision': f"{metrics['precision']:.3f}",
                                'Recall': f"{metrics['recall']:.3f}",
                                'F1-Score': f"{metrics['f1-score']:.3f}",
                                'Support': int(metrics['support'])
                            })
                    
                    if report_data:
                        report_df = pd.DataFrame(report_data)
                        st.dataframe(report_df, hide_index=True, use_container_width=True)
            
            else:
                st.info("No detailed training results available. Please run a new training session.")
        
        with tab2:
            st.markdown("### 🤖 Individual Model Comparison")
            
            if 'training_results' in st.session_state and 'individual_model_scores' in st.session_state.training_results:
                model_scores = st.session_state.training_results['individual_model_scores']
                
                # Create comparison table
                comparison_data = []
                for model_name, scores in model_scores.items():
                    comparison_data.append({
                        'Model': model_name.replace('_', ' ').title(),
                        'Mean Accuracy': f"{scores['mean_accuracy']:.4f}",
                        'Std Accuracy': f"{scores['std_accuracy']:.4f}",
                        'CV Scores': str([f"{score:.3f}" for score in scores['scores']])
                    })
                
                comparison_df = pd.DataFrame(comparison_data)
                st.dataframe(comparison_df, hide_index=True, use_container_width=True)
                
                # Performance visualization
                performance_chart = viz.create_model_performance_chart(model_scores)
                st.plotly_chart(performance_chart, use_container_width=True)
            
            else:
                st.info("Model comparison data not available.")
        
        with tab3:
            st.markdown("### ⚙️ Hyperparameter Optimization")
            
            if hasattr(trainer, 'best_params') and trainer.best_params:
                st.markdown("#### 🏆 Best Hyperparameters Found")
                
                # Group parameters by model
                model_params = {
                    'Random Forest': {},
                    'XGBoost': {},
                    'LightGBM': {}
                }
                
                for param, value in trainer.best_params.items():
                    if param.startswith('rf_'):
                        model_params['Random Forest'][param.replace('rf_', '')] = value
                    elif param.startswith('xgb_'):
                        model_params['XGBoost'][param.replace('xgb_', '')] = value
                    elif param.startswith('lgb_'):
                        model_params['LightGBM'][param.replace('lgb_', '')] = value
                
                # Display parameters for each model
                for model_name, params in model_params.items():
                    if params:
                        st.markdown(f"**{model_name}:**")
                        param_df = pd.DataFrame([
                            {'Parameter': param, 'Value': value}
                            for param, value in params.items()
                        ])
                        st.dataframe(param_df, hide_index=True, use_container_width=True)
                        st.markdown("")
            
            else:
                st.info("No hyperparameter optimization was performed or results not available.")
        
        with tab4:
            st.markdown("### 🎯 Feature Importance Analysis")
            
            if hasattr(trainer.model, 'get_feature_importance'):
                try:
                    importance_df = trainer.model.get_feature_importance()
                    
                    if importance_df is not None:
                        # Feature importance chart
                        importance_chart = viz.create_feature_importance_chart(importance_df, top_n=20)
                        st.plotly_chart(importance_chart, use_container_width=True)
                        
                        # Top features table
                        st.markdown("#### 🔝 Top 20 Most Important Features")
                        top_features = importance_df.head(20)[['feature', 'average']].copy()
                        top_features['average'] = top_features['average'].round(4)
                        st.dataframe(top_features, hide_index=True, use_container_width=True)
                        
                        # Feature categories analysis
                        st.markdown("#### 📂 Feature Categories")
                        
                        categories = {
                            'Form Features': len([f for f in importance_df['feature'] if 'form' in f.lower()]),
                            'H2H Features': len([f for f in importance_df['feature'] if 'h2h' in f.lower()]),
                            'Rolling Stats': len([f for f in importance_df['feature'] if 'avg' in f.lower()]),
                            'Weather Features': len([f for f in importance_df['feature'] if any(w in f.lower() for w in ['temp', 'weather', 'wind', 'rain'])]),
                            'Team Stats': len([f for f in importance_df['feature'] if 'team' in f.lower()]),
                            'Other': len(importance_df) - sum([
                                len([f for f in importance_df['feature'] if cat in f.lower()])
                                for cat in ['form', 'h2h', 'avg', 'temp', 'weather', 'wind', 'rain', 'team']
                            ])
                        }
                        
                        cat_df = pd.DataFrame([
                            {'Category': cat, 'Count': count, 'Percentage': f"{count/len(importance_df)*100:.1f}%"}
                            for cat, count in categories.items()
                        ])
                        
                        st.dataframe(cat_df, hide_index=True, use_container_width=True)
                    
                    else:
                        st.info("Feature importance data not available. Train the model first.")
                
                except Exception as e:
                    st.error(f"Error retrieving feature importance: {e}")
            
            else:
                st.info("Feature importance analysis not available for the current model.")
    
    else:
        st.info("No training history available. Please run a training session first.")

# Model evaluation section
st.markdown("---")
st.markdown("## 🔬 Advanced Model Evaluation")

eval_tab1, eval_tab2, eval_tab3 = st.tabs(["📊 Performance Testing", "🔄 Backtesting", "📈 Training History"])

with eval_tab1:
    st.markdown("### 🎯 Comprehensive Performance Evaluation")
    
    if st.button("🔬 Run Performance Evaluation"):
        if hasattr(trainer.model, 'is_trained') and trainer.model.is_trained:
            
            with st.spinner("Running comprehensive performance evaluation..."):
                
                # Generate test data
                test_data = data_collector.generate_sample_data(n_matches=500)
                X_test, y_test, _ = trainer.prepare_training_data(test_data)
                
                # Make predictions
                predictions = trainer.model.predict(X_test)
                y_pred = predictions['predicted_class']
                y_proba = predictions['final_prediction']
                confidence_scores = predictions['confidence']
                
                # Generate evaluation report
                evaluation_report = evaluator.generate_performance_report(
                    y_test, y_pred, y_proba
                )
                
                # Display results
                st.success("✅ Evaluation completed!")
                
                # Basic metrics
                col1, col2, col3 = st.columns(3)
                
                basic_metrics = evaluation_report['basic_metrics']
                
                with col1:
                    st.metric("Accuracy", f"{basic_metrics['accuracy']:.3f}")
                    st.metric("Precision", f"{basic_metrics['precision_macro']:.3f}")
                
                with col2:
                    st.metric("Recall", f"{basic_metrics['recall_macro']:.3f}")
                    st.metric("F1-Score", f"{basic_metrics['f1_macro']:.3f}")
                
                with col3:
                    if 'brier_score' in basic_metrics:
                        st.metric("Brier Score", f"{basic_metrics['brier_score']:.3f}")
                    if 'log_loss' in basic_metrics:
                        st.metric("Log Loss", f"{basic_metrics['log_loss']:.3f}")
                
                # Confidence analysis
                if 'confidence_analysis' in evaluation_report:
                    st.markdown("#### 🎯 Confidence Analysis")
                    
                    conf_analysis = evaluation_report['confidence_analysis']
                    
                    # Confidence bins table
                    conf_bins_data = []
                    for bin_name, bin_data in conf_analysis['confidence_bins'].items():
                        conf_bins_data.append({
                            'Confidence Range': bin_name,
                            'Accuracy': f"{bin_data['accuracy']:.3f}",
                            'Count': bin_data['count'],
                            'Avg Confidence': f"{bin_data['avg_confidence']:.3f}",
                            'Percentage': f"{bin_data['percentage_of_predictions']:.1%}"
                        })
                    
                    conf_df = pd.DataFrame(conf_bins_data)
                    st.dataframe(conf_df, hide_index=True, use_container_width=True)
                
                # Performance summary
                perf_summary = evaluation_report['performance_summary']
                
                st.markdown("#### 📋 Performance Summary")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**Strengths:**")
                    for strength in perf_summary['strengths']:
                        st.markdown(f"• {strength}")
                
                with col2:
                    st.markdown("**Recommendations:**")
                    for rec in perf_summary['recommendations']:
                        st.markdown(f"• {rec}")
        
        else:
            st.warning("⚠️ No trained model available. Please train a model first.")

with eval_tab2:
    st.markdown("### 🔄 Backtesting Analysis")
    
    if st.button("📈 Run Backtest"):
        if hasattr(trainer.model, 'is_trained') and trainer.model.is_trained:
            
            with st.spinner("Running backtesting analysis..."):
                
                # Generate historical data for backtesting
                backtest_data = data_collector.generate_sample_data(n_matches=2000)
                
                # Run backtest
                backtest_results = trainer.backtest_model(backtest_data, test_period_months=3)
                
                if not backtest_results.empty:
                    st.success("✅ Backtesting completed!")
                    
                    # Backtest summary metrics
                    avg_accuracy = backtest_results['accuracy'].mean()
                    accuracy_std = backtest_results['accuracy'].std()
                    best_period = backtest_results.loc[backtest_results['accuracy'].idxmax()]
                    worst_period = backtest_results.loc[backtest_results['accuracy'].idxmin()]
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Avg Accuracy", f"{avg_accuracy:.3f}")
                    
                    with col2:
                        st.metric("Accuracy Std", f"{accuracy_std:.3f}")
                    
                    with col3:
                        st.metric("Best Period", f"{best_period['accuracy']:.3f}")
                    
                    with col4:
                        st.metric("Worst Period", f"{worst_period['accuracy']:.3f}")
                    
                    # Backtest visualization
                    backtest_chart = viz.create_backtest_results_chart(backtest_results)
                    st.plotly_chart(backtest_chart, use_container_width=True)
                    
                    # Detailed results table
                    st.markdown("#### 📊 Detailed Backtest Results")
                    
                    display_results = backtest_results.copy()
                    display_results['test_period_start'] = display_results['test_period_start'].dt.strftime('%Y-%m')
                    display_results['test_period_end'] = display_results['test_period_end'].dt.strftime('%Y-%m')
                    display_results['accuracy'] = display_results['accuracy'].round(3)
                    display_results['avg_confidence'] = display_results['avg_confidence'].round(3)
                    
                    st.dataframe(display_results, hide_index=True, use_container_width=True)
                
                else:
                    st.warning("⚠️ Insufficient data for backtesting analysis.")
        
        else:
            st.warning("⚠️ No trained model available. Please train a model first.")

with eval_tab3:
    st.markdown("### 📈 Training History")
    
    if hasattr(trainer, 'training_history') and trainer.training_history:
        
        # Training history chart
        history_chart = viz.create_training_history_chart(trainer.training_history)
        st.plotly_chart(history_chart, use_container_width=True)
        
        # Training sessions table
        st.markdown("#### 📋 Training Sessions")
        
        history_data = []
        for i, session in enumerate(trainer.training_history):
            history_data.append({
                'Session': i + 1,
                'Date': session['timestamp'].strftime('%Y-%m-%d %H:%M'),
                'Test Accuracy': f"{session['test_accuracy']:.3f}",
                'Training Samples': f"{session['training_samples']:,}",
                'Features': session['features_count']
            })
        
        history_df = pd.DataFrame(history_data)
        st.dataframe(history_df, hide_index=True, use_container_width=True)
    
    else:
        st.info("No training history available.")

# Footer with training tips
st.markdown("---")
st.markdown("""
<div style="background: #f0f2f6; padding: 1rem; border-radius: 10px; margin-top: 2rem;">
    <h4>💡 Training Tips</h4>
    <ul>
        <li><strong>Data Quality:</strong> More training data generally improves model performance</li>
        <li><strong>Hyperparameter Optimization:</strong> Enable for better performance but longer training time</li>
        <li><strong>Regular Retraining:</strong> Retrain the model periodically with new data</li>
        <li><strong>Feature Engineering:</strong> The model uses 50+ engineered features for predictions</li>
        <li><strong>Ensemble Approach:</strong> Combines multiple algorithms for robust predictions</li>
    </ul>
</div>
""", unsafe_allow_html=True)
