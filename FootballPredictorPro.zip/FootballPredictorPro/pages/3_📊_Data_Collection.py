import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import os

from data.data_collector import FootballDataCollector
from data.web_scraper import FootballDataScraper
from utils.visualization import FootballVisualization
from models.feature_engineering import FootballFeatureEngineer

# Page configuration
st.set_page_config(page_title="Data Collection", page_icon="📊", layout="wide")

# Initialize components
@st.cache_resource
def initialize_data_system():
    return FootballDataCollector(), FootballDataScraper(), FootballVisualization(), FootballFeatureEngineer()

data_collector, scraper, viz, feature_engineer = initialize_data_system()

# Page title and description
st.title("📊 Data Collection & Management")
st.markdown("""
Collect, manage, and update football data for training the prediction models. 
Monitor data quality, automate data collection processes, and ensure comprehensive coverage of all relevant factors.
""")

# Sidebar for data collection configuration
st.sidebar.header("🔧 Data Collection Settings")

# Data source selection
st.sidebar.subheader("📡 Data Sources")
enable_automated_collection = st.sidebar.checkbox("Enable automated collection", value=True)
collection_frequency = st.sidebar.selectbox("Collection frequency", ["Daily", "Weekly", "Bi-weekly", "Monthly"])

# Data types selection
st.sidebar.subheader("📋 Data Types")
collect_match_results = st.sidebar.checkbox("Match results", value=True)
collect_team_stats = st.sidebar.checkbox("Team statistics", value=True)
collect_player_data = st.sidebar.checkbox("Player data", value=True)
collect_weather_data = st.sidebar.checkbox("Weather data", value=True)
collect_betting_odds = st.sidebar.checkbox("Betting odds", value=True)
collect_injury_reports = st.sidebar.checkbox("Injury reports", value=True)

# Advanced settings
with st.sidebar.expander("⚙️ Advanced Settings"):
    leagues_to_collect = st.multiselect(
        "Leagues to collect",
        ["Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"],
        default=["Premier League"]
    )
    max_historical_months = st.slider("Historical data months", 6, 60, 24)
    data_quality_threshold = st.slider("Data quality threshold", 0.5, 1.0, 0.8)

# Main content area
tab1, tab2, tab3, tab4, tab5 = st.tabs(["🔄 Data Collection", "📈 Data Overview", "🔍 Data Quality", "⚙️ Automated Tasks", "📁 Data Management"])

with tab1:
    st.markdown("## 🔄 Manual Data Collection")
    
    # Data collection controls
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🎯 Quick Collection")
        
        if st.button("🚀 Collect All Data", type="primary"):
            with st.spinner("Collecting comprehensive football data..."):
                
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                try:
                    # Collect all data
                    status_text.text("Collecting match data...")
                    progress_bar.progress(20)
                    
                    all_data = data_collector.update_all_data(
                        leagues=leagues_to_collect,
                        save_to_file=True
                    )
                    
                    progress_bar.progress(100)
                    status_text.text("✅ Data collection completed!")
                    
                    st.success("🎉 Successfully collected and saved all football data!")
                    
                    # Display collection summary
                    st.markdown("#### 📊 Collection Summary")
                    
                    summary_data = {
                        "Matches": len(all_data['matches']),
                        "Teams": len(all_data['team_stats']),
                        "Players": sum(len(players) for players in all_data['player_data'].values()),
                        "Referees": len(all_data['referee_stats']),
                        "Last Updated": all_data['last_updated'].strftime('%Y-%m-%d %H:%M:%S')
                    }
                    
                    summary_df = pd.DataFrame([
                        {"Metric": k, "Value": v} for k, v in summary_data.items()
                    ])
                    
                    st.dataframe(summary_df, hide_index=True, use_container_width=True)
                    
                except Exception as e:
                    st.error(f"❌ Data collection failed: {str(e)}")
        
        # Individual collection buttons
        st.markdown("### 🎯 Selective Collection")
        
        col_a, col_b = st.columns(2)
        
        with col_a:
            if st.button("⚽ Match Results"):
                with st.spinner("Collecting match results..."):
                    match_data = scraper.scrape_match_results()
                    st.success(f"✅ Collected {len(match_data)} matches")
            
            if st.button("👥 Team Statistics"):
                with st.spinner("Collecting team statistics..."):
                    team_stats = {}
                    for league in leagues_to_collect:
                        # Simulate team collection for each league
                        for i in range(20):  # 20 teams per league
                            team_name = f"Team_{i+1}_{league}"
                            team_stats[team_name] = scraper.scrape_team_statistics(team_name)
                    st.success(f"✅ Collected stats for {len(team_stats)} teams")
        
        with col_b:
            if st.button("🏥 Injury Reports"):
                with st.spinner("Collecting injury reports..."):
                    injury_data = {}
                    for league in leagues_to_collect:
                        for i in range(20):
                            team_name = f"Team_{i+1}_{league}"
                            injury_data[team_name] = scraper.scrape_injury_reports(team_name)
                    st.success(f"✅ Collected injury data for {len(injury_data)} teams")
            
            if st.button("💰 Betting Odds"):
                with st.spinner("Collecting betting odds..."):
                    odds_data = scraper.scrape_betting_odds("Team A", "Team B", datetime.now())
                    st.success("✅ Collected current betting odds")
    
    with col2:
        st.markdown("### 🌐 Web Scraping")
        
        # URL input for custom scraping
        custom_url = st.text_input("Enter website URL for data extraction:")
        
        if st.button("🔍 Extract Data from URL") and custom_url:
            with st.spinner("Extracting data from website..."):
                try:
                    extracted_text = scraper.get_website_text_content(custom_url)
                    
                    if extracted_text:
                        st.success("✅ Data extracted successfully!")
                        
                        # Display extracted content in expandable section
                        with st.expander("📄 Extracted Content"):
                            st.text_area("Content", extracted_text, height=300)
                        
                        # Option to save extracted data
                        if st.button("💾 Save Extracted Data"):
                            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                            filename = f"extracted_data_{timestamp}.txt"
                            
                            os.makedirs('data/extracted', exist_ok=True)
                            with open(f'data/extracted/{filename}', 'w', encoding='utf-8') as f:
                                f.write(extracted_text)
                            
                            st.success(f"✅ Data saved to data/extracted/{filename}")
                    else:
                        st.warning("⚠️ No content could be extracted from the URL")
                
                except Exception as e:
                    st.error(f"❌ Extraction failed: {str(e)}")
        
        # Predefined useful sources
        st.markdown("#### 📚 Useful Data Sources")
        
        useful_sources = [
            {"name": "BBC Sport", "url": "https://www.bbc.com/sport/football"},
            {"name": "Sky Sports", "url": "https://www.skysports.com/football"},
            {"name": "ESPN", "url": "https://www.espn.com/soccer/"},
            {"name": "FIFA Rankings", "url": "https://www.fifa.com/fifa-world-ranking/"},
        ]
        
        for source in useful_sources:
            if st.button(f"🔗 {source['name']}", key=f"source_{source['name']}"):
                st.info(f"📎 URL: {source['url']}")
                st.markdown("Copy the URL above and use the extraction tool.")

with tab2:
    st.markdown("## 📈 Data Overview")
    
    # Try to load existing data
    try:
        # Check for cached data
        if hasattr(data_collector, 'data_cache') and data_collector.data_cache:
            cached_data = data_collector.data_cache
            
            # Data overview metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                matches_count = len(cached_data.get('matches', []))
                st.metric("Total Matches", f"{matches_count:,}")
            
            with col2:
                teams_count = len(cached_data.get('team_stats', {}))
                st.metric("Teams", teams_count)
            
            with col3:
                players_count = sum(len(players) for players in cached_data.get('player_data', {}).values())
                st.metric("Players", f"{players_count:,}")
            
            with col4:
                last_update = cached_data.get('last_updated')
                if last_update:
                    days_ago = (datetime.now() - last_update).days
                    st.metric("Last Update", f"{days_ago} days ago")
                else:
                    st.metric("Last Update", "Never")
            
            # Data distribution charts
            if 'matches' in cached_data:
                matches_df = pd.DataFrame(cached_data['matches'])
                
                if not matches_df.empty and 'match_date' in matches_df.columns:
                    st.markdown("### 📅 Match Data Distribution")
                    
                    # Convert match_date to datetime if it's not already
                    matches_df['match_date'] = pd.to_datetime(matches_df['match_date'])
                    
                    # Monthly distribution
                    monthly_counts = matches_df.groupby(matches_df['match_date'].dt.to_period('M')).size()
                    
                    fig = go.Figure(data=[
                        go.Bar(
                            x=[str(period) for period in monthly_counts.index],
                            y=monthly_counts.values,
                            marker_color='#FF6B6B'
                        )
                    ])
                    
                    fig.update_layout(
                        title="Matches by Month",
                        xaxis_title="Month",
                        yaxis_title="Number of Matches",
                        height=400
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # League distribution
                    if 'league' in matches_df.columns:
                        league_counts = matches_df['league'].value_counts()
                        
                        fig_pie = go.Figure(data=[
                            go.Pie(
                                labels=league_counts.index,
                                values=league_counts.values,
                                hole=0.3
                            )
                        ])
                        
                        fig_pie.update_layout(
                            title="Matches by League",
                            height=400
                        )
                        
                        st.plotly_chart(fig_pie, use_container_width=True)
                    
                    # Recent data sample
                    st.markdown("### 📊 Recent Match Data Sample")
                    recent_matches = matches_df.head(10)
                    
                    # Select relevant columns for display
                    display_columns = ['match_date', 'home_team', 'away_team', 'home_goals', 'away_goals', 'result']
                    available_columns = [col for col in display_columns if col in recent_matches.columns]
                    
                    if available_columns:
                        st.dataframe(
                            recent_matches[available_columns],
                            hide_index=True,
                            use_container_width=True
                        )
        
        else:
            # No cached data available
            st.info("📭 No data currently cached. Please run data collection first.")
            
            if st.button("🔄 Generate Sample Data for Overview"):
                with st.spinner("Generating sample data..."):
                    sample_data = data_collector.generate_sample_data(n_matches=100)
                    
                    st.success("✅ Sample data generated!")
                    
                    # Display sample data overview
                    st.markdown("### 📊 Sample Data Overview")
                    st.dataframe(sample_data.head(10), use_container_width=True)
    
    except Exception as e:
        st.error(f"❌ Error loading data overview: {str(e)}")

with tab3:
    st.markdown("## 🔍 Data Quality Assessment")
    
    # Data quality controls
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🔍 Run Data Quality Check", type="primary"):
            with st.spinner("Analyzing data quality..."):
                
                try:
                    # Get data quality report
                    quality_report = data_collector.get_data_quality_report()
                    
                    if quality_report != "No data available for quality assessment":
                        st.success("✅ Data quality analysis completed!")
                        
                        # Quality metrics
                        col_a, col_b, col_c = st.columns(3)
                        
                        with col_a:
                            st.metric("Total Matches", f"{quality_report['total_matches']:,}")
                        
                        with col_b:
                            st.metric("Unique Teams", quality_report['unique_teams'])
                        
                        with col_c:
                            st.metric("Unique Venues", quality_report['unique_venues'])
                        
                        # Data consistency metrics
                        st.markdown("#### 📊 Data Consistency")
                        
                        consistency = quality_report['data_consistency']
                        consistency_df = pd.DataFrame([
                            {
                                "Check": "Possession Sum = 100%",
                                "Pass Rate": f"{consistency['possession_sum_100']:.1%}",
                                "Status": "✅ Good" if consistency['possession_sum_100'] > 0.95 else "⚠️ Issues"
                            },
                            {
                                "Check": "Shots >= Shots on Target",
                                "Pass Rate": f"{consistency['shots_logical']:.1%}",
                                "Status": "✅ Good" if consistency['shots_logical'] > 0.95 else "⚠️ Issues"
                            }
                        ])
                        
                        st.dataframe(consistency_df, hide_index=True, use_container_width=True)
                        
                        # Missing data analysis
                        st.markdown("#### 📋 Missing Data Analysis")
                        
                        missing_data = quality_report['missing_data']
                        if any(missing_data.values()):
                            missing_df = pd.DataFrame([
                                {"Data Type": k.title(), "Missing Count": v}
                                for k, v in missing_data.items()
                            ])
                            
                            st.dataframe(missing_df, hide_index=True, use_container_width=True)
                        else:
                            st.success("✅ No missing data detected!")
                        
                        # Date range information
                        if 'date_range' in quality_report:
                            st.markdown("#### 📅 Data Coverage")
                            date_range = quality_report['date_range']
                            
                            col_a, col_b = st.columns(2)
                            with col_a:
                                st.metric("Start Date", str(date_range['start'])[:10])
                            with col_b:
                                st.metric("End Date", str(date_range['end'])[:10])
                    
                    else:
                        st.warning("⚠️ No data available for quality assessment. Please collect data first.")
                
                except Exception as e:
                    st.error(f"❌ Data quality check failed: {str(e)}")
    
    with col2:
        st.markdown("### 🎯 Quality Improvement Suggestions")
        
        # Quality improvement recommendations
        st.markdown("""
        #### 📈 Improve Data Quality
        
        **Data Completeness:**
        - Ensure all matches have complete statistics
        - Fill missing player and team data
        - Validate date and time information
        
        **Data Consistency:**
        - Check logical relationships (shots >= shots on target)
        - Verify possession percentages sum to 100%
        - Validate score and result consistency
        
        **Data Freshness:**
        - Update data regularly (daily/weekly)
        - Monitor for new leagues and competitions
        - Remove outdated or irrelevant data
        """)
        
        # Data validation rules
        st.markdown("#### ✅ Validation Rules")
        
        validation_rules = [
            "Match dates must be valid and not in the future",
            "Home and away teams must be different",
            "Goals must be non-negative integers",
            "Possession percentages must sum to ~100%",
            "Shots on target ≤ Total shots",
            "Player ages must be realistic (16-45)",
            "Match results must match goal differences"
        ]
        
        for rule in validation_rules:
            st.markdown(f"• {rule}")

with tab4:
    st.markdown("## ⚙️ Automated Data Collection")
    
    # Automation status
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🤖 Automation Status")
        
        # Simulate automation status
        automation_status = {
            "Daily Match Results": "✅ Active",
            "Team Statistics": "✅ Active",
            "Injury Reports": "⏸️ Paused",
            "Weather Data": "✅ Active",
            "Betting Odds": "❌ Inactive",
            "Player Transfers": "✅ Active"
        }
        
        status_df = pd.DataFrame([
            {"Task": task, "Status": status}
            for task, status in automation_status.items()
        ])
        
        st.dataframe(status_df, hide_index=True, use_container_width=True)
        
        # Control buttons
        col_a, col_b = st.columns(2)
        
        with col_a:
            if st.button("▶️ Start All Tasks"):
                st.success("✅ All automated tasks started!")
        
        with col_b:
            if st.button("⏸️ Pause All Tasks"):
                st.warning("⏸️ All automated tasks paused!")
    
    with col2:
        st.markdown("### ⏰ Collection Schedule")
        
        # Collection schedule configuration
        schedule_config = {
            "Match Results": "Every 2 hours",
            "Team Stats": "Daily at 6:00 AM",
            "Player Data": "Weekly on Monday",
            "Weather": "Every 6 hours",
            "Injuries": "Daily at 8:00 AM",
            "Odds": "Every 30 minutes"
        }
        
        schedule_df = pd.DataFrame([
            {"Data Type": data_type, "Schedule": schedule}
            for data_type, schedule in schedule_config.items()
        ])
        
        st.dataframe(schedule_df, hide_index=True, use_container_width=True)
        
        # Last collection times
        st.markdown("#### 🕐 Last Collection Times")
        
        last_collection = {
            "Match Results": "2 hours ago",
            "Team Stats": "6 hours ago", 
            "Player Data": "2 days ago",
            "Weather": "1 hour ago",
            "Injuries": "4 hours ago",
            "Odds": "15 minutes ago"
        }
        
        collection_df = pd.DataFrame([
            {"Data Type": data_type, "Last Updated": time}
            for data_type, time in last_collection.items()
        ])
        
        st.dataframe(collection_df, hide_index=True, use_container_width=True)
    
    # Automation logs
    st.markdown("### 📜 Automation Logs")
    
    # Simulated log entries
    log_entries = [
        {"Time": "2024-01-15 14:30", "Task": "Match Results", "Status": "Success", "Records": 25},
        {"Time": "2024-01-15 14:00", "Task": "Betting Odds", "Status": "Success", "Records": 150},
        {"Time": "2024-01-15 13:30", "Task": "Team Stats", "Status": "Warning", "Records": 18},
        {"Time": "2024-01-15 13:00", "Task": "Weather Data", "Status": "Success", "Records": 50},
        {"Time": "2024-01-15 12:30", "Task": "Injury Reports", "Status": "Failed", "Records": 0},
    ]
    
    logs_df = pd.DataFrame(log_entries)
    st.dataframe(logs_df, hide_index=True, use_container_width=True)

with tab5:
    st.markdown("## 📁 Data Management")
    
    # File management
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 📂 Data Files")
        
        # List data files (simulated)
        data_files = [
            {"File": "football_data_20240115_143000.json", "Size": "2.3 MB", "Type": "Complete Dataset"},
            {"File": "scraped_data_20240115_120000.json", "Size": "1.8 MB", "Type": "Scraped Data"},
            {"File": "extracted_data_20240115_100000.txt", "Size": "0.5 MB", "Type": "Text Extract"},
            {"File": "training_data_processed.pkl", "Size": "5.2 MB", "Type": "Processed Data"},
        ]
        
        files_df = pd.DataFrame(data_files)
        st.dataframe(files_df, hide_index=True, use_container_width=True)
        
        # File operations
        col_a, col_b = st.columns(2)
        
        with col_a:
            if st.button("🗑️ Clean Old Files"):
                st.success("✅ Old files cleaned (>30 days)")
        
        with col_b:
            if st.button("📦 Backup Data"):
                st.success("✅ Data backed up successfully")
    
    with col2:
        st.markdown("### 💾 Storage Information")
        
        # Storage metrics
        storage_info = {
            "Total Storage": "50 GB",
            "Used Space": "12.3 GB",
            "Available": "37.7 GB",
            "Usage": "24.6%"
        }
        
        for label, value in storage_info.items():
            st.metric(label, value)
        
        # Storage breakdown
        st.markdown("#### 📊 Storage Breakdown")
        
        storage_breakdown = {
            "Match Data": 45,
            "Player Data": 25,
            "Media/Images": 15,
            "Backups": 10,
            "Other": 5
        }
        
        fig_storage = go.Figure(data=[
            go.Pie(
                labels=list(storage_breakdown.keys()),
                values=list(storage_breakdown.values()),
                hole=0.3
            )
        ])
        
        fig_storage.update_layout(
            title="Storage Usage by Type",
            height=300
        )
        
        st.plotly_chart(fig_storage, use_container_width=True)
    
    # Data export/import
    st.markdown("### 📤 Data Export/Import")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 📤 Export Data")
        
        export_format = st.selectbox("Export format", ["JSON", "CSV", "Excel", "Pickle"])
        export_date_range = st.date_input("Date range", value=[datetime.now().date() - timedelta(days=30), datetime.now().date()])
        
        if st.button("📤 Export Selected Data"):
            st.success(f"✅ Data exported to {export_format} format!")
    
    with col2:
        st.markdown("#### 📥 Import Data")
        
        uploaded_file = st.file_uploader("Upload data file", type=['json', 'csv', 'xlsx', 'pkl'])
        
        if uploaded_file is not None:
            if st.button("📥 Import Data"):
                st.success("✅ Data imported successfully!")

# Footer with data collection tips
st.markdown("---")
st.markdown("""
<div style="background: #f0f2f6; padding: 1rem; border-radius: 10px; margin-top: 2rem;">
    <h4>💡 Data Collection Best Practices</h4>
    <ul>
        <li><strong>Regular Updates:</strong> Set up automated collection for fresh data</li>
        <li><strong>Data Validation:</strong> Always validate collected data for consistency</li>
        <li><strong>Multiple Sources:</strong> Use diverse sources to improve data quality</li>
        <li><strong>Backup Strategy:</strong> Maintain regular backups of important datasets</li>
        <li><strong>Quality Monitoring:</strong> Monitor data quality metrics continuously</li>
        <li><strong>Privacy Compliance:</strong> Ensure all data collection follows privacy regulations</li>
    </ul>
</div>
""", unsafe_allow_html=True)
