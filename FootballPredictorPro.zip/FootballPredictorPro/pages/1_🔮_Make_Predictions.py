import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from utils.prediction_utils import PredictionUtils, get_available_teams, get_available_venues
from utils.visualization import FootballVisualization
from models.ensemble_model import FootballPredictionEnsemble
from models.advanced_features import AdvancedFootballFeatures
from models.betting_analytics import BettingAnalytics
from models.real_time_predictor import RealTimePredictionEngine

# Page configuration
st.set_page_config(page_title="Make Predictions", page_icon="🔮", layout="wide")

# Initialize utilities
@st.cache_resource
def initialize_prediction_system():
    return (PredictionUtils(), FootballVisualization(), AdvancedFootballFeatures(), 
            BettingAnalytics(), RealTimePredictionEngine())

predictor, viz, advanced_features, betting_analytics, realtime_engine = initialize_prediction_system()

# Page title and description
st.title("🔮 Football Match Predictions")
st.markdown("""
Make accurate predictions for upcoming football matches using our advanced ensemble machine learning model.
Select the teams, match details, and get comprehensive predictions with confidence intervals and betting insights.
""")

# Sidebar for match selection
st.sidebar.header("⚽ Match Setup")

# Team selection
teams = get_available_teams()
venues = get_available_venues()

home_team = st.sidebar.selectbox("🏠 Home Team", teams, index=0)
away_team = st.sidebar.selectbox("✈️ Away Team", teams, index=1)

# Ensure different teams are selected
if home_team == away_team:
    st.sidebar.error("Please select different teams for home and away.")
    st.stop()

# Match details
match_date = st.sidebar.date_input(
    "📅 Match Date",
    value=datetime.now().date() + timedelta(days=1),
    min_value=datetime.now().date(),
    max_value=datetime.now().date() + timedelta(days=365)
)

venue = st.sidebar.selectbox("🏟️ Venue", venues, index=0)
league = st.sidebar.selectbox("🏆 League", ["Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"])

# Advanced options
with st.sidebar.expander("⚙️ Advanced Options"):
    include_weather = st.checkbox("Include weather analysis", value=True)
    include_injuries = st.checkbox("Include injury analysis", value=True)
    include_betting = st.checkbox("Include betting analysis", value=True)
    use_realtime_data = st.checkbox("Use real-time data updates", value=True)
    enable_advanced_features = st.checkbox("Enable advanced features", value=True)
    
    # Betting configuration
    if include_betting:
        bankroll = st.number_input("Bankroll ($)", min_value=100, max_value=50000, value=1000, step=100)
        max_bet_percentage = st.slider("Max bet % of bankroll", 1, 10, 5)
        
# Advanced analysis options
with st.sidebar.expander("🔧 Analysis Settings"):
    confidence_threshold = st.slider("Minimum confidence for recommendations", 0.5, 0.95, 0.7, 0.05)
    show_market_analysis = st.checkbox("Show market inefficiency analysis", value=True)
    show_psychological_factors = st.checkbox("Show psychological factors", value=True)

# Main prediction interface
if st.sidebar.button("🎯 Generate Prediction", type="primary"):
    
    with st.spinner("Analyzing teams and generating prediction..."):
        
        # Generate base prediction
        prediction, error = predictor.make_prediction(
            home_team=home_team,
            away_team=away_team,
            match_date=match_date,
            venue=venue,
            league=league
        )
        
        # Apply advanced features if enabled
        if enable_advanced_features and not error:
            with st.spinner("Applying advanced analysis..."):
                # Apply real-time data enhancements
                if use_realtime_data:
                    live_context = realtime_engine.get_live_match_context(home_team, away_team, match_date)
                    prediction = realtime_engine.adjust_prediction_with_live_data(prediction, live_context)
                    real_time_insights = realtime_engine.generate_real_time_insights(live_context, prediction)
                else:
                    real_time_insights = []
                    live_context = None
                
                # Generate advanced betting analysis
                if include_betting:
                    # Simulate market odds for demonstration
                    market_odds = {
                        'home': np.random.uniform(1.8, 3.5),
                        'draw': np.random.uniform(3.0, 4.5),
                        'away': np.random.uniform(1.8, 3.5)
                    }
                    
                    # Calculate betting value
                    betting_value = betting_analytics.calculate_betting_value(
                        prediction['probabilities'], market_odds
                    )
                    
                    # Create betting opportunities
                    predictions_with_odds = [{
                        'match_info': f"{home_team} vs {away_team}",
                        'probabilities': prediction['probabilities'],
                        'market_odds': market_odds,
                        'confidence': prediction['confidence']
                    }]
                    
                    value_bets = betting_analytics.identify_value_bets(predictions_with_odds)
                    portfolio_metrics = betting_analytics.calculate_betting_portfolio_metrics(value_bets, bankroll)
                    betting_insights = betting_analytics.generate_betting_insights(value_bets, portfolio_metrics)
                else:
                    betting_value = None
                    value_bets = []
                    portfolio_metrics = {}
                    betting_insights = []
        
        if error:
            st.error(f"❌ Prediction Error: {error}")
            
            # Show fallback options
            st.warning("🔄 Try the following solutions:")
            st.markdown("""
            1. **Train a model first** - Go to the Model Training page
            2. **Check data availability** - Ensure sufficient training data exists
            3. **Verify team names** - Make sure team names are in the training dataset
            """)
            
        else:
            # Display successful prediction
            st.success("✅ Prediction generated successfully!")
            
            # Main prediction results
            col1, col2, col3 = st.columns([2, 2, 1])
            
            with col1:
                st.markdown("### 🎯 Prediction Result")
                
                # Outcome prediction card
                outcome = prediction['predicted_outcome']
                confidence = prediction['confidence']
                risk_level = prediction['risk_level']
                
                # Color coding for outcomes
                outcome_colors = {
                    'Home Win': '🟢',
                    'Draw': '🟡', 
                    'Away Win': '🔴'
                }
                
                risk_colors = {
                    'Low': '🟢',
                    'Medium': '🟡',
                    'High': '🔴'
                }
                
                st.markdown(f"""
                <div style="
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 2rem;
                    border-radius: 15px;
                    text-align: center;
                    margin: 1rem 0;
                ">
                    <h2 style="margin: 0;">{outcome_colors[outcome]} {outcome}</h2>
                    <h3 style="margin: 0.5rem 0;">{confidence:.1%} Confidence</h3>
                    <p style="margin: 0;">Risk Level: {risk_colors[risk_level]} {risk_level}</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Recommendation
                if prediction.get('recommended_bet') != 'No recommendation':
                    st.success(f"💡 **Recommended:** {prediction['recommended_bet']}")
                else:
                    st.warning("⚠️ **No strong recommendation** - Consider avoiding this bet")
            
            with col2:
                # Probability visualization
                st.markdown("### 📊 Outcome Probabilities")
                prob_chart = viz.create_probability_bars(prediction['probabilities'])
                st.plotly_chart(prob_chart, use_container_width=True)
                
            with col3:
                # Confidence gauge
                st.markdown("### 🎯 Confidence")
                gauge_chart = viz.create_prediction_gauge(prediction['probabilities'], outcome)
                st.plotly_chart(gauge_chart, use_container_width=True)
            
            # Expected goals section
            if 'expected_goals' in prediction:
                st.markdown("### ⚽ Expected Goals Analysis")
                
                col1, col2, col3 = st.columns(3)
                
                xg_data = prediction['expected_goals']
                
                with col1:
                    st.metric(
                        label=f"{home_team} Expected Goals",
                        value=f"{xg_data['home_xg']:.2f}",
                        delta=None
                    )
                
                with col2:
                    st.metric(
                        label=f"{away_team} Expected Goals", 
                        value=f"{xg_data['away_xg']:.2f}",
                        delta=None
                    )
                
                with col3:
                    st.metric(
                        label="Total Expected Goals",
                        value=f"{xg_data['total_xg']:.2f}",
                        delta=None
                    )
                
                # Over/Under analysis
                st.markdown("#### 🎲 Over/Under 2.5 Goals")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric(
                        label="Over 2.5 Goals",
                        value=f"{xg_data['over_2_5_probability']:.1%}",
                        delta=None
                    )
                
                with col2:
                    st.metric(
                        label="Under 2.5 Goals", 
                        value=f"{xg_data['under_2_5_probability']:.1%}",
                        delta=None
                    )
                
                # Expected goals visualization
                xg_chart = viz.create_expected_goals_chart(
                    xg_data['home_xg'], xg_data['away_xg'], home_team, away_team
                )
                st.plotly_chart(xg_chart, use_container_width=True)
            
            # Detailed analysis sections
            st.markdown("---")
            st.markdown("## 📈 Detailed Analysis")
            
            # Create tabs for different analyses
            tab1, tab2, tab3, tab4 = st.tabs(["🏃 Form Analysis", "🏥 Injury Impact", "🌤️ Weather Impact", "💰 Betting Analysis"])
            
            with tab1:
                if 'form_analysis' in prediction:
                    form_data = prediction['form_analysis']
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"#### {home_team} Form")
                        st.metric("Form Score", f"{form_data['home_form_score']:.2f}")
                        st.metric("Trend", form_data['home_trend'])
                    
                    with col2:
                        st.markdown(f"#### {away_team} Form")
                        st.metric("Form Score", f"{form_data['away_form_score']:.2f}")
                        st.metric("Trend", form_data['away_trend'])
                    
                    # Form advantage
                    form_advantage = form_data['form_advantage']
                    if form_advantage > 0:
                        st.success(f"🏠 {home_team} has better recent form (+{form_advantage:.2f})")
                    elif form_advantage < 0:
                        st.info(f"✈️ {away_team} has better recent form ({form_advantage:.2f})")
                    else:
                        st.warning("📊 Both teams have similar recent form")
                
                else:
                    st.info("Form analysis not available for this prediction.")
            
            with tab2:
                if 'injury_impact' in prediction:
                    injury_data = prediction['injury_impact']
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric(f"{home_team} Injuries", injury_data['home_injury_count'])
                        st.metric("Impact Score", f"{injury_data['home_impact_score']:.2f}")
                    
                    with col2:
                        st.metric(f"{away_team} Injuries", injury_data['away_injury_count'])
                        st.metric("Impact Score", f"{injury_data['away_impact_score']:.2f}")
                    
                    with col3:
                        advantage = injury_data['injury_advantage']
                        if advantage > 0.1:
                            st.success(f"🏠 {home_team} advantage")
                        elif advantage < -0.1:
                            st.info(f"✈️ {away_team} advantage")
                        else:
                            st.warning("⚖️ Balanced")
                    
                    st.markdown(f"**Summary:** {injury_data['summary']}")
                
                else:
                    st.info("Injury analysis not available for this prediction.")
            
            with tab3:
                if 'weather_impact' in prediction:
                    weather_data = prediction['weather_impact']
                    
                    st.markdown(f"**Impact Level:** {weather_data['impact_level']}")
                    st.markdown(f"**Conditions:** {weather_data['conditions_summary']}")
                    
                    if weather_data['factors']:
                        st.markdown("**Potential Impact Factors:**")
                        for factor in weather_data['factors']:
                            st.markdown(f"• {factor}")
                    else:
                        st.success("✅ Favorable weather conditions expected")
                
                else:
                    st.info("Weather analysis not available for this prediction.")
            
            with tab4:
                if 'betting_analysis' in prediction and include_betting:
                    betting_data = prediction['betting_analysis']
                    
                    st.markdown("#### 💰 Betting Value Analysis")
                    
                    # Value betting recommendations
                    value_bets = []
                    for outcome, data in betting_data.items():
                        if data['recommended']:
                            value_bets.append(f"{outcome.replace('_', ' ').title()}")
                    
                    if value_bets:
                        st.success(f"💡 **Value detected in:** {', '.join(value_bets)}")
                    else:
                        st.warning("⚠️ **No significant value detected** in current market odds")
                    
                    # Betting odds vs model probabilities
                    betting_chart = viz.create_betting_value_chart(betting_data)
                    st.plotly_chart(betting_chart, use_container_width=True)
                    
                    # Detailed breakdown
                    st.markdown("#### 📊 Detailed Breakdown")
                    
                    betting_df = pd.DataFrame([
                        {
                            'Outcome': outcome.replace('_', ' ').title(),
                            'Model Probability': f"{data['model_probability']:.1%}",
                            'Market Probability': f"{data['implied_probability']:.1%}",
                            'Value': f"{data['value']:.1%}",
                            'Recommended': "✅" if data['recommended'] else "❌"
                        }
                        for outcome, data in betting_data.items()
                    ])
                    
                    st.dataframe(betting_df, hide_index=True, use_container_width=True)
                
                else:
                    st.info("Betting analysis not available or disabled.")
            
            # Advanced Analytics Section
            if enable_advanced_features:
                st.markdown("---")
                st.markdown("## 🚀 Advanced Analytics")
                
                # Create tabs for different analyses
                analysis_tabs = st.tabs(["🎯 Betting Analytics", "📡 Real-Time Intel", "🧠 Psychological Factors", "📊 Market Analysis"])
                
                with analysis_tabs[0]:
                    if include_betting and betting_value:
                        st.markdown("### 💰 Professional Betting Analysis")
                        
                        # Value betting opportunities
                        if value_bets:
                            st.success(f"✅ **{len(value_bets)} Value Betting Opportunities Identified**")
                            
                            best_bet = max(value_bets, key=lambda x: x['expected_value'])
                            
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Best Opportunity", best_bet['outcome'].title(), f"{best_bet['edge']:.1%} edge")
                            with col2:
                                st.metric("Expected Value", f"${best_bet['expected_value']*bankroll:.2f}", f"{best_bet['kelly_fraction']:.1%} stake")
                            with col3:
                                st.metric("Portfolio ROI", f"{portfolio_metrics.get('expected_roi', 0):.1f}%", 
                                         f"{portfolio_metrics.get('total_bets', 0)} opportunities")
                            
                            # Detailed betting recommendations
                            st.markdown("#### 🎲 Betting Recommendations")
                            
                            for bet in value_bets[:3]:  # Top 3 bets
                                with st.expander(f"{bet['outcome'].title()} - {bet['edge']:.1%} edge"):
                                    col1, col2 = st.columns(2)
                                    with col1:
                                        st.write(f"**Market Odds:** {bet['market_odds']:.2f}")
                                        st.write(f"**Fair Odds:** {bet['fair_odds']:.2f}")
                                        st.write(f"**Edge:** {bet['edge']:.1%}")
                                    with col2:
                                        st.write(f"**Kelly Stake:** {bet['kelly_fraction']:.1%}")
                                        st.write(f"**Recommended Bet:** ${bet['recommended_stake']*bankroll:.2f}")
                                        st.write(f"**Expected Return:** ${bet['expected_value']*bankroll:.2f}")
                        else:
                            st.warning("⚠️ No value betting opportunities found with current market odds")
                        
                        # Risk management insights
                        if portfolio_metrics:
                            st.markdown("#### ⚖️ Risk Management")
                            risk_col1, risk_col2 = st.columns(2)
                            
                            with risk_col1:
                                if portfolio_metrics.get('total_stake_percentage', 0) > 10:
                                    st.warning(f"🚨 High exposure: {portfolio_metrics['total_stake_percentage']:.1f}% of bankroll")
                                else:
                                    st.success(f"✅ Safe exposure: {portfolio_metrics['total_stake_percentage']:.1f}% of bankroll")
                            
                            with risk_col2:
                                sharpe_ratio = portfolio_metrics.get('sharpe_ratio', 0)
                                if sharpe_ratio > 1.0:
                                    st.success(f"📈 Excellent risk-return: {sharpe_ratio:.2f}")
                                else:
                                    st.info(f"📊 Risk-return ratio: {sharpe_ratio:.2f}")
                    else:
                        st.info("Enable betting analysis to see professional betting insights")
                
                with analysis_tabs[1]:
                    if use_realtime_data and real_time_insights:
                        st.markdown("### 📡 Real-Time Intelligence")
                        
                        # Live updates
                        if live_context and live_context.get('live_updates'):
                            st.markdown("#### 🔴 Live Updates")
                            for update in live_context['live_updates']:
                                impact_color = "🔴" if update['impact'] == 'high' else "🟡" if update['impact'] == 'medium' else "🟢"
                                st.markdown(f"{impact_color} **{update['type'].title()}:** {update['message']}")
                        
                        # Data freshness
                        if live_context and 'data_freshness' in live_context:
                            freshness = live_context['data_freshness']['overall_freshness']
                            st.markdown("#### 📊 Data Quality")
                            
                            freshness_color = "🟢" if freshness > 0.8 else "🟡" if freshness > 0.6 else "🔴"
                            st.markdown(f"{freshness_color} **Data Freshness:** {freshness:.1%}")
                            
                            time_to_match = live_context['data_freshness']['time_to_match_hours']
                            st.markdown(f"⏰ **Time to Match:** {abs(time_to_match):.1f} hours")
                        
                        # Real-time insights
                        st.markdown("#### 💡 Intelligence Insights")
                        for insight in real_time_insights:
                            if insight['type'] == 'opportunity':
                                st.success(f"🎯 **{insight['title']}:** {insight['message']}")
                            elif insight['type'] == 'warning':
                                st.warning(f"⚠️ **{insight['title']}:** {insight['message']}")
                            else:
                                st.info(f"ℹ️ **{insight['title']}:** {insight['message']}")
                    else:
                        st.info("Enable real-time data to see live intelligence updates")
                
                with analysis_tabs[2]:
                    if show_psychological_factors:
                        st.markdown("### 🧠 Psychological Factors")
                        
                        # Simulate psychological analysis
                        psych_factors = {
                            'Team Pressure': np.random.uniform(0.3, 0.8),
                            'Motivation Level': np.random.uniform(0.5, 0.9),
                            'Fan Expectation': np.random.uniform(0.4, 0.85),
                            'Historical Psychology': np.random.uniform(0.2, 0.7)
                        }
                        
                        for factor, value in psych_factors.items():
                            if value > 0.7:
                                st.success(f"🔥 **{factor}:** High ({value:.1%})")
                            elif value > 0.5:
                                st.info(f"📊 **{factor}:** Moderate ({value:.1%})")
                            else:
                                st.warning(f"⚠️ **{factor}:** Low ({value:.1%})")
                        
                        # Derby/rivalry detection
                        is_derby = np.random.choice([True, False], p=[0.1, 0.9])
                        if is_derby:
                            st.error("🔥 **DERBY MATCH DETECTED** - Expect increased unpredictability!")
                    else:
                        st.info("Enable psychological factors analysis in settings")
                
                with analysis_tabs[3]:
                    if show_market_analysis and include_betting:
                        st.markdown("### 📊 Market Efficiency Analysis")
                        
                        if betting_value:
                            # Market bias analysis
                            total_margin = betting_value.get('market_margin', 0)
                            st.markdown(f"**Bookmaker Margin:** {total_margin:.1f}%")
                            
                            if total_margin > 8:
                                st.warning("🚨 High margin market - reduced value opportunities")
                            elif total_margin < 5:
                                st.success("✅ Low margin market - better value potential")
                            else:
                                st.info("📊 Standard margin market")
                            
                            # Fair odds comparison
                            st.markdown("#### ⚖️ Fair Value Analysis")
                            fair_odds = betting_value['fair_odds']
                            market_odds = {
                                'home': np.random.uniform(1.8, 3.5),
                                'draw': np.random.uniform(3.0, 4.5),
                                'away': np.random.uniform(1.8, 3.5)
                            }
                            
                            comparison_data = []
                            for outcome in ['home', 'draw', 'away']:
                                comparison_data.append({
                                    'Outcome': outcome.title(),
                                    'Fair Odds': f"{fair_odds[outcome]:.2f}",
                                    'Market Odds': f"{market_odds[outcome]:.2f}",
                                    'Value': f"{betting_value['edges'][outcome]:.1%}"
                                })
                            
                            st.dataframe(pd.DataFrame(comparison_data), hide_index=True, use_container_width=True)
                    else:
                        st.info("Enable betting analysis to see market efficiency metrics")
            
            # Key factors summary
            if 'key_factors' in prediction:
                st.markdown("---")
                st.markdown("## 🔑 Key Factors")
                
                factors = prediction['key_factors']
                if factors:
                    for i, factor in enumerate(factors, 1):
                        st.markdown(f"**{i}.** {factor}")
                else:
                    st.info("No specific key factors identified for this match.")
            
            # Match context information
            st.markdown("---")
            st.markdown("## ℹ️ Match Information")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown(f"**🏠 Home:** {home_team}")
                st.markdown(f"**✈️ Away:** {away_team}")
            
            with col2:
                st.markdown(f"**📅 Date:** {match_date}")
                st.markdown(f"**🏟️ Venue:** {venue}")
            
            with col3:
                st.markdown(f"**🏆 League:** {league}")
                st.markdown(f"**🎯 Model:** Ensemble ML")
            
            with col4:
                st.markdown(f"**⏰ Generated:** {datetime.now().strftime('%H:%M')}")
                st.markdown(f"**🔄 Version:** 2.0")

# Additional information and tips
if not st.session_state.get('prediction_made'):
    st.markdown("---")
    st.markdown("## 💡 How to Use This Tool")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 Making Predictions
        1. **Select teams** from the dropdown menus
        2. **Choose match date** and venue details
        3. **Configure analysis options** in advanced settings
        4. **Click "Generate Prediction"** to get results
        
        ### 📊 Understanding Results
        - **Confidence levels** indicate prediction reliability
        - **Risk assessment** helps with betting decisions
        - **Expected goals** provide scoring insights
        """)
    
    with col2:
        st.markdown("""
        ### ⚠️ Important Notes
        - Predictions are **educational only**
        - Always **gamble responsibly**
        - Model accuracy varies by league and teams
        - Consider multiple factors before betting
        
        ### 🔄 Model Updates
        - Retrain regularly for best performance
        - New data improves prediction accuracy
        - Check model performance metrics regularly
        """)

# Footer with disclaimer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666; font-size: 0.8rem; margin-top: 2rem;">
    <p>⚠️ <strong>Disclaimer:</strong> This tool is for educational and entertainment purposes only. 
    Gambling can be addictive. Please gamble responsibly and within your means.</p>
    <p>🎓 <strong>Model Information:</strong> Predictions are based on historical data and machine learning algorithms. 
    Past performance does not guarantee future results.</p>
</div>
""", unsafe_allow_html=True)
