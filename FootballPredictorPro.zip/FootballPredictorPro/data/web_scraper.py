import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import trafilatura
import os
import json
import warnings
warnings.filterwarnings('ignore')

class FootballDataScraper:
    """
    Web scraping functionality for collecting football data from various sources
    """
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
    def get_website_text_content(self, url: str) -> str:
        """
        Extract main text content from a website using trafilatura
        """
        try:
            downloaded = trafilatura.fetch_url(url)
            text = trafilatura.extract(downloaded)
            return text if text else ""
        except Exception as e:
            print(f"Error extracting content from {url}: {e}")
            return ""
    
    def scrape_match_results(self, league='premier-league', season='2023-24'):
        """
        Scrape match results from football websites
        """
        print(f"Scraping match results for {league} {season}...")
        
        # In a real implementation, this would scrape from actual football websites
        # For demonstration, we'll generate realistic data
        
        # Sample URLs that could be scraped (these are examples)
        urls = [
            f"https://example-football-site.com/{league}/results/{season}",
            f"https://another-football-site.com/matches/{league}",
        ]
        
        matches = []
        
        # Simulate scraping process
        for i in range(100):  # Simulate 100 matches
            match = {
                'date': datetime.now() - timedelta(days=np.random.randint(1, 365)),
                'home_team': f"Team_{np.random.randint(1, 20)}",
                'away_team': f"Team_{np.random.randint(1, 20)}",
                'home_goals': np.random.randint(0, 5),
                'away_goals': np.random.randint(0, 5),
                'venue': f"Stadium_{np.random.randint(1, 10)}",
                'attendance': np.random.randint(20000, 80000)
            }
            
            # Determine result
            if match['home_goals'] > match['away_goals']:
                match['result'] = 'H'
            elif match['home_goals'] < match['away_goals']:
                match['result'] = 'A'
            else:
                match['result'] = 'D'
            
            matches.append(match)
        
        return pd.DataFrame(matches)
    
    def scrape_team_statistics(self, team_name, season='2023-24'):
        """
        Scrape detailed team statistics
        """
        print(f"Scraping statistics for {team_name}...")
        
        # Simulate scraping team stats
        team_stats = {
            'team_name': team_name,
            'season': season,
            'league_position': np.random.randint(1, 20),
            'games_played': np.random.randint(20, 38),
            'wins': np.random.randint(5, 25),
            'draws': np.random.randint(3, 15),
            'losses': np.random.randint(3, 20),
            'goals_for': np.random.randint(30, 90),
            'goals_against': np.random.randint(25, 80),
            'clean_sheets': np.random.randint(5, 20),
            'avg_possession': np.random.uniform(40, 70),
            'pass_accuracy': np.random.uniform(75, 90),
            'shots_per_game': np.random.uniform(10, 20),
            'shots_on_target_per_game': np.random.uniform(4, 8),
            'corners_per_game': np.random.uniform(4, 8),
            'fouls_per_game': np.random.uniform(8, 15),
            'yellow_cards': np.random.randint(30, 80),
            'red_cards': np.random.randint(1, 8)
        }
        
        return team_stats
    
    def scrape_player_data(self, team_name, season='2023-24'):
        """
        Scrape player statistics and information
        """
        print(f"Scraping player data for {team_name}...")
        
        positions = ['Goalkeeper', 'Defender', 'Midfielder', 'Forward']
        players = []
        
        for i in range(25):  # Typical squad size
            player = {
                'name': f"Player_{i+1}",
                'team': team_name,
                'position': np.random.choice(positions),
                'age': np.random.randint(18, 35),
                'nationality': np.random.choice(['England', 'Spain', 'Brazil', 'France', 'Germany']),
                'appearances': np.random.randint(0, 38),
                'goals': np.random.randint(0, 25),
                'assists': np.random.randint(0, 20),
                'yellow_cards': np.random.randint(0, 15),
                'red_cards': np.random.randint(0, 3),
                'minutes_played': np.random.randint(0, 3420),
                'pass_accuracy': np.random.uniform(70, 95),
                'shots_per_game': np.random.uniform(0, 5),
                'tackles_per_game': np.random.uniform(0, 8),
                'interceptions_per_game': np.random.uniform(0, 5),
                'market_value': np.random.uniform(1, 100),  # Million euros
                'contract_expiry': f"202{np.random.randint(4, 8)}"
            }
            
            players.append(player)
        
        return pd.DataFrame(players)
    
    def scrape_injury_reports(self, team_name):
        """
        Scrape current injury reports
        """
        print(f"Scraping injury reports for {team_name}...")
        
        injuries = []
        
        # Simulate injury data
        for i in range(np.random.randint(2, 8)):  # Random number of injuries
            injury = {
                'player_name': f"Player_{np.random.randint(1, 25)}",
                'team': team_name,
                'injury_type': np.random.choice([
                    'Hamstring', 'Knee', 'Ankle', 'Muscle', 'Back', 'Shoulder'
                ]),
                'severity': np.random.choice(['Minor', 'Moderate', 'Serious']),
                'expected_return': datetime.now() + timedelta(days=np.random.randint(1, 90)),
                'injury_date': datetime.now() - timedelta(days=np.random.randint(1, 30)),
                'status': np.random.choice(['Injured', 'Recovering', 'Training'])
            }
            
            injuries.append(injury)
        
        return pd.DataFrame(injuries)
    
    def scrape_transfer_news(self, league='premier-league'):
        """
        Scrape recent transfer news and rumors
        """
        print(f"Scraping transfer news for {league}...")
        
        transfers = []
        
        for i in range(np.random.randint(10, 30)):
            transfer = {
                'player_name': f"Player_{np.random.randint(100, 999)}",
                'from_team': f"Team_{np.random.randint(1, 50)}",
                'to_team': f"Team_{np.random.randint(1, 50)}",
                'transfer_fee': np.random.uniform(5, 100),  # Million euros
                'transfer_date': datetime.now() - timedelta(days=np.random.randint(1, 365)),
                'transfer_type': np.random.choice(['Permanent', 'Loan', 'Free Transfer']),
                'contract_length': np.random.randint(1, 5),  # Years
                'source_reliability': np.random.choice(['High', 'Medium', 'Low'])
            }
            
            transfers.append(transfer)
        
        return pd.DataFrame(transfers)
    
    def scrape_betting_odds(self, home_team, away_team, match_date):
        """
        Scrape betting odds from various bookmakers
        """
        print(f"Scraping betting odds for {home_team} vs {away_team}...")
        
        bookmakers = ['Bet365', 'William Hill', 'Paddy Power', 'Ladbrokes', 'Coral']
        odds_data = {}
        
        for bookmaker in bookmakers:
            odds_data[bookmaker] = {
                'home_win': round(np.random.uniform(1.5, 5.0), 2),
                'draw': round(np.random.uniform(3.0, 4.5), 2),
                'away_win': round(np.random.uniform(1.5, 5.0), 2),
                'over_2_5_goals': round(np.random.uniform(1.6, 2.5), 2),
                'under_2_5_goals': round(np.random.uniform(1.6, 2.5), 2),
                'both_teams_score_yes': round(np.random.uniform(1.7, 2.2), 2),
                'both_teams_score_no': round(np.random.uniform(1.7, 2.2), 2),
                'home_clean_sheet': round(np.random.uniform(2.0, 4.0), 2),
                'away_clean_sheet': round(np.random.uniform(2.0, 4.0), 2)
            }
        
        return odds_data
    
    def scrape_weather_forecast(self, venue, match_date):
        """
        Scrape weather forecast for match venue
        """
        print(f"Scraping weather forecast for {venue} on {match_date}...")
        
        # In a real implementation, this would use weather APIs
        weather_forecast = {
            'venue': venue,
            'date': match_date,
            'temperature': np.random.normal(15, 8),  # Celsius
            'feels_like': np.random.normal(15, 8),
            'humidity': np.random.uniform(40, 90),  # Percentage
            'wind_speed': np.random.uniform(0, 20),  # km/h
            'wind_direction': np.random.choice(['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']),
            'precipitation_chance': np.random.uniform(0, 100),  # Percentage
            'precipitation_amount': np.random.exponential(2),  # mm
            'visibility': np.random.uniform(5, 20),  # km
            'uv_index': np.random.randint(1, 11),
            'condition': np.random.choice([
                'Clear', 'Partly Cloudy', 'Cloudy', 'Light Rain', 
                'Heavy Rain', 'Snow', 'Fog', 'Thunderstorm'
            ]),
            'air_pressure': np.random.normal(1013, 20)  # hPa
        }
        
        return weather_forecast
    
    def scrape_referee_statistics(self, referee_name):
        """
        Scrape referee statistics and performance data
        """
        print(f"Scraping referee statistics for {referee_name}...")
        
        referee_stats = {
            'name': referee_name,
            'experience_years': np.random.randint(5, 20),
            'games_officiated_this_season': np.random.randint(15, 35),
            'total_career_games': np.random.randint(100, 500),
            'yellow_cards_per_game': np.random.uniform(3, 7),
            'red_cards_per_game': np.random.uniform(0.1, 0.5),
            'penalties_awarded_per_game': np.random.uniform(0.2, 0.6),
            'fouls_called_per_game': np.random.uniform(20, 35),
            'home_team_bias': np.random.uniform(-0.2, 0.2),  # Positive = favors home
            'strict_rating': np.random.uniform(6, 10),  # 1-10 scale
            'consistency_rating': np.random.uniform(7, 10),
            'var_decisions_overturned': np.random.randint(0, 10),
            'controversial_decisions': np.random.randint(0, 5),
            'average_match_control': np.random.uniform(7, 10)
        }
        
        return referee_stats
    
    def scrape_league_table(self, league='premier-league', season='2023-24'):
        """
        Scrape current league table and standings
        """
        print(f"Scraping league table for {league} {season}...")
        
        teams = [
            'Manchester City', 'Arsenal', 'Liverpool', 'Chelsea', 'Manchester United',
            'Tottenham', 'Newcastle', 'Brighton', 'Aston Villa', 'West Ham',
            'Crystal Palace', 'Fulham', 'Brentford', 'Wolves', 'Everton',
            'Nottingham Forest', 'Leeds United', 'Leicester City', 'Southampton', 'Bournemouth'
        ]
        
        table = []
        
        for i, team in enumerate(teams):
            # Simulate realistic league table data
            games_played = np.random.randint(25, 38)
            wins = np.random.randint(games_played//4, games_played//2)
            losses = np.random.randint(games_played//4, games_played//2)
            draws = games_played - wins - losses
            
            goals_for = np.random.randint(30, 80)
            goals_against = np.random.randint(25, 70)
            
            team_data = {
                'position': i + 1,
                'team': team,
                'games_played': games_played,
                'wins': wins,
                'draws': draws,
                'losses': losses,
                'goals_for': goals_for,
                'goals_against': goals_against,
                'goal_difference': goals_for - goals_against,
                'points': wins * 3 + draws,
                'form': ''.join(np.random.choice(['W', 'D', 'L'], 5)),
                'home_record': f"{np.random.randint(wins//2, wins)}-{np.random.randint(0, draws)}-{np.random.randint(0, losses//2)}",
                'away_record': f"{wins - np.random.randint(wins//2, wins)}-{draws - np.random.randint(0, draws)}-{losses - np.random.randint(0, losses//2)}"
            }
            
            table.append(team_data)
        
        # Sort by points
        table.sort(key=lambda x: x['points'], reverse=True)
        
        # Update positions
        for i, team_data in enumerate(table):
            team_data['position'] = i + 1
        
        return pd.DataFrame(table)
    
    def scrape_historical_h2h(self, team1, team2, years_back=5):
        """
        Scrape historical head-to-head records
        """
        print(f"Scraping H2H history for {team1} vs {team2}...")
        
        h2h_matches = []
        
        for i in range(np.random.randint(5, 15)):  # Last 5-15 meetings
            match_date = datetime.now() - timedelta(days=np.random.randint(30, years_back*365))
            
            # Randomly assign home/away
            if np.random.random() > 0.5:
                home_team, away_team = team1, team2
            else:
                home_team, away_team = team2, team1
            
            home_goals = np.random.randint(0, 5)
            away_goals = np.random.randint(0, 5)
            
            if home_goals > away_goals:
                result = 'H'
            elif home_goals < away_goals:
                result = 'A'
            else:
                result = 'D'
            
            match = {
                'date': match_date,
                'home_team': home_team,
                'away_team': away_team,
                'home_goals': home_goals,
                'away_goals': away_goals,
                'result': result,
                'venue': f"{home_team} Stadium",
                'competition': np.random.choice(['Premier League', 'FA Cup', 'League Cup', 'Champions League']),
                'attendance': np.random.randint(30000, 80000)
            }
            
            h2h_matches.append(match)
        
        return pd.DataFrame(h2h_matches).sort_values('date', ascending=False)
    
    def scrape_news_sentiment(self, team_name, days_back=7):
        """
        Scrape recent news and analyze sentiment
        """
        print(f"Scraping news sentiment for {team_name}...")
        
        news_articles = []
        
        for i in range(np.random.randint(5, 20)):
            article_date = datetime.now() - timedelta(days=np.random.randint(1, days_back))
            
            # Simulate news topics
            topics = [
                'Transfer News', 'Injury Update', 'Match Preview', 'Match Review',
                'Manager Comments', 'Player Interview', 'Training Report'
            ]
            
            sentiment_scores = ['Positive', 'Neutral', 'Negative']
            
            article = {
                'date': article_date,
                'title': f"{np.random.choice(topics)}: {team_name}",
                'source': np.random.choice(['BBC Sport', 'Sky Sports', 'ESPN', 'The Guardian']),
                'topic': np.random.choice(topics),
                'sentiment': np.random.choice(sentiment_scores),
                'sentiment_score': np.random.uniform(-1, 1),  # -1 (negative) to 1 (positive)
                'relevance_score': np.random.uniform(0.5, 1.0),
                'social_media_engagement': np.random.randint(100, 10000)
            }
            
            news_articles.append(article)
        
        return pd.DataFrame(news_articles)
    
    def run_comprehensive_scrape(self, teams, save_data=True):
        """
        Run comprehensive data scraping for multiple teams
        """
        print("Starting comprehensive data scraping...")
        
        scraped_data = {
            'matches': [],
            'team_stats': {},
            'player_data': {},
            'injuries': {},
            'transfers': None,
            'league_table': None,
            'news_sentiment': {},
            'scrape_timestamp': datetime.now()
        }
        
        # Scrape league table
        scraped_data['league_table'] = self.scrape_league_table()
        
        # Scrape transfer news
        scraped_data['transfers'] = self.scrape_transfer_news()
        
        # Scrape data for each team
        for team in teams:
            print(f"Scraping data for {team}...")
            
            # Team statistics
            scraped_data['team_stats'][team] = self.scrape_team_statistics(team)
            
            # Player data
            scraped_data['player_data'][team] = self.scrape_player_data(team)
            
            # Injury reports
            scraped_data['injuries'][team] = self.scrape_injury_reports(team)
            
            # News sentiment
            scraped_data['news_sentiment'][team] = self.scrape_news_sentiment(team)
            
            # Add small delay to be respectful to servers
            time.sleep(1)
        
        # Scrape recent matches
        scraped_data['matches'] = self.scrape_match_results()
        
        if save_data:
            # Save scraped data
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'scraped_data_{timestamp}.json'
            
            os.makedirs('data/scraped', exist_ok=True)
            
            # Convert DataFrames to dictionaries for JSON serialization
            serializable_data = self.prepare_data_for_json(scraped_data)
            
            with open(f'data/scraped/{filename}', 'w') as f:
                json.dump(serializable_data, f, default=str, indent=2)
            
            print(f"Scraped data saved to data/scraped/{filename}")
        
        return scraped_data
    
    def prepare_data_for_json(self, data):
        """
        Prepare scraped data for JSON serialization
        """
        serializable_data = {}
        
        for key, value in data.items():
            if isinstance(value, pd.DataFrame):
                serializable_data[key] = value.to_dict('records')
            elif isinstance(value, dict):
                serializable_data[key] = {}
                for subkey, subvalue in value.items():
                    if isinstance(subvalue, pd.DataFrame):
                        serializable_data[key][subkey] = subvalue.to_dict('records')
                    else:
                        serializable_data[key][subkey] = subvalue
            else:
                serializable_data[key] = value
        
        return serializable_data
    
    def get_scraping_report(self, scraped_data):
        """
        Generate a report of the scraping session
        """
        report = {
            'scrape_timestamp': scraped_data.get('scrape_timestamp'),
            'teams_scraped': len(scraped_data.get('team_stats', {})),
            'total_matches': len(scraped_data.get('matches', [])),
            'total_players': sum(len(players) for players in scraped_data.get('player_data', {}).values()),
            'total_injuries': sum(len(injuries) for injuries in scraped_data.get('injuries', {}).values()),
            'total_transfers': len(scraped_data.get('transfers', [])),
            'news_articles': sum(len(news) for news in scraped_data.get('news_sentiment', {}).values()),
            'data_quality': 'Good',  # Would implement actual quality checks
            'sources_used': ['Simulated Data'],  # Would list actual sources
        }
        
        return report
