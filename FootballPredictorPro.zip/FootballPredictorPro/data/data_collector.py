import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import time
import os
import json
from data.web_scraper import FootballDataScraper
import warnings
warnings.filterwarnings('ignore')

class FootballDataCollector:
    """
    Comprehensive football data collection system
    """
    
    def __init__(self):
        self.scraper = FootballDataScraper()
        self.data_cache = {}
        self.last_update = None
        
    def generate_sample_data(self, n_matches=1000, start_date=None, end_date=None):
        """Generate comprehensive sample football data for training"""
        print(f"Generating {n_matches} sample matches...")
        
        if start_date is None:
            start_date = datetime.now() - timedelta(days=365*2)  # 2 years ago
        if end_date is None:
            end_date = datetime.now()
        
        # Premier League teams
        teams = [
            'Arsenal', 'Chelsea', 'Liverpool', 'Manchester City', 'Manchester United',
            'Tottenham', 'Newcastle', 'Brighton', 'Aston Villa', 'West Ham',
            'Crystal Palace', 'Fulham', 'Brentford', 'Wolves', 'Everton',
            'Nottingham Forest', 'Leeds United', 'Leicester City', 'Southampton', 'Bournemouth'
        ]
        
        # Venues
        venues = [
            'Emirates Stadium', 'Stamford Bridge', 'Anfield', 'Etihad Stadium',
            'Old Trafford', 'Tottenham Hotspur Stadium', 'St. James Park',
            'Amex Stadium', 'Villa Park', 'London Stadium'
        ]
        
        # Referees
        referees = [
            'Michael Oliver', 'Anthony Taylor', 'Paul Tierney', 'Andre Marriner',
            'Stuart Attwell', 'Mike Dean', 'Craig Pawson', 'Chris Kavanagh'
        ]
        
        matches = []
        
        for i in range(n_matches):
            # Random date between start and end
            random_date = start_date + timedelta(
                days=np.random.randint(0, (end_date - start_date).days)
            )
            
            # Select teams (ensure they're different)
            home_team = np.random.choice(teams)
            away_team = np.random.choice([t for t in teams if t != home_team])
            
            # Team strengths (simplified)
            team_strength = {
                'Manchester City': 90, 'Liverpool': 88, 'Arsenal': 85, 'Chelsea': 82,
                'Manchester United': 80, 'Tottenham': 78, 'Newcastle': 75, 'Brighton': 72,
                'Aston Villa': 70, 'West Ham': 68, 'Crystal Palace': 65, 'Fulham': 63,
                'Brentford': 60, 'Wolves': 58, 'Everton': 55, 'Nottingham Forest': 52,
                'Leeds United': 50, 'Leicester City': 48, 'Southampton': 45, 'Bournemouth': 42
            }
            
            home_strength = team_strength.get(home_team, 60)
            away_strength = team_strength.get(away_team, 60)
            
            # Home advantage
            home_advantage = 5
            
            # Calculate probabilities
            strength_diff = (home_strength + home_advantage) - away_strength
            
            # Probability of home win (sigmoid function)
            home_win_prob = 1 / (1 + np.exp(-strength_diff / 20))
            away_win_prob = 1 / (1 + np.exp(strength_diff / 20))
            draw_prob = 1 - home_win_prob - away_win_prob
            
            # Normalize probabilities
            total_prob = home_win_prob + draw_prob + away_win_prob
            home_win_prob /= total_prob
            draw_prob /= total_prob
            away_win_prob /= total_prob
            
            # Determine result
            rand = np.random.random()
            if rand < home_win_prob:
                result = 'H'
                # Home win - higher home goals
                home_goals = np.random.poisson(2.2)
                away_goals = np.random.poisson(1.1)
                if home_goals <= away_goals:
                    home_goals = away_goals + 1
            elif rand < home_win_prob + draw_prob:
                result = 'D'
                # Draw
                goals = np.random.poisson(1.5)
                home_goals = goals
                away_goals = goals
            else:
                result = 'A'
                # Away win - higher away goals
                home_goals = np.random.poisson(1.0)
                away_goals = np.random.poisson(1.8)
                if away_goals <= home_goals:
                    away_goals = home_goals + 1
            
            # Additional match statistics
            match_data = {
                'match_date': random_date,
                'home_team': home_team,
                'away_team': away_team,
                'home_goals': home_goals,
                'away_goals': away_goals,
                'result': result,
                'venue': np.random.choice(venues),
                'league': 'Premier League',
                'referee': np.random.choice(referees),
                
                # Extended statistics
                'home_shots': max(home_goals * 3 + np.random.poisson(5), home_goals),
                'away_shots': max(away_goals * 3 + np.random.poisson(5), away_goals),
                'home_shots_on_target': min(np.random.poisson(home_goals + 2), home_goals * 2 + 3),
                'away_shots_on_target': min(np.random.poisson(away_goals + 2), away_goals * 2 + 3),
                'home_possession': np.random.normal(50 + strength_diff/4, 10),
                'away_possession': 0,  # Will be calculated
                'home_corners': np.random.poisson(5),
                'away_corners': np.random.poisson(5),
                'home_fouls': np.random.poisson(12),
                'away_fouls': np.random.poisson(12),
                'home_yellow_cards': np.random.poisson(2),
                'away_yellow_cards': np.random.poisson(2),
                'home_red_cards': np.random.poisson(0.1),
                'away_red_cards': np.random.poisson(0.1),
                
                # Market data (for betting analysis)
                'home_odds': 1 / max(home_win_prob, 0.1) + np.random.normal(0, 0.1),
                'draw_odds': 1 / max(draw_prob, 0.1) + np.random.normal(0, 0.1),
                'away_odds': 1 / max(away_win_prob, 0.1) + np.random.normal(0, 0.1),
                
                # Additional context
                'attendance': np.random.randint(30000, 75000),
                'temperature': np.random.normal(15, 8),  # Celsius
                'weather_condition': np.random.choice(['Clear', 'Cloudy', 'Rain', 'Snow'], p=[0.4, 0.3, 0.25, 0.05])
            }
            
            # Calculate away possession
            match_data['away_possession'] = 100 - match_data['home_possession']
            
            # Ensure logical constraints
            match_data['home_shots_on_target'] = min(match_data['home_shots_on_target'], match_data['home_shots'])
            match_data['away_shots_on_target'] = min(match_data['away_shots_on_target'], match_data['away_shots'])
            
            matches.append(match_data)
        
        df = pd.DataFrame(matches)
        df = df.sort_values('match_date').reset_index(drop=True)
        
        print(f"Generated {len(df)} matches from {df['match_date'].min()} to {df['match_date'].max()}")
        print(f"Result distribution: {df['result'].value_counts().to_dict()}")
        
        return df
    
    def collect_team_statistics(self, team_name, season='2023-24'):
        """Collect comprehensive team statistics"""
        # In a real implementation, this would fetch from APIs
        # For now, we'll generate realistic statistics
        
        team_stats = {
            'team_name': team_name,
            'season': season,
            'games_played': np.random.randint(25, 38),
            'wins': 0,
            'draws': 0,
            'losses': 0,
            'goals_for': 0,
            'goals_against': 0,
            'points': 0,
            'home_record': {'wins': 0, 'draws': 0, 'losses': 0},
            'away_record': {'wins': 0, 'draws': 0, 'losses': 0},
            'form_last_5': [],
            'avg_possession': np.random.uniform(45, 65),
            'avg_shots_per_game': np.random.uniform(10, 20),
            'avg_shots_on_target': np.random.uniform(4, 8),
            'pass_accuracy': np.random.uniform(75, 90),
            'clean_sheets': np.random.randint(5, 20),
            'goals_per_game': np.random.uniform(1.0, 2.5),
            'goals_conceded_per_game': np.random.uniform(0.8, 2.0),
            'xg_for': np.random.uniform(40, 80),
            'xg_against': np.random.uniform(30, 70)
        }
        
        # Calculate derived statistics
        games = team_stats['games_played']
        team_stats['wins'] = np.random.randint(games//4, games//2)
        team_stats['losses'] = np.random.randint(games//4, games//2)
        team_stats['draws'] = games - team_stats['wins'] - team_stats['losses']
        team_stats['points'] = team_stats['wins'] * 3 + team_stats['draws']
        team_stats['goals_for'] = int(team_stats['goals_per_game'] * games)
        team_stats['goals_against'] = int(team_stats['goals_conceded_per_game'] * games)
        
        return team_stats
    
    def collect_player_data(self, team_name):
        """Collect player statistics and injury information"""
        # Sample player data structure
        positions = ['GK', 'DEF', 'MID', 'FWD']
        player_count = {'GK': 2, 'DEF': 6, 'MID': 6, 'FWD': 4}
        
        players = []
        
        for position, count in player_count.items():
            for i in range(count):
                player = {
                    'name': f'{position}_Player_{i+1}',
                    'position': position,
                    'age': np.random.randint(18, 35),
                    'nationality': np.random.choice(['England', 'Brazil', 'Spain', 'France', 'Germany']),
                    'market_value': np.random.uniform(5, 100),  # Million euros
                    'games_played': np.random.randint(15, 38),
                    'goals': np.random.randint(0, 20) if position == 'FWD' else np.random.randint(0, 10),
                    'assists': np.random.randint(0, 15),
                    'yellow_cards': np.random.randint(0, 10),
                    'red_cards': np.random.randint(0, 2),
                    'injury_status': np.random.choice(['Fit', 'Minor Injury', 'Major Injury'], p=[0.8, 0.15, 0.05]),
                    'form_rating': np.random.uniform(6.0, 9.0)
                }
                
                if position == 'GK':
                    player.update({
                        'clean_sheets': np.random.randint(5, 20),
                        'saves_per_game': np.random.uniform(2, 6),
                        'goals_conceded': np.random.randint(20, 50)
                    })
                
                players.append(player)
        
        return players
    
    def collect_weather_data(self, venue, match_date):
        """Collect weather data for match prediction"""
        # In production, this would use weather APIs
        weather_data = {
            'venue': venue,
            'date': match_date,
            'temperature': np.random.normal(15, 10),  # Celsius
            'humidity': np.random.uniform(30, 90),  # Percentage
            'wind_speed': np.random.exponential(5),  # km/h
            'precipitation': np.random.exponential(2),  # mm
            'visibility': np.random.uniform(5, 20),  # km
            'pressure': np.random.normal(1013, 20),  # hPa
            'condition': np.random.choice(['Clear', 'Cloudy', 'Rain', 'Snow', 'Fog'])
        }
        
        return weather_data
    
    def collect_betting_odds(self, home_team, away_team, match_date):
        """Collect betting odds from multiple bookmakers"""
        # Simulate odds from different bookmakers
        bookmakers = ['Bet365', 'William Hill', 'Paddy Power', 'Ladbrokes', 'Coral']
        
        # Base odds calculation (simplified)
        base_home_odds = np.random.uniform(1.5, 4.0)
        base_draw_odds = np.random.uniform(3.0, 4.5)
        base_away_odds = np.random.uniform(1.5, 4.0)
        
        odds_data = {}
        
        for bookmaker in bookmakers:
            # Add slight variation for each bookmaker
            variation = np.random.normal(1, 0.05)
            odds_data[bookmaker] = {
                'home_win': round(base_home_odds * variation, 2),
                'draw': round(base_draw_odds * variation, 2),
                'away_win': round(base_away_odds * variation, 2),
                'over_2_5': round(np.random.uniform(1.6, 2.2), 2),
                'under_2_5': round(np.random.uniform(1.6, 2.2), 2),
                'btts_yes': round(np.random.uniform(1.7, 2.1), 2),
                'btts_no': round(np.random.uniform(1.7, 2.1), 2)
            }
        
        # Calculate average odds
        avg_odds = {
            'home_win': np.mean([odds['home_win'] for odds in odds_data.values()]),
            'draw': np.mean([odds['draw'] for odds in odds_data.values()]),
            'away_win': np.mean([odds['away_win'] for odds in odds_data.values()]),
            'over_2_5': np.mean([odds['over_2_5'] for odds in odds_data.values()]),
            'under_2_5': np.mean([odds['under_2_5'] for odds in odds_data.values()])
        }
        
        return {
            'bookmaker_odds': odds_data,
            'average_odds': avg_odds,
            'odds_movement': np.random.choice(['Stable', 'Home Shortening', 'Away Shortening'])
        }
    
    def collect_referee_data(self, referee_name):
        """Collect referee statistics and tendencies"""
        referee_stats = {
            'name': referee_name,
            'games_officiated': np.random.randint(20, 40),
            'avg_cards_per_game': np.random.uniform(3, 6),
            'avg_yellow_cards': np.random.uniform(2.5, 5.5),
            'avg_red_cards': np.random.uniform(0.1, 0.3),
            'penalty_frequency': np.random.uniform(0.2, 0.5),  # Penalties per game
            'home_bias': np.random.uniform(-0.1, 0.1),  # Tendency to favor home team
            'strict_rating': np.random.uniform(6, 10),  # How strict the referee is
            'consistency_rating': np.random.uniform(7, 10)
        }
        
        return referee_stats
    
    def update_all_data(self, leagues=['Premier League'], save_to_file=True):
        """Update all football data"""
        print("Starting comprehensive data update...")
        
        all_data = {
            'matches': self.generate_sample_data(n_matches=2000),
            'team_stats': {},
            'player_data': {},
            'weather_cache': {},
            'betting_odds': {},
            'referee_stats': {},
            'last_updated': datetime.now()
        }
        
        # Get unique teams from matches
        teams = pd.concat([
            all_data['matches']['home_team'],
            all_data['matches']['away_team']
        ]).unique()
        
        # Collect team statistics
        print("Collecting team statistics...")
        for team in teams:
            all_data['team_stats'][team] = self.collect_team_statistics(team)
            all_data['player_data'][team] = self.collect_player_data(team)
        
        # Collect referee statistics
        print("Collecting referee data...")
        referees = all_data['matches']['referee'].unique()
        for referee in referees:
            all_data['referee_stats'][referee] = self.collect_referee_data(referee)
        
        # Cache the data
        self.data_cache = all_data
        self.last_update = datetime.now()
        
        if save_to_file:
            # Save to JSON file
            filename = f"football_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            # Convert datetime objects to strings for JSON serialization
            serializable_data = self.convert_datetime_to_string(all_data.copy())
            
            os.makedirs('data/cache', exist_ok=True)
            with open(f'data/cache/{filename}', 'w') as f:
                json.dump(serializable_data, f, default=str, indent=2)
            
            print(f"Data saved to data/cache/{filename}")
        
        print("Data update completed!")
        return all_data
    
    def convert_datetime_to_string(self, data):
        """Convert datetime objects to strings for JSON serialization"""
        if isinstance(data, dict):
            return {k: self.convert_datetime_to_string(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self.convert_datetime_to_string(item) for item in data]
        elif isinstance(data, pd.DataFrame):
            return data.to_dict('records')
        elif isinstance(data, (datetime, pd.Timestamp)):
            return data.strftime('%Y-%m-%d %H:%M:%S')
        else:
            return data
    
    def get_match_prediction_data(self, home_team, away_team, match_date, venue=None):
        """Collect all data needed for a specific match prediction"""
        print(f"Collecting prediction data for {home_team} vs {away_team}")
        
        prediction_data = {
            'match_info': {
                'home_team': home_team,
                'away_team': away_team,
                'match_date': match_date,
                'venue': venue or f"{home_team} Stadium"
            },
            'team_stats': {
                'home': self.collect_team_statistics(home_team),
                'away': self.collect_team_statistics(away_team)
            },
            'player_data': {
                'home': self.collect_player_data(home_team),
                'away': self.collect_player_data(away_team)
            },
            'weather': self.collect_weather_data(venue or f"{home_team} Stadium", match_date),
            'betting_odds': self.collect_betting_odds(home_team, away_team, match_date),
            'referee': self.collect_referee_data("Michael Oliver"),  # Default referee
            'historical_h2h': self.get_head_to_head_history(home_team, away_team)
        }
        
        return prediction_data
    
    def get_head_to_head_history(self, team1, team2, last_n_games=10):
        """Get head-to-head history between two teams"""
        # In a real implementation, this would query historical match data
        h2h_matches = []
        
        for i in range(last_n_games):
            # Generate realistic H2H data
            match_date = datetime.now() - timedelta(days=np.random.randint(30, 1000))
            
            # Randomly assign home/away
            if np.random.random() > 0.5:
                home_team, away_team = team1, team2
            else:
                home_team, away_team = team2, team1
            
            # Generate result
            result = np.random.choice(['H', 'D', 'A'], p=[0.4, 0.3, 0.3])
            
            if result == 'H':
                home_goals = np.random.randint(1, 4)
                away_goals = np.random.randint(0, home_goals)
            elif result == 'A':
                away_goals = np.random.randint(1, 4)
                home_goals = np.random.randint(0, away_goals)
            else:
                goals = np.random.randint(0, 3)
                home_goals = away_goals = goals
            
            h2h_match = {
                'date': match_date,
                'home_team': home_team,
                'away_team': away_team,
                'home_goals': home_goals,
                'away_goals': away_goals,
                'result': result
            }
            
            h2h_matches.append(h2h_match)
        
        return sorted(h2h_matches, key=lambda x: x['date'], reverse=True)
    
    def get_data_quality_report(self):
        """Generate data quality report"""
        if not self.data_cache:
            return "No data available for quality assessment"
        
        matches_df = pd.DataFrame(self.data_cache['matches'])
        
        quality_report = {
            'total_matches': len(matches_df),
            'date_range': {
                'start': matches_df['match_date'].min(),
                'end': matches_df['match_date'].max()
            },
            'unique_teams': matches_df['home_team'].nunique(),
            'unique_venues': matches_df['venue'].nunique(),
            'missing_data': {
                'goals': matches_df[['home_goals', 'away_goals']].isnull().sum().sum(),
                'stats': matches_df[['home_shots', 'away_shots']].isnull().sum().sum(),
                'weather': 0  # Weather data is generated, so no missing values
            },
            'data_consistency': {
                'possession_sum_100': (abs(matches_df['home_possession'] + matches_df['away_possession'] - 100) < 1).mean(),
                'shots_logical': (matches_df['home_shots'] >= matches_df['home_shots_on_target']).mean()
            },
            'last_updated': self.last_update
        }
        
        return quality_report
