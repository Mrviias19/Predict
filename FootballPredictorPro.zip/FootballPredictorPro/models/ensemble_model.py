import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.model_selection import cross_val_score, TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report, brier_score_loss
import xgboost as xgb
import lightgbm as lgb
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

class FootballPredictionEnsemble:
    """
    Advanced ensemble model for football match prediction combining multiple ML algorithms
    """
    
    def __init__(self):
        self.models = {}
        self.ensemble = None
        self.scaler = StandardScaler()
        self.feature_names = None
        self.is_trained = False
        
    def create_models(self):
        """Create and configure individual models"""
        
        # Random Forest Model
        self.models['random_forest'] = RandomForestClassifier(
            n_estimators=200,
            max_depth=15,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        
        # XGBoost Model
        self.models['xgboost'] = xgb.XGBClassifier(
            n_estimators=200,
            max_depth=8,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            eval_metric='logloss'
        )
        
        # LightGBM Model
        self.models['lightgbm'] = lgb.LGBMClassifier(
            n_estimators=200,
            max_depth=8,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            verbose=-1
        )
        
    def create_neural_network(self, input_dim):
        """Create neural network model"""
        model = Sequential([
            Dense(128, activation='relu', input_dim=input_dim),
            BatchNormalization(),
            Dropout(0.3),
            
            Dense(64, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            
            Dense(32, activation='relu'),
            BatchNormalization(),
            Dropout(0.2),
            
            Dense(16, activation='relu'),
            Dropout(0.2),
            
            Dense(3, activation='softmax')  # 3 classes: Home Win, Draw, Away Win
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def prepare_data(self, X, y=None):
        """Prepare and scale data for training/prediction"""
        if y is not None:
            # Training phase
            X_scaled = self.scaler.fit_transform(X)
            self.feature_names = X.columns.tolist() if hasattr(X, 'columns') else None
            return X_scaled, y
        else:
            # Prediction phase
            X_scaled = self.scaler.transform(X)
            return X_scaled
    
    def train(self, X, y, validation_split=0.2):
        """Train the ensemble model"""
        print("Starting model training...")
        
        # Prepare data
        X_scaled, y = self.prepare_data(X, y)
        
        # Create models
        self.create_models()
        
        # Split data for neural network training
        split_idx = int(len(X_scaled) * (1 - validation_split))
        X_train, X_val = X_scaled[:split_idx], X_scaled[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Train individual models
        print("Training Random Forest...")
        self.models['random_forest'].fit(X_scaled, y)
        
        print("Training XGBoost...")
        self.models['xgboost'].fit(X_scaled, y)
        
        print("Training LightGBM...")
        self.models['lightgbm'].fit(X_scaled, y)
        
        print("Training Neural Network...")
        self.models['neural_network'] = self.create_neural_network(X_scaled.shape[1])
        self.models['neural_network'].fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=100,
            batch_size=32,
            verbose=0
        )
        
        # Create ensemble using voting classifier (excluding neural network for now)
        self.ensemble = VotingClassifier(
            estimators=[
                ('rf', self.models['random_forest']),
                ('xgb', self.models['xgboost']),
                ('lgb', self.models['lightgbm'])
            ],
            voting='soft'
        )
        
        self.ensemble.fit(X_scaled, y)
        self.is_trained = True
        
        print("Model training completed!")
        return self.evaluate_models(X_scaled, y)
    
    def predict(self, X):
        """Make predictions using the ensemble model"""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        X_scaled = self.prepare_data(X)
        
        # Get predictions from all models
        predictions = {}
        
        # Tree-based models predictions
        predictions['ensemble'] = self.ensemble.predict_proba(X_scaled)
        predictions['random_forest'] = self.models['random_forest'].predict_proba(X_scaled)
        predictions['xgboost'] = self.models['xgboost'].predict_proba(X_scaled)
        predictions['lightgbm'] = self.models['lightgbm'].predict_proba(X_scaled)
        
        # Neural network predictions
        nn_pred = self.models['neural_network'].predict(X_scaled, verbose=0)
        predictions['neural_network'] = nn_pred
        
        # Create final ensemble prediction (weighted average)
        final_prediction = (
            0.3 * predictions['ensemble'] +
            0.25 * predictions['random_forest'] +
            0.25 * predictions['xgboost'] +
            0.2 * predictions['neural_network']
        )
        
        return {
            'final_prediction': final_prediction,
            'individual_predictions': predictions,
            'predicted_class': np.argmax(final_prediction, axis=1),
            'confidence': np.max(final_prediction, axis=1)
        }
    
    def evaluate_models(self, X, y):
        """Evaluate individual models and ensemble"""
        results = {}
        
        # Time series cross-validation
        tscv = TimeSeriesSplit(n_splits=5)
        
        for name, model in self.models.items():
            if name == 'neural_network':
                continue  # Skip neural network for cross-validation
            
            scores = cross_val_score(model, X, y, cv=tscv, scoring='accuracy')
            results[name] = {
                'mean_accuracy': scores.mean(),
                'std_accuracy': scores.std(),
                'scores': scores
            }
        
        # Ensemble evaluation
        ensemble_scores = cross_val_score(self.ensemble, X, y, cv=tscv, scoring='accuracy')
        results['ensemble'] = {
            'mean_accuracy': ensemble_scores.mean(),
            'std_accuracy': ensemble_scores.std(),
            'scores': ensemble_scores
        }
        
        return results
    
    def get_feature_importance(self):
        """Get feature importance from trained models"""
        if not self.is_trained:
            raise ValueError("Model must be trained before getting feature importance")
        
        importance_data = {}
        
        # Random Forest importance
        rf_importance = self.models['random_forest'].feature_importances_
        importance_data['random_forest'] = rf_importance
        
        # XGBoost importance
        xgb_importance = self.models['xgboost'].feature_importances_
        importance_data['xgboost'] = xgb_importance
        
        # LightGBM importance
        lgb_importance = self.models['lightgbm'].feature_importances_
        importance_data['lightgbm'] = lgb_importance
        
        # Average importance
        avg_importance = (rf_importance + xgb_importance + lgb_importance) / 3
        importance_data['average'] = avg_importance
        
        if self.feature_names:
            importance_df = pd.DataFrame({
                'feature': self.feature_names,
                'random_forest': rf_importance,
                'xgboost': xgb_importance,
                'lightgbm': lgb_importance,
                'average': avg_importance
            }).sort_values('average', ascending=False)
            
            return importance_df
        
        return importance_data
    
    def save_model(self, filepath):
        """Save the trained model"""
        if not self.is_trained:
            raise ValueError("Model must be trained before saving")
        
        model_data = {
            'models': {k: v for k, v in self.models.items() if k != 'neural_network'},
            'ensemble': self.ensemble,
            'scaler': self.scaler,
            'feature_names': self.feature_names,
            'is_trained': self.is_trained
        }
        
        # Save neural network separately
        nn_path = filepath.replace('.pkl', '_nn.h5')
        self.models['neural_network'].save(nn_path)
        
        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath):
        """Load a trained model"""
        from tensorflow.keras.models import load_model
        
        model_data = joblib.load(filepath)
        
        self.models = model_data['models']
        self.ensemble = model_data['ensemble']
        self.scaler = model_data['scaler']
        self.feature_names = model_data['feature_names']
        self.is_trained = model_data['is_trained']
        
        # Load neural network
        nn_path = filepath.replace('.pkl', '_nn.h5')
        if os.path.exists(nn_path):
            self.models['neural_network'] = load_model(nn_path)
        
        print(f"Model loaded from {filepath}")
    
    def predict_match_details(self, X):
        """Provide detailed match predictions including confidence intervals"""
        predictions = self.predict(X)
        
        final_pred = predictions['final_prediction']
        confidence = predictions['confidence']
        
        results = []
        class_names = ['Home Win', 'Draw', 'Away Win']
        
        for i in range(len(final_pred)):
            pred_probs = final_pred[i]
            conf = confidence[i]
            predicted_class = np.argmax(pred_probs)
            
            result = {
                'predicted_outcome': class_names[predicted_class],
                'probabilities': {
                    'home_win': pred_probs[0],
                    'draw': pred_probs[1],
                    'away_win': pred_probs[2]
                },
                'confidence': conf,
                'risk_level': 'Low' if conf > 0.7 else 'Medium' if conf > 0.5 else 'High',
                'recommended_bet': class_names[predicted_class] if conf > 0.6 else 'No recommendation'
            }
            
            results.append(result)
        
        return results
