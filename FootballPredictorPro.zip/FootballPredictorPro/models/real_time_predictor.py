import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import asyncio
import concurrent.futures
from typing import Dict, List, Optional, Tuple


class RealTimePredictionEngine:
    """
    Real-time prediction engine with live data updates and dynamic model adjustment
    """
    
    def __init__(self):
        self.live_data_cache = {}
        self.prediction_cache = {}
        self.cache_expiry = 300  # 5 minutes
        self.confidence_boost_factors = {
            'recent_form': 0.15,
            'injury_update': 0.10,
            'weather_change': 0.05,
            'lineup_confirmed': 0.12,
            'market_movement': 0.08
        }
        
    def get_live_match_context(self, home_team: str, away_team: str, match_date: datetime) -> Dict:
        """Get real-time match context and updates"""
        
        # Simulate real-time data updates
        live_context = {
            'match_id': f"{home_team}_{away_team}_{match_date.strftime('%Y%m%d')}",
            'last_updated': datetime.now(),
            'data_freshness': self.calculate_data_freshness(match_date),
            'live_updates': self.get_live_updates(home_team, away_team),
            'pre_match_intel': self.get_pre_match_intelligence(home_team, away_team),
            'market_sentiment': self.get_market_sentiment(home_team, away_team),
            'social_sentiment': self.get_social_sentiment(home_team, away_team)
        }
        
        return live_context
    
    def calculate_data_freshness(self, match_date: datetime) -> Dict:
        """Calculate how fresh different data sources are"""
        
        now = datetime.now()
        time_to_match = (match_date - now).total_seconds() / 3600  # hours
        
        freshness_scores = {
            'team_news': min(1.0, max(0.1, 1 - (abs(time_to_match - 2) / 48))),  # Peak 2h before match
            'injury_reports': min(1.0, max(0.3, 1 - (abs(time_to_match - 24) / 72))),  # Peak 24h before
            'weather_forecast': min(1.0, max(0.5, 1 - (abs(time_to_match) / 24))),  # Peak at match time
            'betting_odds': min(1.0, max(0.7, 1 - (abs(time_to_match) / 12))),  # Always relatively fresh
            'lineup_rumors': min(1.0, max(0.2, 1 - (abs(time_to_match - 1) / 24)))  # Peak 1h before
        }
        
        return {
            'scores': freshness_scores,
            'overall_freshness': np.mean(list(freshness_scores.values())),
            'time_to_match_hours': time_to_match
        }
    
    def get_live_updates(self, home_team: str, away_team: str) -> List[Dict]:
        """Simulate live updates and breaking news"""
        
        possible_updates = [
            {
                'type': 'injury',
                'impact': 'high',
                'message': f'Key player ruled out for {home_team}',
                'confidence_impact': -0.08,
                'team_affected': 'home'
            },
            {
                'type': 'lineup',
                'impact': 'medium',
                'message': f'Star striker confirmed to start for {away_team}',
                'confidence_impact': 0.05,
                'team_affected': 'away'
            },
            {
                'type': 'weather',
                'impact': 'low',
                'message': 'Heavy rain expected during match',
                'confidence_impact': -0.02,
                'team_affected': 'both'
            },
            {
                'type': 'tactical',
                'impact': 'medium',
                'message': f'{home_team} manager hints at formation change',
                'confidence_impact': 0.03,
                'team_affected': 'home'
            },
            {
                'type': 'motivation',
                'impact': 'low',
                'message': f'{away_team} playing for European qualification',
                'confidence_impact': 0.04,
                'team_affected': 'away'
            }
        ]
        
        # Randomly select 0-3 updates
        num_updates = min(3, max(0, np.random.poisson(1.5)))
        if num_updates > 0:
            indices = np.random.choice(
                len(possible_updates), 
                size=min(num_updates, len(possible_updates)), 
                replace=False
            )
            selected_updates = [possible_updates[i] for i in indices]
        else:
            selected_updates = []
        
        # Add timestamps
        for update in selected_updates:
            update['timestamp'] = datetime.now() - timedelta(minutes=np.random.randint(5, 180))
            update['reliability'] = np.random.uniform(0.6, 0.95)
        
        return selected_updates
    
    def get_pre_match_intelligence(self, home_team: str, away_team: str) -> Dict:
        """Gather pre-match intelligence and insider information"""
        
        intelligence = {
            'team_morale': {
                'home': np.random.uniform(0.4, 0.9),
                'away': np.random.uniform(0.4, 0.9)
            },
            'training_reports': {
                'home_intensity': np.random.uniform(0.6, 1.0),
                'away_intensity': np.random.uniform(0.6, 1.0)
            },
            'tactical_preparation': {
                'home_preparation_quality': np.random.uniform(0.5, 0.95),
                'away_preparation_quality': np.random.uniform(0.5, 0.95)
            },
            'player_availability': {
                'home_full_squad_available': np.random.choice([True, False], p=[0.7, 0.3]),
                'away_full_squad_available': np.random.choice([True, False], p=[0.7, 0.3])
            },
            'internal_pressure': {
                'home_pressure_level': np.random.uniform(0.2, 0.8),
                'away_pressure_level': np.random.uniform(0.2, 0.8)
            }
        }
        
        return intelligence
    
    def get_market_sentiment(self, home_team: str, away_team: str) -> Dict:
        """Analyze betting market sentiment and movements"""
        
        sentiment = {
            'sharp_money_direction': np.random.choice(['home', 'draw', 'away']),
            'public_betting_split': {
                'home': np.random.uniform(0.2, 0.6),
                'draw': np.random.uniform(0.1, 0.3),
                'away': np.random.uniform(0.2, 0.6)
            },
            'odds_movements': {
                'home_trend': np.random.choice(['shortening', 'drifting', 'stable']),
                'home_movement_magnitude': np.random.uniform(0.0, 0.15),
                'volume_indicator': np.random.uniform(0.3, 1.0)
            },
            'market_confidence': np.random.uniform(0.6, 0.9),
            'arbitrage_opportunities': np.random.choice([True, False], p=[0.15, 0.85])
        }
        
        # Normalize betting split
        total_split = sum(sentiment['public_betting_split'].values())
        for outcome in sentiment['public_betting_split']:
            sentiment['public_betting_split'][outcome] /= total_split
        
        return sentiment
    
    def get_social_sentiment(self, home_team: str, away_team: str) -> Dict:
        """Analyze social media sentiment and fan confidence"""
        
        sentiment = {
            'fan_confidence': {
                'home': np.random.uniform(0.3, 0.8),
                'away': np.random.uniform(0.3, 0.8)
            },
            'social_buzz_volume': np.random.uniform(0.4, 1.0),
            'sentiment_polarity': {
                'home': np.random.uniform(-0.3, 0.5),  # -1 to 1 scale
                'away': np.random.uniform(-0.3, 0.5)
            },
            'trending_topics': [
                f'{home_team} tactics',
                f'{away_team} injuries',
                'match predictions'
            ],
            'expert_predictions_split': {
                'home': np.random.uniform(0.2, 0.6),
                'draw': np.random.uniform(0.1, 0.3),
                'away': np.random.uniform(0.2, 0.6)
            }
        }
        
        # Normalize expert predictions
        total_expert = sum(sentiment['expert_predictions_split'].values())
        for outcome in sentiment['expert_predictions_split']:
            sentiment['expert_predictions_split'][outcome] /= total_expert
        
        return sentiment
    
    def adjust_prediction_with_live_data(self, base_prediction: Dict, live_context: Dict) -> Dict:
        """Adjust base prediction using real-time data"""
        
        adjusted_prediction = base_prediction.copy()
        confidence_adjustments = []
        probability_adjustments = {'home': 0, 'draw': 0, 'away': 0}
        
        # Process live updates
        for update in live_context['live_updates']:
            reliability_factor = update['reliability']
            impact_magnitude = abs(update['confidence_impact']) * reliability_factor
            
            if update['team_affected'] == 'home':
                probability_adjustments['home'] += update['confidence_impact']
                probability_adjustments['away'] -= update['confidence_impact'] / 2
            elif update['team_affected'] == 'away':
                probability_adjustments['away'] += update['confidence_impact']
                probability_adjustments['home'] -= update['confidence_impact'] / 2
            else:  # both teams affected
                probability_adjustments['draw'] += update['confidence_impact']
            
            confidence_adjustments.append(impact_magnitude)
        
        # Apply market sentiment adjustments
        market_sentiment = live_context['market_sentiment']
        if market_sentiment['sharp_money_direction'] != 'draw':
            direction = market_sentiment['sharp_money_direction']
            magnitude = market_sentiment['odds_movements']['home_movement_magnitude']
            probability_adjustments[direction] += magnitude * 0.1
        
        # Apply social sentiment
        social_sentiment = live_context['social_sentiment']
        for team in ['home', 'away']:
            fan_impact = (social_sentiment['fan_confidence'][team] - 0.5) * 0.05
            probability_adjustments[team] += fan_impact
        
        # Apply intelligence factors
        intel = live_context['pre_match_intel']
        for team in ['home', 'away']:
            morale_impact = (intel['team_morale'][team] - 0.65) * 0.08
            training_impact = (intel['training_reports'][f'{team}_intensity'] - 0.8) * 0.03
            probability_adjustments[team] += morale_impact + training_impact
        
        # Normalize probability adjustments
        total_adjustment = sum(abs(adj) for adj in probability_adjustments.values())
        if total_adjustment > 0.15:  # Cap total adjustment at 15%
            scale_factor = 0.15 / total_adjustment
            for outcome in probability_adjustments:
                probability_adjustments[outcome] *= scale_factor
        
        # Apply adjustments to probabilities
        for outcome in ['home', 'draw', 'away']:
            adjusted_prediction['probabilities'][outcome] = max(
                0.05,  # Minimum probability
                min(0.85,  # Maximum probability
                    base_prediction['probabilities'][outcome] + probability_adjustments[outcome]
                )
            )
        
        # Renormalize probabilities
        total_prob = sum(adjusted_prediction['probabilities'].values())
        for outcome in adjusted_prediction['probabilities']:
            adjusted_prediction['probabilities'][outcome] /= total_prob
        
        # Adjust confidence
        base_confidence = base_prediction.get('confidence', 0.7)
        confidence_impact = np.mean(confidence_adjustments) if confidence_adjustments else 0
        data_freshness_bonus = live_context['data_freshness']['overall_freshness'] * 0.1
        
        adjusted_prediction['confidence'] = max(
            0.3,
            min(0.95, base_confidence + confidence_impact + data_freshness_bonus)
        )
        
        # Add live data metadata
        adjusted_prediction['live_data_applied'] = True
        adjusted_prediction['live_updates_count'] = len(live_context['live_updates'])
        adjusted_prediction['data_freshness_score'] = live_context['data_freshness']['overall_freshness']
        adjusted_prediction['last_updated'] = datetime.now()
        
        return adjusted_prediction
    
    def generate_real_time_insights(self, live_context: Dict, adjusted_prediction: Dict) -> List[Dict]:
        """Generate insights based on real-time data"""
        
        insights = []
        
        # Live update insights
        high_impact_updates = [
            update for update in live_context['live_updates'] 
            if abs(update['confidence_impact']) > 0.05
        ]
        
        if high_impact_updates:
            insights.append({
                'type': 'live_update',
                'title': 'Breaking News Impact',
                'message': f"{len(high_impact_updates)} significant updates may affect the outcome",
                'details': [update['message'] for update in high_impact_updates],
                'confidence': 'high'
            })
        
        # Market movement insights
        market = live_context['market_sentiment']
        if market['odds_movements']['home_movement_magnitude'] > 0.1:
            direction = "towards" if market['odds_movements']['home_trend'] == 'shortening' else "away from"
            insights.append({
                'type': 'market',
                'title': 'Significant Market Movement',
                'message': f"Odds moving {direction} home team - {market['sharp_money_direction']} money detected",
                'confidence': 'medium'
            })
        
        # Data freshness insights
        freshness = live_context['data_freshness']
        if freshness['overall_freshness'] > 0.8:
            insights.append({
                'type': 'data_quality',
                'title': 'High-Quality Real-Time Data',
                'message': f"Prediction based on very fresh data ({freshness['overall_freshness']:.1%} freshness)",
                'confidence': 'high'
            })
        elif freshness['overall_freshness'] < 0.5:
            insights.append({
                'type': 'warning',
                'title': 'Limited Real-Time Data',
                'message': f"Prediction may be less accurate due to stale data ({freshness['overall_freshness']:.1%} freshness)",
                'confidence': 'medium'
            })
        
        # Sentiment insights
        social = live_context['social_sentiment']
        fan_confidence_diff = abs(social['fan_confidence']['home'] - social['fan_confidence']['away'])
        if fan_confidence_diff > 0.3:
            favorite_team = 'home' if social['fan_confidence']['home'] > social['fan_confidence']['away'] else 'away'
            insights.append({
                'type': 'sentiment',
                'title': 'Strong Fan Sentiment Bias',
                'message': f"Significant confidence difference favoring {favorite_team} team",
                'confidence': 'medium'
            })
        
        return insights
    
    def create_live_prediction_summary(self, home_team: str, away_team: str, 
                                     base_prediction: Dict, live_context: Dict, 
                                     adjusted_prediction: Dict) -> Dict:
        """Create comprehensive live prediction summary"""
        
        summary = {
            'match_info': {
                'home_team': home_team,
                'away_team': away_team,
                'prediction_time': datetime.now(),
                'data_sources_used': len(live_context['live_updates']) + 4  # base + market + social + intel
            },
            'prediction_evolution': {
                'base_probabilities': base_prediction['probabilities'],
                'live_adjusted_probabilities': adjusted_prediction['probabilities'],
                'confidence_change': adjusted_prediction['confidence'] - base_prediction.get('confidence', 0.7),
                'key_adjustments': self.identify_key_adjustments(base_prediction, adjusted_prediction)
            },
            'live_factors': {
                'breaking_news_count': len(live_context['live_updates']),
                'market_activity_level': live_context['market_sentiment']['volume_indicator'],
                'social_buzz_level': live_context['social_sentiment']['social_buzz_volume'],
                'data_reliability': live_context['data_freshness']['overall_freshness']
            },
            'insights': self.generate_real_time_insights(live_context, adjusted_prediction),
            'recommendation_strength': self.calculate_recommendation_strength(adjusted_prediction, live_context)
        }
        
        return summary
    
    def identify_key_adjustments(self, base_prediction: Dict, adjusted_prediction: Dict) -> List[str]:
        """Identify the most significant adjustments made"""
        
        adjustments = []
        
        for outcome in ['home', 'draw', 'away']:
            change = adjusted_prediction['probabilities'][outcome] - base_prediction['probabilities'][outcome]
            if abs(change) > 0.03:  # 3% threshold
                direction = "increased" if change > 0 else "decreased"
                adjustments.append(f"{outcome.title()} probability {direction} by {abs(change):.1%}")
        
        return adjustments
    
    def calculate_recommendation_strength(self, prediction: Dict, live_context: Dict) -> str:
        """Calculate overall recommendation strength"""
        
        confidence = prediction['confidence']
        data_freshness = live_context['data_freshness']['overall_freshness']
        market_confidence = live_context['market_sentiment']['market_confidence']
        
        # Highest probability outcome
        max_prob = max(prediction['probabilities'].values())
        
        strength_score = (confidence * 0.4 + data_freshness * 0.3 + 
                         market_confidence * 0.2 + max_prob * 0.1)
        
        if strength_score > 0.8:
            return "Very Strong"
        elif strength_score > 0.65:
            return "Strong"
        elif strength_score > 0.5:
            return "Moderate"
        else:
            return "Weak"