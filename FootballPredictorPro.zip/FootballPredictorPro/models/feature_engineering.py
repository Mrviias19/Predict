import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.preprocessing import StandardScaler, LabelEncoder
import warnings
warnings.filterwarnings('ignore')

class FootballFeatureEngineer:
    """
    Advanced feature engineering for football match prediction
    """
    
    def __init__(self):
        self.team_encoder = LabelEncoder()
        self.venue_encoder = LabelEncoder()
        self.league_encoder = LabelEncoder()
        self.referee_encoder = LabelEncoder()
        self.is_fitted = False
        
    def create_base_features(self, df):
        """Create basic features from raw data"""
        features_df = df.copy()
        
        # Date features
        features_df['match_date'] = pd.to_datetime(features_df['match_date'])
        features_df['month'] = features_df['match_date'].dt.month
        features_df['day_of_week'] = features_df['match_date'].dt.dayofweek
        features_df['is_weekend'] = features_df['day_of_week'].isin([5, 6]).astype(int)
        
        # Season features
        features_df['season_month'] = features_df['match_date'].dt.month
        features_df['is_early_season'] = (features_df['season_month'] <= 9).astype(int)
        features_df['is_mid_season'] = ((features_df['season_month'] >= 10) & 
                                       (features_df['season_month'] <= 2)).astype(int)
        features_df['is_late_season'] = (features_df['season_month'] >= 3).astype(int)
        
        return features_df
    
    def create_form_features(self, df, team_col, result_col, n_games=5):
        """Create team form features based on recent results"""
        df = df.sort_values('match_date')
        
        # Initialize form columns
        form_cols = [f'form_{i}' for i in range(1, n_games + 1)]
        for col in form_cols:
            df[f'home_{col}'] = 0.0
            df[f'away_{col}'] = 0.0
        
        df['home_form_points'] = 0.0
        df['away_form_points'] = 0.0
        df['home_win_streak'] = 0
        df['away_win_streak'] = 0
        df['home_unbeaten_streak'] = 0
        df['away_unbeaten_streak'] = 0
        
        teams = df[team_col].unique()
        
        for team in teams:
            team_matches = df[(df['home_team'] == team) | (df['away_team'] == team)].copy()
            
            for i, (idx, match) in enumerate(team_matches.iterrows()):
                if i < n_games:
                    continue
                
                # Get last n_games results for this team
                recent_matches = team_matches.iloc[max(0, i-n_games):i]
                
                results = []
                points = 0
                win_streak = 0
                unbeaten_streak = 0
                
                for _, recent_match in recent_matches.iterrows():
                    if recent_match['home_team'] == team:
                        if recent_match['result'] == 'H':
                            results.append(3)  # Win
                            points += 3
                            win_streak += 1
                            unbeaten_streak += 1
                        elif recent_match['result'] == 'D':
                            results.append(1)  # Draw
                            points += 1
                            win_streak = 0
                            unbeaten_streak += 1
                        else:
                            results.append(0)  # Loss
                            win_streak = 0
                            unbeaten_streak = 0
                    else:  # Away team
                        if recent_match['result'] == 'A':
                            results.append(3)  # Win
                            points += 3
                            win_streak += 1
                            unbeaten_streak += 1
                        elif recent_match['result'] == 'D':
                            results.append(1)  # Draw
                            points += 1
                            win_streak = 0
                            unbeaten_streak += 1
                        else:
                            results.append(0)  # Loss
                            win_streak = 0
                            unbeaten_streak = 0
                
                # Update form features
                if match['home_team'] == team:
                    df.loc[idx, 'home_form_points'] = points
                    df.loc[idx, 'home_win_streak'] = win_streak
                    df.loc[idx, 'home_unbeaten_streak'] = unbeaten_streak
                    for j, result in enumerate(results[-n_games:]):
                        if j < len(form_cols):
                            df.loc[idx, f'home_form_{j+1}'] = result
                else:
                    df.loc[idx, 'away_form_points'] = points
                    df.loc[idx, 'away_win_streak'] = win_streak
                    df.loc[idx, 'away_unbeaten_streak'] = unbeaten_streak
                    for j, result in enumerate(results[-n_games:]):
                        if j < len(form_cols):
                            df.loc[idx, f'away_form_{j+1}'] = result
        
        return df
    
    def create_head_to_head_features(self, df):
        """Create head-to-head historical features"""
        df = df.sort_values('match_date')
        
        # Initialize H2H columns
        df['h2h_home_wins'] = 0
        df['h2h_away_wins'] = 0
        df['h2h_draws'] = 0
        df['h2h_total_games'] = 0
        df['h2h_home_win_rate'] = 0.0
        df['h2h_goals_for_avg'] = 0.0
        df['h2h_goals_against_avg'] = 0.0
        
        for i, (idx, match) in enumerate(df.iterrows()):
            home_team = match['home_team']
            away_team = match['away_team']
            
            # Get all previous matches between these teams
            h2h_matches = df[:i]
            h2h_matches = h2h_matches[
                ((h2h_matches['home_team'] == home_team) & (h2h_matches['away_team'] == away_team)) |
                ((h2h_matches['home_team'] == away_team) & (h2h_matches['away_team'] == home_team))
            ]
            
            if len(h2h_matches) > 0:
                home_wins = 0
                away_wins = 0
                draws = 0
                goals_for = []
                goals_against = []
                
                for _, h2h_match in h2h_matches.iterrows():
                    if h2h_match['home_team'] == home_team:
                        # Current home team was home in previous match
                        if h2h_match['result'] == 'H':
                            home_wins += 1
                        elif h2h_match['result'] == 'A':
                            away_wins += 1
                        else:
                            draws += 1
                        
                        if 'home_goals' in h2h_match and pd.notna(h2h_match['home_goals']):
                            goals_for.append(h2h_match['home_goals'])
                            goals_against.append(h2h_match['away_goals'])
                    else:
                        # Current home team was away in previous match
                        if h2h_match['result'] == 'A':
                            home_wins += 1
                        elif h2h_match['result'] == 'H':
                            away_wins += 1
                        else:
                            draws += 1
                        
                        if 'away_goals' in h2h_match and pd.notna(h2h_match['away_goals']):
                            goals_for.append(h2h_match['away_goals'])
                            goals_against.append(h2h_match['home_goals'])
                
                total_games = len(h2h_matches)
                df.loc[idx, 'h2h_home_wins'] = home_wins
                df.loc[idx, 'h2h_away_wins'] = away_wins
                df.loc[idx, 'h2h_draws'] = draws
                df.loc[idx, 'h2h_total_games'] = total_games
                df.loc[idx, 'h2h_home_win_rate'] = home_wins / total_games if total_games > 0 else 0
                
                if goals_for:
                    df.loc[idx, 'h2h_goals_for_avg'] = np.mean(goals_for)
                    df.loc[idx, 'h2h_goals_against_avg'] = np.mean(goals_against)
        
        return df
    
    def create_rolling_stats(self, df, windows=[3, 5, 10]):
        """Create rolling statistical features"""
        df = df.sort_values('match_date')
        
        for window in windows:
            # Home team rolling stats
            df[f'home_goals_scored_avg_{window}'] = 0.0
            df[f'home_goals_conceded_avg_{window}'] = 0.0
            df[f'home_points_avg_{window}'] = 0.0
            df[f'home_shots_avg_{window}'] = 0.0
            df[f'home_shots_on_target_avg_{window}'] = 0.0
            df[f'home_possession_avg_{window}'] = 0.0
            
            # Away team rolling stats
            df[f'away_goals_scored_avg_{window}'] = 0.0
            df[f'away_goals_conceded_avg_{window}'] = 0.0
            df[f'away_points_avg_{window}'] = 0.0
            df[f'away_shots_avg_{window}'] = 0.0
            df[f'away_shots_on_target_avg_{window}'] = 0.0
            df[f'away_possession_avg_{window}'] = 0.0
        
        teams = pd.concat([df['home_team'], df['away_team']]).unique()
        
        for team in teams:
            team_matches = df[(df['home_team'] == team) | (df['away_team'] == team)].copy()
            team_matches = team_matches.sort_values('match_date')
            
            for window in windows:
                for i, (idx, match) in enumerate(team_matches.iterrows()):
                    if i < window:
                        continue
                    
                    recent_matches = team_matches.iloc[max(0, i-window):i]
                    
                    # Calculate stats for recent matches
                    goals_scored = []
                    goals_conceded = []
                    points = []
                    shots = []
                    shots_on_target = []
                    possession = []
                    
                    for _, recent_match in recent_matches.iterrows():
                        if recent_match['home_team'] == team:
                            # Team was playing at home
                            if 'home_goals' in recent_match and pd.notna(recent_match['home_goals']):
                                goals_scored.append(recent_match['home_goals'])
                                goals_conceded.append(recent_match['away_goals'])
                            
                            if recent_match['result'] == 'H':
                                points.append(3)
                            elif recent_match['result'] == 'D':
                                points.append(1)
                            else:
                                points.append(0)
                            
                            if 'home_shots' in recent_match and pd.notna(recent_match['home_shots']):
                                shots.append(recent_match['home_shots'])
                            if 'home_shots_on_target' in recent_match and pd.notna(recent_match['home_shots_on_target']):
                                shots_on_target.append(recent_match['home_shots_on_target'])
                            if 'home_possession' in recent_match and pd.notna(recent_match['home_possession']):
                                possession.append(recent_match['home_possession'])
                        else:
                            # Team was playing away
                            if 'away_goals' in recent_match and pd.notna(recent_match['away_goals']):
                                goals_scored.append(recent_match['away_goals'])
                                goals_conceded.append(recent_match['home_goals'])
                            
                            if recent_match['result'] == 'A':
                                points.append(3)
                            elif recent_match['result'] == 'D':
                                points.append(1)
                            else:
                                points.append(0)
                            
                            if 'away_shots' in recent_match and pd.notna(recent_match['away_shots']):
                                shots.append(recent_match['away_shots'])
                            if 'away_shots_on_target' in recent_match and pd.notna(recent_match['away_shots_on_target']):
                                shots_on_target.append(recent_match['away_shots_on_target'])
                            if 'away_possession' in recent_match and pd.notna(recent_match['away_possession']):
                                possession.append(recent_match['away_possession'])
                    
                    # Update rolling averages
                    if match['home_team'] == team:
                        if goals_scored:
                            df.loc[idx, f'home_goals_scored_avg_{window}'] = np.mean(goals_scored)
                            df.loc[idx, f'home_goals_conceded_avg_{window}'] = np.mean(goals_conceded)
                        df.loc[idx, f'home_points_avg_{window}'] = np.mean(points) if points else 0
                        if shots:
                            df.loc[idx, f'home_shots_avg_{window}'] = np.mean(shots)
                        if shots_on_target:
                            df.loc[idx, f'home_shots_on_target_avg_{window}'] = np.mean(shots_on_target)
                        if possession:
                            df.loc[idx, f'home_possession_avg_{window}'] = np.mean(possession)
                    else:
                        if goals_scored:
                            df.loc[idx, f'away_goals_scored_avg_{window}'] = np.mean(goals_scored)
                            df.loc[idx, f'away_goals_conceded_avg_{window}'] = np.mean(goals_conceded)
                        df.loc[idx, f'away_points_avg_{window}'] = np.mean(points) if points else 0
                        if shots:
                            df.loc[idx, f'away_shots_avg_{window}'] = np.mean(shots)
                        if shots_on_target:
                            df.loc[idx, f'away_shots_on_target_avg_{window}'] = np.mean(shots_on_target)
                        if possession:
                            df.loc[idx, f'away_possession_avg_{window}'] = np.mean(possession)
        
        return df
    
    def create_venue_features(self, df):
        """Create venue and home advantage features"""
        # Home advantage stats
        df['home_advantage_score'] = 0.0
        df['venue_altitude'] = 0.0  # Placeholder for venue altitude
        df['venue_capacity'] = 0.0  # Placeholder for venue capacity
        
        venues = df['venue'].unique() if 'venue' in df.columns else []
        
        for venue in venues:
            venue_matches = df[df['venue'] == venue]
            if len(venue_matches) > 0:
                home_wins = len(venue_matches[venue_matches['result'] == 'H'])
                total_matches = len(venue_matches)
                home_advantage = home_wins / total_matches if total_matches > 0 else 0.5
                
                df.loc[df['venue'] == venue, 'home_advantage_score'] = home_advantage
        
        return df
    
    def create_weather_features(self, df):
        """Create weather-related features"""
        # Placeholder weather features - in production, these would come from weather APIs
        df['temperature'] = np.random.normal(15, 10, len(df))  # Temperature in Celsius
        df['humidity'] = np.random.uniform(30, 90, len(df))  # Humidity percentage
        df['wind_speed'] = np.random.exponential(5, len(df))  # Wind speed in km/h
        df['precipitation'] = np.random.exponential(2, len(df))  # Precipitation in mm
        df['is_rainy'] = (df['precipitation'] > 5).astype(int)
        df['is_windy'] = (df['wind_speed'] > 15).astype(int)
        df['is_cold'] = (df['temperature'] < 5).astype(int)
        df['is_hot'] = (df['temperature'] > 25).astype(int)
        
        return df
    
    def create_league_features(self, df):
        """Create league-specific features"""
        if 'league' in df.columns:
            # League strength and competitiveness metrics
            df['league_avg_goals'] = 0.0
            df['league_competitiveness'] = 0.0
            
            for league in df['league'].unique():
                league_matches = df[df['league'] == league]
                
                if 'home_goals' in league_matches.columns and 'away_goals' in league_matches.columns:
                    avg_goals = (league_matches['home_goals'].mean() + 
                               league_matches['away_goals'].mean())
                    df.loc[df['league'] == league, 'league_avg_goals'] = avg_goals
                
                # Calculate competitiveness (lower variance in team performance = higher competitiveness)
                if len(league_matches) > 10:
                    home_win_rate = len(league_matches[league_matches['result'] == 'H']) / len(league_matches)
                    away_win_rate = len(league_matches[league_matches['result'] == 'A']) / len(league_matches)
                    draw_rate = len(league_matches[league_matches['result'] == 'D']) / len(league_matches)
                    
                    # Higher entropy = more competitive
                    entropy = -sum([p * np.log(p + 1e-10) for p in [home_win_rate, away_win_rate, draw_rate]])
                    df.loc[df['league'] == league, 'league_competitiveness'] = entropy
        
        return df
    
    def create_player_features(self, df):
        """Create player-related features (simplified version)"""
        # Placeholder for player features - in production, these would come from player databases
        df['home_team_rating'] = np.random.normal(75, 10, len(df))  # Team rating out of 100
        df['away_team_rating'] = np.random.normal(75, 10, len(df))
        df['home_injuries'] = np.random.poisson(2, len(df))  # Number of key injuries
        df['away_injuries'] = np.random.poisson(2, len(df))
        df['home_suspensions'] = np.random.poisson(1, len(df))  # Number of suspensions
        df['away_suspensions'] = np.random.poisson(1, len(df))
        df['rating_difference'] = df['home_team_rating'] - df['away_team_rating']
        
        return df
    
    def encode_categorical_features(self, df):
        """Encode categorical features"""
        categorical_cols = ['home_team', 'away_team', 'venue', 'league', 'referee']
        
        for col in categorical_cols:
            if col in df.columns:
                if not self.is_fitted:
                    df[f'{col}_encoded'] = getattr(self, f'{col.split("_")[0]}_encoder').fit_transform(df[col].astype(str))
                else:
                    # Handle new categories during prediction
                    unique_vals = getattr(self, f'{col.split("_")[0]}_encoder').classes_
                    df[col] = df[col].astype(str)
                    df[col] = df[col].apply(lambda x: x if x in unique_vals else unique_vals[0])
                    df[f'{col}_encoded'] = getattr(self, f'{col.split("_")[0]}_encoder').transform(df[col])
        
        return df
    
    def create_all_features(self, df, target_column='result'):
        """Create comprehensive feature set"""
        print("Creating base features...")
        df = self.create_base_features(df)
        
        print("Creating form features...")
        df = self.create_form_features(df, 'home_team', target_column)
        
        print("Creating head-to-head features...")
        df = self.create_head_to_head_features(df)
        
        print("Creating rolling statistics...")
        df = self.create_rolling_stats(df)
        
        print("Creating venue features...")
        df = self.create_venue_features(df)
        
        print("Creating weather features...")
        df = self.create_weather_features(df)
        
        print("Creating league features...")
        df = self.create_league_features(df)
        
        print("Creating player features...")
        df = self.create_player_features(df)
        
        print("Encoding categorical features...")
        df = self.encode_categorical_features(df)
        
        self.is_fitted = True
        
        # Select only numeric features for model training
        feature_columns = [col for col in df.columns if 
                          col not in ['match_date', 'home_team', 'away_team', 'venue', 'league', 'referee', target_column] 
                          and df[col].dtype in ['int64', 'float64']]
        
        print(f"Created {len(feature_columns)} features total")
        
        return df, feature_columns
    
    def get_feature_summary(self, df, feature_columns):
        """Get summary of created features"""
        feature_summary = {
            'total_features': len(feature_columns),
            'form_features': len([col for col in feature_columns if 'form' in col]),
            'h2h_features': len([col for col in feature_columns if 'h2h' in col]),
            'rolling_features': len([col for col in feature_columns if 'avg' in col]),
            'weather_features': len([col for col in feature_columns if col in ['temperature', 'humidity', 'wind_speed', 'precipitation', 'is_rainy', 'is_windy', 'is_cold', 'is_hot']]),
            'venue_features': len([col for col in feature_columns if 'venue' in col or 'home_advantage' in col]),
            'league_features': len([col for col in feature_columns if 'league' in col]),
            'player_features': len([col for col in feature_columns if 'rating' in col or 'injuries' in col or 'suspensions' in col]),
            'encoded_features': len([col for col in feature_columns if 'encoded' in col])
        }
        
        return feature_summary
