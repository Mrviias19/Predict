import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import optuna
from models.ensemble_model import FootballPredictionEnsemble
from models.feature_engineering import FootballFeatureEngineer
import joblib
import os
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class ModelTrainer:
    """
    Advanced model training and optimization system
    """
    
    def __init__(self):
        self.model = FootballPredictionEnsemble()
        self.feature_engineer = FootballFeatureEngineer()
        self.training_history = []
        self.best_params = {}
        
    def prepare_training_data(self, df, target_column='result'):
        """Prepare data for model training"""
        print("Preparing training data...")
        
        # Create features
        df_features, feature_columns = self.feature_engineer.create_all_features(df, target_column)
        
        # Prepare feature matrix and target
        X = df_features[feature_columns].copy()
        
        # Handle missing values
        X = X.fillna(X.mean())
        
        # Encode target variable
        if target_column in df_features.columns:
            target_mapping = {'H': 0, 'D': 1, 'A': 2}  # Home, Draw, Away
            y = df_features[target_column].map(target_mapping)
            y = y.dropna()
            X = X.loc[y.index]
        else:
            raise ValueError(f"Target column '{target_column}' not found in data")
        
        print(f"Training data shape: {X.shape}")
        print(f"Feature columns: {len(feature_columns)}")
        print(f"Class distribution: {y.value_counts().to_dict()}")
        
        return X, y, feature_columns
    
    def optimize_hyperparameters(self, X, y, n_trials=100):
        """Optimize hyperparameters using Optuna"""
        print(f"Starting hyperparameter optimization with {n_trials} trials...")
        
        def objective(trial):
            # Random Forest parameters
            rf_params = {
                'n_estimators': trial.suggest_int('rf_n_estimators', 100, 300),
                'max_depth': trial.suggest_int('rf_max_depth', 10, 20),
                'min_samples_split': trial.suggest_int('rf_min_samples_split', 2, 10),
                'min_samples_leaf': trial.suggest_int('rf_min_samples_leaf', 1, 5)
            }
            
            # XGBoost parameters
            xgb_params = {
                'n_estimators': trial.suggest_int('xgb_n_estimators', 100, 300),
                'max_depth': trial.suggest_int('xgb_max_depth', 3, 10),
                'learning_rate': trial.suggest_float('xgb_learning_rate', 0.01, 0.3),
                'subsample': trial.suggest_float('xgb_subsample', 0.6, 1.0),
                'colsample_bytree': trial.suggest_float('xgb_colsample_bytree', 0.6, 1.0)
            }
            
            # LightGBM parameters
            lgb_params = {
                'n_estimators': trial.suggest_int('lgb_n_estimators', 100, 300),
                'max_depth': trial.suggest_int('lgb_max_depth', 3, 10),
                'learning_rate': trial.suggest_float('lgb_learning_rate', 0.01, 0.3),
                'subsample': trial.suggest_float('lgb_subsample', 0.6, 1.0),
                'colsample_bytree': trial.suggest_float('lgb_colsample_bytree', 0.6, 1.0)
            }
            
            # Create temporary model with suggested parameters
            temp_model = FootballPredictionEnsemble()
            
            # Update model parameters
            temp_model.models['random_forest'] = temp_model.models.get('random_forest', temp_model.create_models()['random_forest'])
            for param, value in rf_params.items():
                setattr(temp_model.models['random_forest'], param.replace('rf_', ''), value)
            
            # Split data for validation
            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
            
            # Train and evaluate
            try:
                temp_model.train(X_train, y_train, validation_split=0.2)
                predictions = temp_model.predict(X_val)
                accuracy = accuracy_score(y_val, predictions['predicted_class'])
                return accuracy
            except Exception as e:
                print(f"Trial failed: {e}")
                return 0.0
        
        # Run optimization
        study = optuna.create_study(direction='maximize')
        study.optimize(objective, n_trials=n_trials)
        
        self.best_params = study.best_params
        print(f"Best accuracy: {study.best_value:.4f}")
        print(f"Best parameters: {self.best_params}")
        
        return study.best_params, study.best_value
    
    def train_model(self, X, y, optimize_params=True, n_trials=50):
        """Train the ensemble model with optional hyperparameter optimization"""
        print("Starting model training...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Optimize hyperparameters if requested
        if optimize_params:
            best_params, best_score = self.optimize_hyperparameters(X_train, y_train, n_trials)
            self.apply_best_parameters(best_params)
        
        # Train the model
        training_results = self.model.train(X_train, y_train, validation_split=0.2)
        
        # Evaluate on test set
        test_predictions = self.model.predict(X_test)
        test_accuracy = accuracy_score(y_test, test_predictions['predicted_class'])
        
        # Create comprehensive training report
        training_report = {
            'timestamp': datetime.now(),
            'training_samples': len(X_train),
            'test_samples': len(X_test),
            'features_count': X.shape[1],
            'test_accuracy': test_accuracy,
            'individual_model_scores': training_results,
            'best_hyperparameters': self.best_params if optimize_params else None,
            'class_distribution': y.value_counts().to_dict(),
            'confusion_matrix': confusion_matrix(y_test, test_predictions['predicted_class']).tolist(),
            'classification_report': classification_report(y_test, test_predictions['predicted_class'], output_dict=True)
        }
        
        self.training_history.append(training_report)
        
        print(f"Model training completed!")
        print(f"Test accuracy: {test_accuracy:.4f}")
        print(f"Training history length: {len(self.training_history)}")
        
        return training_report
    
    def apply_best_parameters(self, best_params):
        """Apply optimized hyperparameters to model"""
        # Create models with optimized parameters
        self.model.create_models()
        
        # Apply Random Forest parameters
        rf_params = {k.replace('rf_', ''): v for k, v in best_params.items() if k.startswith('rf_')}
        for param, value in rf_params.items():
            if hasattr(self.model.models['random_forest'], param):
                setattr(self.model.models['random_forest'], param, value)
        
        # Apply XGBoost parameters
        xgb_params = {k.replace('xgb_', ''): v for k, v in best_params.items() if k.startswith('xgb_')}
        for param, value in xgb_params.items():
            if hasattr(self.model.models['xgboost'], param):
                setattr(self.model.models['xgboost'], param, value)
        
        # Apply LightGBM parameters
        lgb_params = {k.replace('lgb_', ''): v for k, v in best_params.items() if k.startswith('lgb_')}
        for param, value in lgb_params.items():
            if hasattr(self.model.models['lightgbm'], param):
                setattr(self.model.models['lightgbm'], param, value)
    
    def evaluate_model_performance(self, X, y, cv_folds=5):
        """Comprehensive model evaluation"""
        from sklearn.model_selection import cross_val_score, StratifiedKFold
        from sklearn.metrics import brier_score_loss, log_loss
        
        print("Evaluating model performance...")
        
        # Cross-validation
        skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
        cv_scores = cross_val_score(self.model.ensemble, X, y, cv=skf, scoring='accuracy')
        
        # Split for additional metrics
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
        
        # Train on subset and predict
        self.model.train(X_train, y_train)
        predictions = self.model.predict(X_test)
        
        y_pred = predictions['predicted_class']
        y_proba = predictions['final_prediction']
        
        # Calculate comprehensive metrics
        evaluation_metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'cv_accuracy_mean': cv_scores.mean(),
            'cv_accuracy_std': cv_scores.std(),
            'brier_score': self.calculate_multiclass_brier_score(y_test, y_proba),
            'log_loss': log_loss(y_test, y_proba),
            'confidence_metrics': self.analyze_confidence_metrics(predictions['confidence'], y_test, y_pred),
            'per_class_metrics': classification_report(y_test, y_pred, output_dict=True)
        }
        
        return evaluation_metrics
    
    def calculate_multiclass_brier_score(self, y_true, y_proba):
        """Calculate Brier score for multiclass classification"""
        # Convert to one-hot encoding
        n_classes = y_proba.shape[1]
        y_true_onehot = np.zeros((len(y_true), n_classes))
        for i, label in enumerate(y_true):
            y_true_onehot[i, label] = 1
        
        # Calculate Brier score
        brier_score = np.mean(np.sum((y_proba - y_true_onehot) ** 2, axis=1))
        return brier_score
    
    def analyze_confidence_metrics(self, confidence, y_true, y_pred):
        """Analyze model confidence vs accuracy"""
        correct_predictions = (y_true == y_pred)
        
        # Group by confidence levels
        high_confidence = confidence > 0.7
        medium_confidence = (confidence >= 0.5) & (confidence <= 0.7)
        low_confidence = confidence < 0.5
        
        metrics = {
            'high_confidence_accuracy': correct_predictions[high_confidence].mean() if high_confidence.sum() > 0 else 0,
            'medium_confidence_accuracy': correct_predictions[medium_confidence].mean() if medium_confidence.sum() > 0 else 0,
            'low_confidence_accuracy': correct_predictions[low_confidence].mean() if low_confidence.sum() > 0 else 0,
            'high_confidence_count': high_confidence.sum(),
            'medium_confidence_count': medium_confidence.sum(),
            'low_confidence_count': low_confidence.sum(),
            'avg_confidence': confidence.mean(),
            'confidence_std': confidence.std()
        }
        
        return metrics
    
    def backtest_model(self, df, target_column='result', test_period_months=6):
        """Backtest model performance over time"""
        print(f"Starting backtest with {test_period_months} month test periods...")
        
        df = df.sort_values('match_date')
        df['match_date'] = pd.to_datetime(df['match_date'])
        
        # Get date range
        start_date = df['match_date'].min()
        end_date = df['match_date'].max()
        
        backtest_results = []
        current_date = start_date + pd.DateOffset(months=12)  # Start after 1 year of training data
        
        while current_date <= end_date - pd.DateOffset(months=test_period_months):
            # Define training and test periods
            train_end = current_date
            test_start = current_date
            test_end = current_date + pd.DateOffset(months=test_period_months)
            
            # Split data
            train_data = df[df['match_date'] < train_end]
            test_data = df[(df['match_date'] >= test_start) & (df['match_date'] < test_end)]
            
            if len(train_data) < 100 or len(test_data) < 20:
                current_date += pd.DateOffset(months=3)
                continue
            
            try:
                # Prepare training data
                X_train, y_train, feature_columns = self.prepare_training_data(train_data, target_column)
                
                # Prepare test data
                test_features, _ = self.feature_engineer.create_all_features(test_data, target_column)
                X_test = test_features[feature_columns].fillna(test_features[feature_columns].mean())
                
                target_mapping = {'H': 0, 'D': 1, 'A': 2}
                y_test = test_data[target_column].map(target_mapping).dropna()
                X_test = X_test.loc[y_test.index]
                
                # Train model
                temp_trainer = ModelTrainer()
                temp_trainer.model.train(X_train, y_train)
                
                # Make predictions
                predictions = temp_trainer.model.predict(X_test)
                accuracy = accuracy_score(y_test, predictions['predicted_class'])
                
                backtest_result = {
                    'test_period_start': test_start,
                    'test_period_end': test_end,
                    'train_samples': len(X_train),
                    'test_samples': len(X_test),
                    'accuracy': accuracy,
                    'avg_confidence': predictions['confidence'].mean()
                }
                
                backtest_results.append(backtest_result)
                print(f"Backtest period {test_start.strftime('%Y-%m')} to {test_end.strftime('%Y-%m')}: Accuracy = {accuracy:.3f}")
                
            except Exception as e:
                print(f"Backtest failed for period {current_date}: {e}")
            
            current_date += pd.DateOffset(months=3)
        
        return pd.DataFrame(backtest_results)
    
    def save_training_session(self, filepath):
        """Save complete training session including model and history"""
        training_session = {
            'model': self.model,
            'feature_engineer': self.feature_engineer,
            'training_history': self.training_history,
            'best_params': self.best_params,
            'timestamp': datetime.now()
        }
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        joblib.dump(training_session, filepath)
        print(f"Training session saved to {filepath}")
    
    def load_training_session(self, filepath):
        """Load complete training session"""
        training_session = joblib.load(filepath)
        
        self.model = training_session['model']
        self.feature_engineer = training_session['feature_engineer']
        self.training_history = training_session['training_history']
        self.best_params = training_session['best_params']
        
        print(f"Training session loaded from {filepath}")
        print(f"Model is trained: {self.model.is_trained}")
        print(f"Training history length: {len(self.training_history)}")
    
    def get_training_summary(self):
        """Get summary of all training sessions"""
        if not self.training_history:
            return "No training history available"
        
        latest_training = self.training_history[-1]
        
        summary = {
            'total_training_sessions': len(self.training_history),
            'latest_training_date': latest_training['timestamp'],
            'latest_test_accuracy': latest_training['test_accuracy'],
            'features_used': latest_training['features_count'],
            'training_samples': latest_training['training_samples'],
            'model_complexity': 'High (Ensemble of 4 models)',
            'optimization_status': 'Enabled' if self.best_params else 'Disabled'
        }
        
        return summary
