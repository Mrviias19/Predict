import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json


class BettingAnalytics:
    """
    Advanced betting analytics and value detection system
    """
    
    def __init__(self):
        self.kelly_fraction = 0.25  # Conservative Kelly fraction
        self.min_edge_threshold = 0.05  # Minimum 5% edge required
        self.confidence_threshold = 0.7  # Minimum confidence for bet recommendations
        
    def calculate_betting_value(self, model_probabilities, market_odds):
        """Calculate betting value and Kelly criterion recommendations"""
        
        # Convert odds to implied probabilities
        home_implied = 1 / market_odds['home'] if market_odds['home'] > 0 else 0
        draw_implied = 1 / market_odds['draw'] if market_odds['draw'] > 0 else 0
        away_implied = 1 / market_odds['away'] if market_odds['away'] > 0 else 0
        
        # Remove bookmaker margin (normalize to 100%)
        total_implied = home_implied + draw_implied + away_implied
        if total_implied > 0:
            home_fair = home_implied / total_implied
            draw_fair = draw_implied / total_implied
            away_fair = away_implied / total_implied
        else:
            return None
        
        # Calculate edges
        home_edge = model_probabilities['home'] - home_fair
        draw_edge = model_probabilities['draw'] - draw_fair
        away_edge = model_probabilities['away'] - away_fair
        
        # Kelly criterion calculations
        kelly_home = self.calculate_kelly_bet(model_probabilities['home'], market_odds['home'])
        kelly_draw = self.calculate_kelly_bet(model_probabilities['draw'], market_odds['draw'])
        kelly_away = self.calculate_kelly_bet(model_probabilities['away'], market_odds['away'])
        
        return {
            'edges': {
                'home': home_edge,
                'draw': draw_edge,
                'away': away_edge
            },
            'kelly_fractions': {
                'home': kelly_home,
                'draw': kelly_draw,
                'away': kelly_away
            },
            'fair_odds': {
                'home': 1/model_probabilities['home'] if model_probabilities['home'] > 0 else 0,
                'draw': 1/model_probabilities['draw'] if model_probabilities['draw'] > 0 else 0,
                'away': 1/model_probabilities['away'] if model_probabilities['away'] > 0 else 0
            },
            'market_margin': (total_implied - 1) * 100  # Bookmaker margin percentage
        }
    
    def calculate_kelly_bet(self, true_probability, odds):
        """Calculate Kelly criterion bet sizing"""
        if odds <= 1 or true_probability <= 0:
            return 0
            
        # Kelly formula: (bp - q) / b
        # where b = odds - 1, p = true probability, q = 1 - p
        b = odds - 1
        p = true_probability
        q = 1 - p
        
        kelly = (b * p - q) / b
        
        # Apply fractional Kelly for risk management
        return max(0, kelly * self.kelly_fraction)
    
    def identify_value_bets(self, predictions_with_odds):
        """Identify and rank value betting opportunities"""
        
        value_bets = []
        
        for prediction in predictions_with_odds:
            betting_analysis = self.calculate_betting_value(
                prediction['probabilities'], 
                prediction['market_odds']
            )
            
            if betting_analysis is None:
                continue
                
            # Check each outcome for value
            for outcome in ['home', 'draw', 'away']:
                edge = betting_analysis['edges'][outcome]
                kelly = betting_analysis['kelly_fractions'][outcome]
                
                if edge >= self.min_edge_threshold and kelly > 0:
                    value_bet = {
                        'match': prediction['match_info'],
                        'outcome': outcome,
                        'edge': edge,
                        'kelly_fraction': kelly,
                        'recommended_stake': kelly,
                        'market_odds': prediction['market_odds'][outcome],
                        'fair_odds': betting_analysis['fair_odds'][outcome],
                        'confidence': prediction.get('confidence', 0),
                        'expected_value': edge * prediction['market_odds'][outcome],
                        'market_margin': betting_analysis['market_margin']
                    }
                    value_bets.append(value_bet)
        
        # Sort by expected value
        value_bets.sort(key=lambda x: x['expected_value'], reverse=True)
        
        return value_bets
    
    def calculate_betting_portfolio_metrics(self, value_bets, bankroll=1000):
        """Calculate portfolio-level betting metrics"""
        
        if not value_bets:
            return {}
        
        total_stake = sum(bet['recommended_stake'] for bet in value_bets) * bankroll
        total_expected_value = sum(bet['expected_value'] * bet['recommended_stake'] for bet in value_bets) * bankroll
        
        # Risk metrics
        portfolio_variance = self.calculate_portfolio_variance(value_bets)
        sharpe_ratio = total_expected_value / (portfolio_variance ** 0.5) if portfolio_variance > 0 else 0
        
        # Diversification metrics
        outcome_distribution = {}
        for bet in value_bets:
            outcome_distribution[bet['outcome']] = outcome_distribution.get(bet['outcome'], 0) + bet['recommended_stake']
        
        return {
            'total_bets': len(value_bets),
            'total_stake_percentage': total_stake / bankroll * 100,
            'expected_roi': (total_expected_value / total_stake * 100) if total_stake > 0 else 0,
            'portfolio_variance': portfolio_variance,
            'sharpe_ratio': sharpe_ratio,
            'outcome_distribution': outcome_distribution,
            'average_edge': np.mean([bet['edge'] for bet in value_bets]),
            'max_single_bet': max(bet['recommended_stake'] for bet in value_bets) * 100,
            'min_confidence': min(bet['confidence'] for bet in value_bets),
            'avg_confidence': np.mean([bet['confidence'] for bet in value_bets])
        }
    
    def calculate_portfolio_variance(self, value_bets):
        """Calculate portfolio variance for risk assessment"""
        
        if len(value_bets) <= 1:
            return 0
        
        # Simplified variance calculation
        stakes = [bet['recommended_stake'] for bet in value_bets]
        odds = [bet['market_odds'] for bet in value_bets]
        probabilities = [1/bet['fair_odds'] if bet['fair_odds'] > 0 else 0 for bet in value_bets]
        
        portfolio_variance = 0
        for i, bet in enumerate(value_bets):
            # Individual bet variance
            p = probabilities[i]
            stake = stakes[i]
            payout = odds[i] * stake
            
            bet_variance = p * (payout - stake) ** 2 + (1 - p) * stake ** 2
            portfolio_variance += bet_variance
        
        return portfolio_variance
    
    def analyze_market_efficiency(self, historical_predictions, actual_results):
        """Analyze market efficiency and model performance over time"""
        
        market_analysis = {
            'total_predictions': len(historical_predictions),
            'profitable_bets': 0,
            'total_roi': 0,
            'accuracy_by_confidence': {},
            'market_bias_analysis': {},
            'seasonal_patterns': {}
        }
        
        # Analyze by confidence levels
        confidence_buckets = [0.6, 0.7, 0.8, 0.9, 1.0]
        
        for i, bucket in enumerate(confidence_buckets[:-1]):
            bucket_predictions = [
                p for p in historical_predictions 
                if bucket <= p.get('confidence', 0) < confidence_buckets[i+1]
            ]
            
            if bucket_predictions:
                correct_predictions = sum(
                    1 for p in bucket_predictions 
                    if self.is_prediction_correct(p, actual_results)
                )
                
                market_analysis['accuracy_by_confidence'][f'{bucket:.1f}-{confidence_buckets[i+1]:.1f}'] = {
                    'accuracy': correct_predictions / len(bucket_predictions),
                    'sample_size': len(bucket_predictions)
                }
        
        return market_analysis
    
    def is_prediction_correct(self, prediction, actual_results):
        """Check if a prediction was correct"""
        # Simplified check - in real implementation, match with actual results
        return np.random.choice([True, False], p=[0.65, 0.35])  # 65% accuracy simulation
    
    def generate_betting_insights(self, value_bets, portfolio_metrics):
        """Generate actionable betting insights and recommendations"""
        
        insights = []
        
        # Portfolio-level insights
        if portfolio_metrics.get('total_bets', 0) > 0:
            
            if portfolio_metrics['expected_roi'] > 10:
                insights.append({
                    'type': 'opportunity',
                    'title': 'High Value Portfolio',
                    'message': f"Strong value opportunities identified with {portfolio_metrics['expected_roi']:.1f}% expected ROI",
                    'confidence': 'high'
                })
            
            if portfolio_metrics['total_stake_percentage'] > 15:
                insights.append({
                    'type': 'warning',
                    'title': 'High Risk Exposure',
                    'message': f"Portfolio stakes {portfolio_metrics['total_stake_percentage']:.1f}% of bankroll - consider reducing bet sizes",
                    'confidence': 'medium'
                })
            
            if portfolio_metrics['sharpe_ratio'] > 1.5:
                insights.append({
                    'type': 'positive',
                    'title': 'Excellent Risk-Adjusted Returns',
                    'message': f"Sharpe ratio of {portfolio_metrics['sharpe_ratio']:.2f} indicates strong risk-adjusted value",
                    'confidence': 'high'
                })
        
        # Individual bet insights
        high_value_bets = [bet for bet in value_bets if bet['edge'] > 0.1]
        if high_value_bets:
            insights.append({
                'type': 'opportunity',
                'title': 'Premium Value Bets',
                'message': f"{len(high_value_bets)} bets with >10% edge identified",
                'confidence': 'high',
                'bets': high_value_bets[:3]  # Top 3
            })
        
        # Market inefficiency insights
        draw_bets = [bet for bet in value_bets if bet['outcome'] == 'draw']
        if len(draw_bets) > len(value_bets) * 0.4:
            insights.append({
                'type': 'analysis',
                'title': 'Draw Market Inefficiency',
                'message': "Market appears to consistently undervalue draw probabilities",
                'confidence': 'medium'
            })
        
        return insights
    
    def create_betting_dashboard_data(self, value_bets, portfolio_metrics):
        """Prepare data for betting analytics dashboard"""
        
        dashboard_data = {
            'summary_metrics': {
                'total_opportunities': len(value_bets),
                'total_expected_value': sum(bet['expected_value'] for bet in value_bets),
                'average_edge': np.mean([bet['edge'] for bet in value_bets]) if value_bets else 0,
                'recommended_stakes': sum(bet['recommended_stake'] for bet in value_bets),
                'highest_value_bet': max(value_bets, key=lambda x: x['expected_value']) if value_bets else None
            },
            'risk_metrics': portfolio_metrics,
            'bet_distribution': {
                'by_outcome': {},
                'by_edge_range': {},
                'by_confidence': {}
            },
            'top_opportunities': value_bets[:10],  # Top 10 bets
            'market_insights': self.analyze_market_patterns(value_bets)
        }
        
        # Calculate distributions
        if value_bets:
            # By outcome
            for bet in value_bets:
                outcome = bet['outcome']
                dashboard_data['bet_distribution']['by_outcome'][outcome] = \
                    dashboard_data['bet_distribution']['by_outcome'].get(outcome, 0) + 1
            
            # By edge range
            edge_ranges = [(0, 0.05), (0.05, 0.1), (0.1, 0.15), (0.15, float('inf'))]
            for min_edge, max_edge in edge_ranges:
                range_key = f"{min_edge:.0%}-{max_edge:.0%}" if max_edge != float('inf') else f"{min_edge:.0%}+"
                count = sum(1 for bet in value_bets if min_edge <= bet['edge'] < max_edge)
                dashboard_data['bet_distribution']['by_edge_range'][range_key] = count
        
        return dashboard_data
    
    def analyze_market_patterns(self, value_bets):
        """Analyze patterns in market inefficiencies"""
        
        patterns = {
            'favorite_bias': 0,
            'underdog_opportunities': 0,
            'draw_value_frequency': 0,
            'high_margin_markets': 0
        }
        
        for bet in value_bets:
            # Analyze market patterns
            if bet['market_odds'] < 2.0:  # Favorites
                patterns['favorite_bias'] += 1
            elif bet['market_odds'] > 3.0:  # Underdogs
                patterns['underdog_opportunities'] += 1
            
            if bet['outcome'] == 'draw':
                patterns['draw_value_frequency'] += 1
            
            if bet['market_margin'] > 8:  # High margin markets
                patterns['high_margin_markets'] += 1
        
        return patterns